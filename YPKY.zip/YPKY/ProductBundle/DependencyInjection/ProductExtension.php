<?php

namespace YPKY\ProductBundle\DependencyInjection;

use Symfony\Component\DependencyInjection\ContainerBuilder;
use Symfony\Component\Config\FileLocator;
use Symfony\Component\HttpKernel\DependencyInjection\Extension;
use Symfony\Component\DependencyInjection\Loader;

/**
 * This is the class that loads and manages your bundle configuration
 *
 * To learn more see {@link http://symfony.com/doc/current/cookbook/bundles/extension.html}
 */
class ProductExtension extends Extension
{
    /**
     * {@inheritDoc}
     */
    public function load(array $configs, ContainerBuilder $container)
    {
        $configuration = new Configuration();
        $config = $this->processConfiguration($configuration, $configs);

        $loader = new Loader\YamlFileLoader($container, new FileLocator(__DIR__.'/../Resources/config'));
        $loader->load('services.yml');

        
        // build config for internal_forms
        foreach ($config['internal_forms'] as $key => $value) {
            $parameterName = $this->getAlias().'.internal_forms.'.$key;
            $container->setParameter($parameterName, $value);
        }
        
        $container->setParameter('product.internal_forms', $config['internal_forms']);
        $container->setParameter('product.product_forms', $config['product_forms']);
        $container->setParameter('product.form_fields', $config['form_fields']);
        $container->setParameter('product.question_template_names', $config['question_templates_names']);
    }
}
