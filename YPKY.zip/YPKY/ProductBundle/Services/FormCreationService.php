<?php
/**
 * Form Creation Service Class
 * @description This class is a service to duplicate form and each form questions and elements.
 * @author Diovannie Donayre
 * @created Feb 3 2015
 */
namespace YPKY\ProductBundle\Services;

use Doctrine\ORM\EntityManager;

use YPKY\ProductBundle\Entity\FormSection;
use YPKY\ProductBundle\Entity\Form;
use YPKY\ProductBundle\Entity\FormElement;
use YPKY\ProductBundle\Entity\FormQuestion;
use YPKY\ProductBundle\Entity\FormDefaultState;

use YPKY\ProductBundle\Exception\FormCreationException;

class FormCreationService
{
    //Entity manager
    private $em;

    //us states question template name
    private $usStateTemplateName;

    const FORM_NAME_STATE_SEPARATOR = ' for ';
    
    //current repository
    private $repository;

    public function __construct(EntityManager $em)
    {
        $this->em = $em;
        $this->repository = $em->getRepository('ProductBundle:Form');
    }

    public function setUsStateTemplateName($questionTemplateNames = array())
    {
        $this->usStateTemplateName = $questionTemplateNames['organization_profile']['mailing_address']['org_us_state'];
    }

    /*
        Find Form by name
        @param $formName String
        @return Form Entity
    */
    private function findFormByName($formName)
    {
        return $this->repository->findOneByName($formName);
    }
    /*
        Create Form for each states
        @param String $formName
        @return Array of formstates created
    */
    public function createFormStates($formName)
    {
        $formToClone = $this->findFormByName($formName);

        if (!$formToClone) {
           throw FormCreationException::formNotFound($formName);
        }

        $manager = $this->em;
        $formStatesGenerated = array();
        $states = $this->em->getRepository('AdminBundle:State')->findAll();

        try {
            $manager->getConnection()->beginTransaction();

            foreach ($states as $state) {
                //Clone Form
                $newForm = clone $formToClone;
                $newForm->setName($formName . self::FORM_NAME_STATE_SEPARATOR . $state->getName());
                $newForm->setStatus(1);
                $manager->persist($newForm);

                //create form and state relationship for state default value of form

                $stateFormCompliance = new FormDefaultState();
                $stateFormCompliance->setState($state);
                $stateFormCompliance->setForm($newForm);
                $manager->persist($stateFormCompliance);

                //duplicate each formelements, formsections, and formquestion in current state compliance form
                $this->duplicateFormElementsQuestionsAndSections($formToClone, $newForm, $state->getId());

                $formStatesGenerated[$state->getName()] = $newForm->getName();

                $manager->flush();
            }

            $manager->clear();
            $manager->getConnection()->commit();
           
            return  $formStatesGenerated;

        } catch (\Exception $e) {
            $manager->getConnection()->rollback();
            throw $e;
        }                  
        

    }

   /*
        Duplicate all formelement, formquestion and formsection from each form
        @param Formquestions array object, Form Entity, Int $stateId
   */

    private function duplicateFormElementsQuestionsAndSections(Form $formToClone, Form $newForm, $stateId)
    {
        $formQuestions = $this->em->getRepository('ProductBundle:FormQuestion')
                            ->getFormQuestionsWithFormElementByForm($formToClone);
        $em = $this->em;
        $formSectionsList = array();

        foreach ($formQuestions as $formQuestion) {
            $isGlobal = 1;
            $formElement = $formQuestion->getFormElement();
            $formSection = $formElement->getFormSection();

            if (!array_key_exists($formElement->getFormSection()->getName(), $formSectionsList) && $formSection instanceof FormSection) {
                 //Clone and persists Formsection object
                $newFormSection = clone $formSection;
                $newFormSection->setForm($newForm);
               
                $formSectionsList[$formElement->getFormSection()->getName()] = $newFormSection;

            } else {
                $newFormSection = $formSectionsList[$formElement->getFormSection()->getName()];
            }

            $em->persist($newFormSection);

            //Clone and persist FormElement object
            if ($formElement instanceof FormElement) {
                $newFormElement = clone $formElement;
                $newFormElement->setForm($newForm);
                $newFormElement->setFormSection($newFormSection);
                $widgetMetaData = \json_decode($formElement->getWidgetMetadata(), true);
                if ($formQuestion->getQuestionTemplate()->getName() == $this->usStateTemplateName) {
                    $isGlobal = 0;
                    $widgetMetaData['widget_attribute'] = array(array('data-state' => $stateId, 'disabled' => 'disabled'));
                    $newFormElement->setWidgetMetadata(\json_encode($widgetMetaData, true));
                }
            }

            $em->persist($newFormElement);
            
            //Clone and persist FormQuestion Object
            if ($formQuestion instanceof FormQuestion) {
                $newFormQuestion = clone $formQuestion;
                $newFormQuestion->setForm($newForm);
                $newFormQuestion->setIsGlobal($isGlobal);
                $newFormQuestion->setFormElement($newFormElement);
            }

            $em->persist($newFormQuestion);
          
        }

    }

}


