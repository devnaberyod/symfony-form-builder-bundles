<?php

namespace YPKY\ProductBundle\Services;

use Doctrine\ORM\EntityManager;
use Doctrine\ORM\Query;
use YPKY\ProductBundle\Entity\FormElement;
use YPKY\ProductBundle\Entity\FormElementTypes;
use YPKY\HelperBundle\Classes\QueryOption;
use YPKY\ProductBundle\Entity\FormQuestion;
use YPKY\ProductBundle\Entity\FormSection;
use YPKY\ProductBundle\Entity\Form;
use YPKY\HelperBundle\Service\EntitySerializerService;

/**
 * Provides service methods for form elements
 */
class FormElementService
{
    /**
     * Entity Manager
     */
    private $em;

    private $defaultRenderConfiguration;
    
    /** 
     * @var EntitySerializerService
     */
    private $entitySerializerService;


    public function __construct(EntityManager $em)
    {
        $this->em = $em;
    }

    public function setDefaultRenderConfiguration($v)
    {
        $this->defaultRenderConfiguration = $v;
    }

    /** 
     * @param EntitySerializerService $service
     */
    public function setEntitySerializerService(EntitySerializerService $service)
    {
        $this->entitySerializerService = $service;
    }

    /**
     * Retrieves form elements of given filters
     */
    public function getFormElements($filters = array(), $hydrateMode = Query::HYDRATE_ARRAY, QueryOption $queryOption=null)
    {
        $repo = $this->em->getRepository('ProductBundle:FormElement');

        $qb = $repo->createQueryBuilderWithFilters($filters, $queryOption);

        $results = $qb->getQuery()->getResult($hydrateMode);

        return $results;
    }
    
    public function getByFormSection(FormSection $formSection, $hydrateMode = Query::HYDRATE_ARRAY)
    {
        $repo = $this->em->getRepository('ProductBundle:FormElement');

        $filters = array('formSection' => $formSection);
        
        $qb = $repo->createQueryBuilderWithFilters($filters, null);
        
        return $qb->getQuery()->getResult($hydrateMode);
        
    }
    
    public function deleteByFormSection(FormSection $formSection, $flush = true)
    {
        if($formSection->getForm()->getStatus() == Form::STATUS_ACTIVE) {
            throw new \Exception('FormElements with ACTIVE Form cannot be deleted.');
        }

        $formElements = $this->getByFormSection($formSection, Query::HYDRATE_OBJECT);
        foreach($formElements as $each) {

            if($each->getFormQuestion()) {
                $this->em->remove($each->getFormQuestion());
            }

            $this->em->remove($each);
        }

        if($flush)
            $this->em->flush();
    }

    public function createPrototypeFromQuestionTemplate($questionTemplate)
    {
        if ($questionTemplate instanceof QuestionTemplate) {

            // convert instance to Array to cater array hydrated entity
            return $this->entitySerializerService->toArray($questionTemplate);
        }
        else {
            if (!is_array($questionTemplate)) {
                throw new \Exception('Invalid argument for FormElementService::createPrototypeFromQuestionTemplate');
            }
        }

        $formElement = new FormElement();
        $formElement->setElementType(FormElementTypes::QUESTION_TEMPLATE);
        $formElement->setRenderConfig(\json_encode($this->defaultRenderConfiguration));
        $formElement->setText($questionTemplate['question']);

        return $formElement;
    }
}
