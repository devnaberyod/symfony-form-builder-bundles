<?php

namespace YPKY\ProductBundle\Services;

use Doctrine\ORM\EntityManager;
use Doctrine\ORM\Query;

use YPKY\ProductBundle\Entity\FormSection;
use YPKY\ProductBundle\Entity\Form;

/**
 * Provides service methods for form sections
 */
class FormService
{
    /**
     * Entity Manager
     */
    private $em;
    
    /**
     * @var unknown
     */
    private $repository;

    public function __construct(EntityManager $em)
    {
        $this->em = $em;
        $this->repository = $em->getRepository('ProductBundle:Form');
    }

    
    /**
     * find Active Forms
     * @return array
     */
    public function findActiveForms()
    {
        return $this->repository->findByStatus(Form::STATUS_ACTIVE);
    }
}