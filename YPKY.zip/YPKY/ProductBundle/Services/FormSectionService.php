<?php

namespace YPKY\ProductBundle\Services;

use Doctrine\ORM\EntityManager;
use Doctrine\ORM\Query;

use YPKY\ProductBundle\Entity\FormSection;
use YPKY\ProductBundle\Entity\Form;

/**
 * Provides service methods for form sections
 */
class FormSectionService
{
    /**
     * Entity Manager
     */
    private $em;

    /** 
     * @var FormElement
     */
    private $formElementService;


    public function __construct(EntityManager $em)
    {
        $this->em = $em;
    }

    /**
     * Set FormElementService
     *  
     * @param FormElementService $service
     */
    public function setFormElementService(FormElementService $service)
    {
        $this->formElementService = $service;
    }

    
    /**
     * Delete FormSection and related FormElements and FormQuestions
     * 
     * @param FormSection $formSection
     * @param string $flush
     * @throws \Exception
     */
    public function deleteByFormSection(FormSection $formSection, $flush = true)
    {
        $hasFormElements = $this->em->getRepository('ProductBundle:FormElement')->findByFormSection($formSection);

        if ($hasFormElements) {
            if ($formSection->getForm()->getStatus() == Form::STATUS_ACTIVE) {
                throw new \Exception('Unable to delete. Active form with questions can not be deleted.');
            }

            $this->formElementService->deleteByFormSection($formSection, false);
        }

        $this->em->remove($formSection);
        
        return $this->em->flush();
    }

}
