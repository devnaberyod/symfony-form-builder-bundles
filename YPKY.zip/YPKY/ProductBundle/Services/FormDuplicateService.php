<?php
/**
 * Form Creation Service Class
 * @description This class is a service to duplicate form and all it's elements
 * @author Diovannie Donayre
 * @created Feb 3 2015
 */
namespace YPKY\ProductBundle\Services;

use Doctrine\ORM\EntityManager;

use YPKY\ProductBundle\Entity\FormSection;
use YPKY\ProductBundle\Entity\Form;
use YPKY\ProductBundle\Entity\FormElement;
use YPKY\ProductBundle\Entity\FormQuestion;

use YPKY\ProductBundle\Exception\FormDuplicateException;
use YPKY\FormBuilderBundle\Services\FormElementRenderConfigParser;

class FormDuplicateService
{
    //Entity manager
    private $em;
    
    /** 
     * @var FormElementRenderConfigParser
     */
    private $renderConfigParser;

    private $currentDateTime;
    private $formQuestionsAdded = array();

    const FORM_NAME_STATE_SEPARATOR = ' - ';

    public function __construct(EntityManager $em)
    {
        $this->em = $em;
        $dateTime = new \DateTime('NOW');
        $this->currentDateTime = $dateTime->format('Y-m-d H:i:s');
    }
    
    public function setRenderConfigParser(FormElementRenderConfigParser $renderConfigParser)
    {
        $this->renderConfigParser = $renderConfigParser;
    }

    /*
        Duplicate FormQuestion Entity
        @param FormQuestion, Form, FormElement Entity
        @return Clone FormQuestion Entity
    */
    private function duplicateFormQuestion(FormQuestion $formQuestion, Form $form, FormElement $formElement)
    {
        $newFormQuestion = clone $formQuestion;
        $newFormQuestion->setForm($form);
        $newFormQuestion->setFormElement($formElement);
        $this->em->persist($newFormQuestion);

        return $newFormQuestion;
    }

    /*
        Duplicate FormSection Entity
        @param Form Entity
        @return array
    */
    private function duplicateFormSectionsByForm(Form $form, $newForm)
    {
        $formSections = $this->em->getRepository('ProductBundle:FormSection')->findByForm($form);

        $formSectionsList = array();

        foreach ($formSections as $each) {
            $newFormSection = clone $each;
            $newFormSection->setForm($newForm);
            $this->em->persist($newFormSection);
            $formSectionsList[$newFormSection->getName()] = $newFormSection;
        }
        
        return $formSectionsList;
    }

    /*
        Duplicate FormElement Entity
        @param FormElement, Form, FormSection Entity
        @return Clone FormElementEntity
    */
    private function duplicateFormElement(FormElement $formElement, Form $form, FormSection $formSection)
    {
        $em = $this->em;
        $newFormElement = clone $formElement;
        $newFormElement->setForm($form);
        $newFormElement->setFormSection($formSection);
        $em->persist($newFormElement);
        //$em->flush();

        return $newFormElement;
    }

   /*
        Duplicate Form and all formelement, formquestion and formsection in a form
        @param Form Entity
   */
    public function duplicateForm(Form $form)
    {
        try {

            $this->em->getConnection()->beginTransaction();

            $formQuestions = $this->em->getRepository('ProductBundle:FormQuestion')
                            ->getFormQuestionsWithFormElementByForm($form);

            $formSections = $this->em->getRepository('ProductBundle:FormSection')->findByForm($form);

            $newForm = clone $form;
            $newForm->setName($form->getName() . ' Copy' . self::FORM_NAME_STATE_SEPARATOR . $this->currentDateTime);
            $newForm->setStatus(Form::STATUS_DRAFT);
            $this->em->persist($newForm);

            $newFormSection = $this->duplicateFormSectionsByForm($form, $newForm);
       
            foreach ($formQuestions as $formQuestion) {
                $formElement = $formQuestion->getFormElement();

                $newFormElement = $this->duplicateFormElement($formElement, $newForm, $newFormSection[$formElement->getFormSection()->getName()]);
                $newFormQuestion = $this->duplicateFormQuestion($formQuestion, $newForm, $newFormElement);

                $renderConfig = $this->renderConfigParser->parse($formElement->getRenderConfig());

                if($renderConfig->getDependentsConfig() || $renderConfig->getParentDependency()) {
                    $this->formQuestionsAdded[$formQuestion->getId()] = $newFormQuestion;
                }
            }

            $this->em->flush();
            $this->em->getConnection()->commit();

            $this->updateFormQuestionsDependencyConfig(); //update all dependencies

            return $newForm->getName();


        } catch(\Exception $e) {
            $this->em->getConnection()->rollback();
            throw $e;
        }

    }

    private function updateFormQuestionsDependencyConfig()
    {
        foreach($this->formQuestionsAdded as $oldFormQuestionId => $formQuestion) {
            
            $jsonRenderConfig = $formQuestion->getFormElement()->getRenderConfig();
            $renderConfig = $this->renderConfigParser->parse($jsonRenderConfig);
            $renderConfigArrayData = json_decode($jsonRenderConfig, true);

            // Update Dependents Config
            if($renderConfig->getDependentsConfig() && count($renderConfig->getDependentsConfig())) {

                foreach($renderConfig->getDependentsConfig() as $key => $eachDependentsConfig) {
 
                    if(is_array($eachDependentsConfig) && isset($eachDependentsConfig['dependents'])) {
                        
                        foreach($eachDependentsConfig['dependents'] as $formQuestionId => $eachConfig) {
                            if((int)$formQuestionId === 0 || !isset($this->formQuestionsAdded[$formQuestionId])) {
                                continue;
                            }

                            $newFormQuestionId = $this->formQuestionsAdded[$formQuestionId]->getId(); 

                            $renderConfigArrayData['dependents_config'][$key]['dependents'][$newFormQuestionId] = $eachConfig;

                            // Remove old config
                            unset($renderConfigArrayData['dependents_config'][$key]['dependents'][$formQuestionId]);
                        }
                    }
                }
            }

            // Update Parent Dependency Config
            if($renderConfig->getParentDependency() && count($renderConfig->getParentDependency())) {
 
                foreach($renderConfig->getParentDependency() as $formQuestionId => $eachParentConfig) {
                    if((int)$formQuestionId === 0 || !isset($this->formQuestionsAdded[$formQuestionId])) {
                        continue;
                    }

                    $newFormQuestionId = $this->formQuestionsAdded[$formQuestionId]->getId();

                    $renderConfigArrayData['parent_dependency'][$newFormQuestionId] = $eachParentConfig;
                    $renderConfigArrayData['parent_dependency'][$newFormQuestionId]['parent_question']['id'] = $newFormQuestionId;

                    // Remove old Config
                    unset($renderConfigArrayData['parent_dependency'][$formQuestionId]);
                }
            }

            $formQuestion->getFormElement()->setRenderConfig(json_encode($renderConfigArrayData));
            $this->em->persist($formQuestion->getFormElement());
        }

        $this->em->flush();
    }
}


