<?php
namespace YPKY\ProductBundle\Repository;

use Doctrine\ORM\EntityRepository;
use YPKY\ProductBundle\Entity\FormSection;
use Doctrine\ORM\Query;
use YPKY\HelperBundle\Classes\QueryHelper;
use Doctrine\ORM\QueryBuilder;

class FormSectionRepository extends EntityRepository
{
    public function save(FormSection $entity)
    {
        $this->_em->persist($entity);
        $this->_em->flush();
    }

    /**
     *
     * @param array $filters
     * @return QueryBuilder
     */
    public function getQueryBuilderWithFilters(array $filters=array())
    {
        $qb = $this->_em->createQueryBuilder();
        $qb->select('fs, f')
            ->from('ProductBundle:FormSection', 'fs')
            ->innerJoin('fs.form', 'f')
            ->where('1=1');

        $knownFilters = array(
        	'form' => $qb->expr()->eq('fs.form', ':form')
        );

        $qb = QueryHelper::applyQueryBuilderFilters($qb, $knownFilters, $filters);

        return $qb;
    }

    /**
     *
     * @param array $filters
     * @param int $hydrationMode
     * @return array
     */
    public function findWithFilters(array $filters=array(), $hydrationMode=Query::HYDRATE_ARRAY)
    {
        $qb = $this->getQueryBuilderWithFilters($filters);
        $qb->orderBy('fs.position', 'ASC');

        return $qb->getQuery()->getResult($hydrationMode);
    }
}