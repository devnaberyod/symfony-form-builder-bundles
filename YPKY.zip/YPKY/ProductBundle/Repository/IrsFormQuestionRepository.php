<?php
namespace YPKY\ProductBundle\Repository;

use YPKY\ProductBundle\Entity\IrsFormQuestion;
use YPKY\ProductBundle\Entity\FormQuestion;

use JMS\Serializer\SerializerBuilder;
use Doctrine\ORM\EntityRepository;
use Doctrine\ORM\Query;

/**
 * IrsFormQuestionRepository
 */
class IrsFormQuestionRepository extends EntityRepository
{
    /**
     * Save and link to FormQuestion IrsFormQuestion
     *
     * @param FormQuestion $formQuestion
     * @param IrsFormQuestion $irsFormQuestion
     */
    public function saveAndLinkToFormQuestion(IrsFormQuestion $irsFormQuestion, FormQuestion $formQuestion)
    {
        $irsFormQuestion->setFormQuestion($formQuestion);

        // Link irsFormQuestion to a formQuestion
        $this->linkToFormQuestion($irsFormQuestion, $formQuestion);

        $this->save($irsFormQuestion);
    }

    /**
     * Save IrsFormQuestion
     *
     * @param IrsFormQuestion $entity
     */
    public function save(IrsFormQuestion $entity)
    {
        $this->_em->persist($entity);
        $this->_em->flush();
    }

    /**
     * Link irsFormQuestion to formQuestion
     *
     * @param IrsFormQuestion $irsFormQuestion
     * @param FormQuestion $formQuestion
     */
    private function linkToFormQuestion(IrsFormQuestion $irsFormQuestion, FormQuestion $formQuestion)
    {
        // Set formQuestion irsFormQuestion
        $formQuestion->setIrsFormQuestion($irsFormQuestion);

        // Update formElement to lock
        $formQuestion->getFormElement()->setIsLocked(true);

        $this->_em->persist($formQuestion);
    }
}
