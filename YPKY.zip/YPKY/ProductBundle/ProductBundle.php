<?php

namespace YPKY\ProductBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ProductBundle extends Bundle
{
}
