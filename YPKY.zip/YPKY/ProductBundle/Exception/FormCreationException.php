<?php
namespace YPKY\ProductBundle\Exception;

class FormCreationException extends \Exception
{
    public static function formNotFound($formName)
    {
        return new self("Form not found: {$formName}");
    }
}