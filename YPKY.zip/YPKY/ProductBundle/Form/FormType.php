<?php

namespace YPKY\ProductBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;
use Symfony\Component\Validator\Constraints\NotBlank;
use YPKY\ProductBundle\Form\FormLinkType;
use Doctrine\ORM\EntityManager;

use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;

class FormType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('name', null, array(
                'constraints' => array(new NotBlank())
            ))
            ->add('irsFormName')
            ->add('wpFormId')
            ->add('description', 'text', array(
                'constraints' => array(new NotBlank())
            ))
            ->add('helpText')
            ->add('videoLink')
            ->add('price')
            ->add('formLinks', 'collection', 
                array(
                    'type' => new FormLinkType(),
                    'allow_add' => true,
                    'allow_delete' => true,
                    // 'prototype' => true,
                    // Post update
                    'by_reference' => false,
                    // 'by_reference' => false
            ))
            ->add('status')
            ->addEventListener(
                FormEvents::PRE_SUBMIT,
                array($this, 'onPreSubmit'))
        ;
    }

    /**
     * @param OptionsResolverInterface $resolver
     */
    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'YPKY\ProductBundle\Entity\Form'
        ));
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'ypky_productbundle_form';
    }
    public function onPreSubmit(FormEvent $event)
    {
        $data = $event->getData();
        
        $form = $event->getForm();

        if (empty($data['formLinks'][0]['link']) && empty($data['formLinks'][0]['title'])) {

            unset($data['formLinks']);
            
            $event->setData($data);

        }
    }
} 