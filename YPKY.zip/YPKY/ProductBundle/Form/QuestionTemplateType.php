<?php

namespace YPKY\ProductBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;
use Symfony\Component\Validator\Constraints\NotBlank;

use Chromedia\WidgetFormBuilderBundle\Form\Transformer\JsonMetadataTransformer;

class QuestionTemplateType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {

        $builder
            ->add('question', 'text', array(
                'label' => 'Question Title on Member forms',
                'constraints' => array(new NotBlank())
            ))
            ->add('name', null, array(
                'constraints' => array(new NotBlank()),
                'label'    => 'Database Name'
            ))
            ->add('subLabel', null, array(
                'required' => false
            ))
            ->add('example', null, array(
               'required' => false,
               'label' => 'Placeholder (Example)'
            ))
            ->add('notes', null, array(
                'required' => false
            ))
            ->add('helpText', null, array(
                'required' => false,
                'attr' => array('class' => 'tinymce')
            ))
            ->add('widgetMetadata', 'chromedia_widget_builder_form_type')
            //->add('status')
        ;
    }

    /**
     * @param OptionsResolverInterface $resolver
     */
    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'YPKY\ProductBundle\Entity\QuestionTemplate'
        ));
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'ypky_productbundle_questiontemplate';
    }
}
