<?php

namespace YPKY\ProductBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;

class QuestionInfoCollectionTypeType extends AbstractType
{
        /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('infoCollectionType')
            ->add('questionTemplate')
        ;
    }
    
    /**
     * @param OptionsResolverInterface $resolver
     */
    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'YPKY\ProductBundle\Entity\QuestionInfoCollectionType'
        ));
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'ypky_productbundle_questioninfocollectiontype';
    }
}
