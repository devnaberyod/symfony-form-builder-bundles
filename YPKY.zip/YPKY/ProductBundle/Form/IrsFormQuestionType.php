<?php 
namespace YPKY\ProductBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;
use Symfony\Component\Validator\Constraints\NotBlank;

class IrsFormQuestionType extends AbstractType
{
    const FORM_NAME = 'irsFormQuestion';
    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('irsSection', 'text' , array(
                'constraints' => array(new NotBlank())
            ))
            ->add('irsQuestion', 'text' , array(
                'constraints' => array(new NotBlank())
            ))
            ->add('irsQuestionNo', 'text' , array(
                'constraints' => array(new NotBlank())
            ))
            ->add('developersNotes', 'textarea');
    }
    /**
     * {@inheritdoc}
     */
    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'YPKY\ProductBundle\Entity\IrsFormQuestion',
        ));
    }

    /**
     * {@inheritdoc}
     */
    public function getName()
    {
        return self::FORM_NAME;
    }
}
