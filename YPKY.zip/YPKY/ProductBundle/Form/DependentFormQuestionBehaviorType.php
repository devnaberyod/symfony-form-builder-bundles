<?php

namespace YPKY\ProductBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;

class DependentFormQuestionBehaviorType extends AbstractType
{
        /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('name')
        ;
    }
    
    /**
     * @param OptionsResolverInterface $resolver
     */
    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'YPKY\ProductBundle\Entity\DependentFormQuestionBehavior'
        ));
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'ypky_productbundle_dependentformquestionbehavior';
    }
}
