<?php 

/*
    CreateFormStatesComplianceCommand Class
    @description This class execute console command for creation of Form States Compliance
    @author Diovannie 
    @created Feb 3 2015
*/

namespace YPKY\ProductBundle\Command;

use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Formatter\OutputFormatterStyle;

use YPKY\ProductBundle\Entity\Form;

class CreateFormStatesComplianceCommand extends ContainerAwareCommand
{
    const FORM_NAME = 'Compliance Unified Registration Form';
     /**
     * @see Command
     */
    protected function configure()
    {
        $this
            ->setDescription('Create a compliance form for each states')
            ->setName('create:formstates:compliance')
            ->setAliases(array('create:formstates:compliance'))
        ;
    }

    /**
     * @see Command
     */
    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $style = new OutputFormatterStyle('red', 'yellow', array('bold', 'blink'));
        $output->getFormatter()->setStyle('fire', $style);
        $output->writeln('<fire>Please wait while creating Compliance form for each states...</fire>');

        //call form creation service form to create form for each states
        $formStatesCompliance = $this->getContainer()->get('product.form_creation_service')->createFormStates(self::FORM_NAME);
        if ($formStatesCompliance) {
            $output->writeln('<info>States Form Compliance successfully created.</info>');
        }
    }

}

