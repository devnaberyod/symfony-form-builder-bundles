<?php
namespace YPKY\ProductBundle\DataFixtures\OrganizationProfile;

use Doctrine\Common\DataFixtures\AbstractFixture;
use Doctrine\Common\DataFixtures\DependentFixtureInterface;
use Doctrine\Common\Persistence\ObjectManager;
use YPKY\ProductBundle\Entity\Form;
use YPKY\ProductBundle\Entity\FormSection;
use YPKY\ProductBundle\Entity\QuestionTemplate;
use YPKY\ProductBundle\Entity\FormQuestion;
use YPKY\ProductBundle\Entity\FormElement;
use YPKY\ProductBundle\Entity\FormElementTypes;
use Symfony\Component\DependencyInjection\ContainerAwareInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
class OrganizationProfileFormData extends AbstractFixture implements DependentFixtureInterface, ContainerAwareInterface
{
    /**
     * @var Form
     */
    private $form;

    /**
     * @var ObjectManager
     */
    private $manager;

    /**
     * @var ContainerInterface
     */
    private $container;

    public function setContainer(ContainerInterface $container=null)
    {
        $this->container = $container;
    }

    public function load(ObjectManager $manager)
    {
        $this->manager = $manager;

        $this->form = new Form();
        $this->form->setDateCreated(new \DateTime('now'));
        $this->form->setDescription('Description');
        $this->form->setHelpText('HelpText');
        $this->form->setName('Basic Company Details');
        $this->form->setStatus(1);

        $page1 = $this->addPageSection();
        $this->addFormQuestions($page1);

        $manager->persist($this->form);
        $manager->flush();

        $this->setReference('ProductBundle:OrganizationProfileForm', $this->form);
    }

    /**
     *
     * @return \YPKY\ProductBundle\Entity\FormSection
     */
    private function addPageSection()
    {
        $page1 = new FormSection();
        $page1->setDescription('Description');
        $page1->setName('Page1');
        $page1->setPosition(1);
        $page1->setForm($this->form);

        $this->manager->persist($page1);

        return $page1;
    }

    private function addFormQuestions(FormSection $page)
    {
        $defaultConfig = $this->container->getParameter('form_builder.default_render_config');
        //$fullRowRenderConfig = $defaultConfig;
        //$halfRowRenderConfig = array_merge($defaultConfig, array('widget_size' => 50));
        //$configWith33WidgetSize = array_merge($defaultConfig, array('widget_size' => 33));

        $questions = array(
        	'org_name' => array(
        	    'renderConfig' => $defaultConfig
        	),
            'care_of_name'=> array(
        	    'renderConfig' => $defaultConfig
        	),
            'mailing_address_1' => array(
        	    'renderConfig' => $defaultConfig
        	),
            'mailing_address_2' => array(
        	    'renderConfig' => $defaultConfig
        	),
            'city'=> array(
        	    'renderConfig' => $defaultConfig
        	),
            'us_state' => array(
        	    'renderConfig' => $defaultConfig
        	),
            'zip' => array(
        	    'renderConfig' => $defaultConfig
        	),
            'office_phone' => array(
        	    'renderConfig' => $defaultConfig
        	),
            'office_fax' => array(
        	    'renderConfig' => $defaultConfig
        	),
            'company_url' => array(
        	    'renderConfig' => $defaultConfig
        	),
            'organization_type' => array(
        	    'renderConfig' => $defaultConfig
        	),
            'organization_logo' => array(
        	    'renderConfig' => $defaultConfig
        	)
        );

        $position = 1;
        foreach ($questions as $questionName => $formElementData) {
        	$questionTemplate = $this->getReference('ProductBundle:OrganizationProfileQuestionTemplate-'.$questionName);

            $this->buildFormQuestionFromQuestionTemplate($page, $questionTemplate, $position, $formElementData);
            $position++;
        }

    }

    public function buildFormQuestionFromQuestionTemplate(FormSection $page, QuestionTemplate $questionTemplate, $position, $formElementData)
    {
        $formElement = new FormElement();
        $formElement->setElementType(FormElementTypes::QUESTION_TEMPLATE);
        $formElement->setForm($this->form);
        $formElement->setFormSection($page);
        $formElement->setParentFormElement(null);
        $formElement->setPosition($position);
        $formElement->setRenderConfig(isset($formElementData['renderConfig']) ? json_encode($formElementData['renderConfig']) : '');
        $formElement->setText($questionTemplate->getQuestion());
        $formElement->setWidgetMetadata($questionTemplate->getWidgetMetadata());

        $formQuestion = new FormQuestion();
        $formQuestion->setExample($questionTemplate->getExample());
        $formQuestion->setForm($this->form);
        $formQuestion->setFormElement($formElement);
        $formQuestion->setHelpText($questionTemplate->getHelpText());
        $formQuestion->setName($questionTemplate->getName());
        $formQuestion->setNotes($questionTemplate->getNotes());
        $formQuestion->setQuestion($questionTemplate->getQuestion());
        $formQuestion->setQuestionTemplate($questionTemplate);


        $this->manager->persist($formElement);
        $this->manager->persist($formQuestion);
    }



    public function getDependencies()
    {
        return array(
            'YPKY\ProductBundle\DataFixtures\OrganizationProfile\OrganizationProfileQuestionTemplateData'
        );
    }
}