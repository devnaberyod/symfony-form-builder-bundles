<?php
namespace YPKY\ProductBundle\DataFixtures\OrganizationProfile;

use Doctrine\Common\DataFixtures\AbstractFixture;
use Doctrine\Common\Persistence\ObjectManager;
use YPKY\ProductBundle\Entity\QuestionTemplate;
use Doctrine\Common\DataFixtures\DependentFixtureInterface;
use YPKY\ProductBundle\Entity\QuestionInfoCollectionType;
class OrganizationProfileQuestionTemplateData extends AbstractFixture implements DependentFixtureInterface
{
    /**
     * @var ObjectManager
     */
    private $manager;

    public function getDependencies()
    {
        return array(
            'YPKY\AdminBundle\DataFixtures\StatesOfAmericaData',
            'YPKY\ProductBundle\DataFixtures\InfoCollectionTypeData'
        );
    }

    public function load(ObjectManager $manager)
    {
        $this->manager = $manager;

        $this
            ->addFullOrganizationName()
            ->addCareOfName()
            ->addMailingAddress1()
            ->addMailingAddress2()
            ->addCity()
            ->addState()
            ->addZip()
            ->addOfficePhone()
            ->addOfficeFax()
            ->addCompanyUrl()
            ->addOrganizationType()
            ->addOrganizationLogo()
        ;

        $this->manager->flush();

    }

    private function buildQuestionInfoCollectionType(QuestionTemplate $questionTemplate)
    {
        $questionInfoCollectionType = new QuestionInfoCollectionType();
        $questionInfoCollectionType->setInfoCollectionType($this->getReference('ProductBundle:InfoCollectionType-MemberProfile'));
        $questionInfoCollectionType->setQuestionTemplate($questionTemplate);

        $this->manager->persist($questionInfoCollectionType);
    }

    /**
     *
     * @return \YPKY\ProductBundle\DataFixtures\OrganizationProfile\OrganizationProfileQuestionTemplateData
     */
    private function addFullOrganizationName()
    {
        $question = new QuestionTemplate();
        $question->setName('org_name');
        $question->setQuestion('Full Name of Organization (exactly as it appears in organizing document)');
        $question->setExample('Chromedia Far East, Inc.');
        $question->setHelpText('');
        $question->setNotes('');
        $question->setWidgetMetadata('{"widget_id":"text","widget_choices":[],"widget_attribute":[{"placeholder":"Organization full name"}],"widget_constraints":[{"constraint_id":"not_blank","constraint_options":{"message":"This field is required."}}]}');
        $question->setStatus(1);

        $this->buildQuestionInfoCollectionType($question);

        $this->manager->persist($question);
        $this->addReference('ProductBundle:OrganizationProfileQuestionTemplate-org_name', $question);

        return $this;
    }

    /**
     *
     * @return \YPKY\ProductBundle\DataFixtures\OrganizationProfile\OrganizationProfileQuestionTemplateData
     */
    private function addCareOfName()
    {
        $question = new QuestionTemplate();
        $question->setName('care_of_name');
        $question->setQuestion('Care of Name');
        $question->setExample('Chromedia Far East, Inc.');
        $question->setHelpText('');
        $question->setNotes('');
        $question->setWidgetMetadata('{"widget_id":"text","widget_choices":[],"widget_attribute":[{"placeholder":"Care of Name"}],"widget_constraints":[{"constraint_id":"not_blank","constraint_options":{"message":"Care of name is required."}}]}');
        $question->setStatus(1);

        $this->buildQuestionInfoCollectionType($question);

        $this->manager->persist($question);
        $this->addReference('ProductBundle:OrganizationProfileQuestionTemplate-care_of_name', $question);

        return $this;
    }

    /**
     *
     * @return \YPKY\ProductBundle\DataFixtures\OrganizationProfile\OrganizationProfileQuestionTemplateData
     */
    private function addMailingAddress1()
    {
        $question = new QuestionTemplate();
        $question->setName('mailing_address_1');
        $question->setQuestion('Mailing Address 1');
        $question->setExample('Unit 602 6/F Keppel Business Center');
        $question->setHelpText('');
        $question->setNotes('');
        $question->setWidgetMetadata('{"widget_id":"text","widget_choices":[],"widget_attribute":[{"placeholder":"Mailing Address 1"}],"widget_constraints":[{"constraint_id":"not_blank","constraint_options":{"message":"This field is required."}}]}');
        $question->setStatus(1);

        $this->buildQuestionInfoCollectionType($question);

        $this->manager->persist($question);
        $this->addReference('ProductBundle:OrganizationProfileQuestionTemplate-mailing_address_1', $question);

        return $this;
    }

    /**
     *
     * @return \YPKY\ProductBundle\DataFixtures\OrganizationProfile\OrganizationProfileQuestionTemplateData
     */
    private function addMailingAddress2()
    {
        $question = new QuestionTemplate();
        $question->setName('mailing_address_2');
        $question->setQuestion('Mailing Address 2');
        $question->setExample('Unit 602 6/F Keppel Business Center');
        $question->setHelpText('');
        $question->setNotes('');
        $question->setWidgetMetadata('{"widget_id":"text","widget_choices":[],"widget_attribute":[{"placeholder":"Mailing Address 2"}], "widget_constraints":[]}');
        $question->setStatus(1);

        $this->buildQuestionInfoCollectionType($question);

        $this->manager->persist($question);
        $this->addReference('ProductBundle:OrganizationProfileQuestionTemplate-mailing_address_2', $question);

        return $this;
    }

    /**
     *
     * @return \YPKY\ProductBundle\DataFixtures\OrganizationProfile\OrganizationProfileQuestionTemplateData
     */
    private function addCity()
    {
        $question = new QuestionTemplate();
        $question->setName('city');
        $question->setQuestion('City');
        $question->setExample('Denver');
        $question->setHelpText('');
        $question->setNotes('');
        $question->setWidgetMetadata('{"widget_id":"text","widget_choices":[],"widget_attribute":[{"placeholder":"City"}], "widget_constraints":[{"constraint_id":"not_blank","constraint_options":{"message":"This field is required."}}]}');
        $question->setStatus(1);

        $this->buildQuestionInfoCollectionType($question);

        $this->manager->persist($question);
        $this->addReference('ProductBundle:OrganizationProfileQuestionTemplate-city', $question);

        return $this;
    }

    /**
     *
     * @return \YPKY\ProductBundle\DataFixtures\OrganizationProfile\OrganizationProfileQuestionTemplateData
     */
    private function addState()
    {
        $question = new QuestionTemplate();
        $question->setName('us_state');
        $question->setQuestion('State');
        $question->setExample('Colorado');
        $question->setHelpText('');
        $question->setNotes('');
        $question->setWidgetMetadata('{"widget_id":"ypky_admin_stateChoice","widget_choices":[],"widget_attribute":[{"placeholder":"Please select one"}],"widget_constraints":[{"constraint_id":"not_blank","constraint_options":{"message":"US State is required"}}]}');
        $question->setStatus('1');

        $this->buildQuestionInfoCollectionType($question);

        $this->manager->persist($question);
        $this->addReference('ProductBundle:OrganizationProfileQuestionTemplate-us_state', $question);

        return $this;
    }

    /**
     *
     * @return \YPKY\ProductBundle\DataFixtures\OrganizationProfile\OrganizationProfileQuestionTemplateData
     */
    private function addZip()
    {
        $question = new QuestionTemplate();
        $question->setName('zip');
        $question->setQuestion('Zip');
        $question->setExample('80204');
        $question->setHelpText('');
        $question->setNotes('');
        $question->setWidgetMetadata('{"widget_id":"text","widget_choices":[],"widget_attribute":[{"placeholder":"Zip"}], "widget_constraints":[{"constraint_id":"not_blank","constraint_options":{"message":"This field is required."}}]}');
        $question->setStatus(1);

        $this->buildQuestionInfoCollectionType($question);

        $this->manager->persist($question);
        $this->addReference('ProductBundle:OrganizationProfileQuestionTemplate-zip', $question);

        return $this;
    }

    /**
     *
     * @return \YPKY\ProductBundle\DataFixtures\OrganizationProfile\OrganizationProfileQuestionTemplateData
     */
    private function addOfficePhone()
    {
        $question = new QuestionTemplate();
        $question->setName('office_phone');
        $question->setQuestion('Office Phone');
        $question->setExample('');
        $question->setHelpText('');
        $question->setNotes('');
        $question->setWidgetMetadata('{"widget_id":"text","widget_choices":[],"widget_attribute":[{"placeholder":"555-555-5555"}], "widget_constraints":[{"constraint_id":"not_blank","constraint_options":{"message":"This field is required."}}, {"constraint_id":"regex","constraint_options":{"message":"This value is not valid.", "pattern":"/^\d{3}-\d{3}-\d{4}$/"}}]}');
        $question->setStatus(1);

        $this->buildQuestionInfoCollectionType($question);

        $this->manager->persist($question);
        $this->addReference('ProductBundle:OrganizationProfileQuestionTemplate-office_phone', $question);

        return $this;
    }

    /**
     *
     * @return \YPKY\ProductBundle\DataFixtures\OrganizationProfile\OrganizationProfileQuestionTemplateData
     */
    private function addOfficeFax()
    {
        $question = new QuestionTemplate();
        $question->setName('office_fax');
        $question->setQuestion('Office Fax');
        $question->setExample('');
        $question->setHelpText('');
        $question->setNotes('');
        $question->setWidgetMetadata('{"widget_id":"text","widget_choices":[],"widget_attribute":[{"placeholder":"555-555-5555"}], "widget_constraints":[{"constraint_id":"regex","constraint_options":{"message":"This value is not valid.", "pattern":"/^\d{3}-\d{3}-\d{4}$/"}}]}');
        $question->setStatus(1);

        $this->buildQuestionInfoCollectionType($question);

        $this->manager->persist($question);
        $this->addReference('ProductBundle:OrganizationProfileQuestionTemplate-office_fax', $question);

        return $this;
    }

    /**
     *
     * @return \YPKY\ProductBundle\DataFixtures\OrganizationProfile\OrganizationProfileQuestionTemplateData
     */
    private function addCompanyUrl()
    {
        $question = new QuestionTemplate();
        $question->setName('company_url');
        $question->setQuestion('Company Url');
        $question->setExample('');
        $question->setHelpText('');
        $question->setNotes('');
        $question->setWidgetMetadata('{"widget_id":"text","widget_choices":[],"widget_attribute":[{"placeholder":"Company Url"}], "widget_constraints":[]}');
        $question->setStatus(1);

        $this->buildQuestionInfoCollectionType($question);

        $this->manager->persist($question);
        $this->addReference('ProductBundle:OrganizationProfileQuestionTemplate-company_url', $question);

        return $this;
    }

    /**
     *
     * @return \YPKY\ProductBundle\DataFixtures\OrganizationProfile\OrganizationProfileQuestionTemplateData
     */
    private function addOrganizationType()
    {
        $question = new QuestionTemplate();
        $question->setName('organization_type');
        $question->setQuestion('Organization Type');
        $question->setExample('');
        $question->setHelpText('');
        $question->setNotes('');
        $question->setWidgetMetadata('{"widget_id":"choice","widget_choices":["Type1", "Type2", "Type3"],"widget_attribute":[{"placeholder":"555-555-5555"}], "widget_constraints":[{"constraint_id":"not_blank","constraint_options":{"message":"This field is required."}}]}');
        $question->setStatus(1);

        $this->buildQuestionInfoCollectionType($question);

        $this->manager->persist($question);
        $this->addReference('ProductBundle:OrganizationProfileQuestionTemplate-organization_type', $question);

        return $this;
    }

    /**
     *
     * @return \YPKY\ProductBundle\DataFixtures\OrganizationProfile\OrganizationProfileQuestionTemplateData
     */
    private function addOrganizationLogo()
    {
        $question = new QuestionTemplate();
        $question->setName('organization_logo');
        $question->setQuestion('Organization Logo');
        $question->setExample('');
        $question->setHelpText('');
        $question->setNotes('');
        $question->setWidgetMetadata('{"widget_id":"file","widget_choices":[],"widget_attribute":[{"placeholder":"555-555-5555"}], "widget_constraints":[]}');
        $question->setStatus(1);

        $this->buildQuestionInfoCollectionType($question);

        $this->manager->persist($question);
        $this->addReference('ProductBundle:OrganizationProfileQuestionTemplate-organization_logo', $question);

        return $this;
    }

}