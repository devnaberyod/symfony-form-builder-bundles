<?php
namespace YPKY\ProductBundle\DataFixtures;

use Doctrine\Common\DataFixtures\AbstractFixture;
use Doctrine\Common\DataFixtures\DependentFixtureInterface;
use Doctrine\Common\Persistence\ObjectManager;
use YPKY\ProductBundle\Entity\FormSection;
class Form1FormSectionData extends AbstractFixture implements  DependentFixtureInterface
{
    public function load(ObjectManager $manager)
    {
        $page1 = new FormSection();
        $page1->setForm($this->getReference('ProductBundle:Form-1'));
        $page1->setName('Page 1');
        $page1->setDescription('Form 1 Page 1');
        $page1->setPosition(1);

        $page2 = new FormSection();
        $page2->setForm($this->getReference('ProductBundle:Form-1'));
        $page2->setName('Page 2');
        $page2->setDescription('Form 1 Page 2');
        $page2->setPosition(2);

        $manager->persist($page1);
        $manager->persist($page2);
        $manager->flush();

        $this->addReference('ProductBundle:FormSection-1', $page1);

    }

    public function getDependencies()
    {
        return array(
            'YPKY\ProductBundle\DataFixtures\FormData'
        );
    }
}