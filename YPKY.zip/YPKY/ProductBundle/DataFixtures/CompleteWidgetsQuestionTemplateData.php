<?php
namespace YPKY\ProductBundle\DataFixtures;

use Doctrine\Common\DataFixtures\AbstractFixture;
use Doctrine\Common\DataFixtures\DependentFixtureInterface;
use Doctrine\Common\Persistence\ObjectManager;
use YPKY\ProductBundle\Entity\QuestionTemplate;

class CompleteWidgetsQuestionTemplateData extends AbstractFixture //implements DependentFixtureInterface
{
    public function load(ObjectManager $manager)
    {
        $choiceQuestion = new QuestionTemplate();
        $choiceQuestion->setExample('CQ Example');
        $choiceQuestion->setHelpText('CQ Help Text');
        $choiceQuestion->setName('cq');
        $choiceQuestion->setNotes('cq notes');
        $choiceQuestion->setQuestion('What is CQ Example?');
        $choiceQuestion->setStatus(1);

        $widgetMetadata = '{"widget_id":"choice","widget_choices":["Choice 1","Chioce 2"],"widget_attribute":[{"placeholder":"This field is required"}, {"max_length":"3"}],"widget_constraints":[{"constraint_id":"not_blank","constraint_options":{"message":"This is the notblank"}}]}';
        $choiceQuestion->setWidgetMetadata($widgetMetadata);

        $manager->persist($choiceQuestion);
        $manager->flush();

        $this->addReference('ProductBundle:QuestionTemplate-CompleteWidgets', $choiceQuestion);
    }
}