<?php
namespace YPKY\ProductBundle\DataFixtures;

use Doctrine\Common\DataFixtures\AbstractFixture;
use Doctrine\Common\Persistence\ObjectManager;
use Doctrine\Common\DataFixtures\DependentFixtureInterface;

use YPKY\ProductBundle\Entity\FormQuestion;


class FormQuestionData extends AbstractFixture implements  DependentFixtureInterface
{
    public function load(ObjectManager $manager)
    {
        $fq = new FormQuestion();
        $fq->setQuestion('What is your name?');
        $fq->setName('Name');
        $fq->setExample('Juan dela Cruz Jr.');
        $fq->setNotes('Please input complete name.');
        $fq->setHelpText('First Name, Last Name, Suffix');
        $fq->setIsGlobal(true);

        $fq->setForm($this->getReference('ProductBundle:Form-1'));
        $fq->setFormElement($this->getReference('ProductBundle:FormElement-1'));
        $fq->setQuestionTemplate($this->getReference('ProductBundle:QuestionTemplate-CompleteWidgets'));

        $manager->persist($fq);
        $manager->flush();
    }

    public function getDependencies()
    {
        return array(
            'YPKY\ProductBundle\DataFixtures\FormData',
            'YPKY\ProductBundle\DataFixtures\FormSection1FormElementData',
            'YPKY\ProductBundle\DataFixtures\CompleteWidgetsQuestionTemplateData'
        );
    }
}