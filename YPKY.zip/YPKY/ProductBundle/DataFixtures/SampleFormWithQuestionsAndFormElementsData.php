<?php

use Doctrine\Common\DataFixtures\AbstractFixture;

class SampleFormWithQuestionsAndFormElementsData extends AbstractFixture
{
    public function load(ObjectManager $manager)
    {
        
    }

    // private function getForm()
    // {
    //     return
    // }

    // private function addQuestions()
    // {

    // }

    // private function addQuestionTemplates()
    // {

    // }

    // private function addFormElements()
    // {

    // }
}