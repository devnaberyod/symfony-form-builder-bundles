<?php
namespace YPKY\ProductBundle\DataFixtures;

use Doctrine\Common\DataFixtures\AbstractFixture;
use Doctrine\Common\Persistence\ObjectManager;
use YPKY\ProductBundle\Entity\DependentFormQuestionBehavior;


class DependentFormQuestionBehaviorData extends AbstractFixture
{
    public function load(ObjectManager $manager)
    {
        $behaviors = array('show', 'hide');

        foreach ($behaviors as $behavior) {
            $behaviorEntity = new DependentFormQuestionBehavior();
            $behaviorEntity->setName($behavior);

            $manager->persist($behaviorEntity);

            $this->addReference("ProductBundle:DependentFormQuestionBehavior-$behavior", $behaviorEntity);
            
        }

        $manager->flush();
    }
}