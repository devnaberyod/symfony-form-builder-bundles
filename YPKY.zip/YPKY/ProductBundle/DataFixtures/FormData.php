<?php
namespace YPKY\ProductBundle\DataFixtures;

use Doctrine\Common\DataFixtures\AbstractFixture;
use Doctrine\Common\Persistence\ObjectManager;
use YPKY\ProductBundle\Entity\Form;
class FormData extends AbstractFixture
{
    public function load(ObjectManager $manager)
    {
        $form1 = new Form();
        $form1->setDateCreated(new \DateTime('now'));
        $form1->setDescription('Description Only');
        $form1->setHelpText('Helptext');
        $form1->setName('Form 1');
        $form1->setPrice(100);
        $form1->setVideoLink('');
        $form1->setStatus(0);

        $manager->persist($form1);
        $manager->flush();

        $this->addReference('ProductBundle:Form-1', $form1);
    }
}