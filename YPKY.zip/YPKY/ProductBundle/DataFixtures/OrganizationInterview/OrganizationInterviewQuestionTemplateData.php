<?php
namespace YPKY\ProductBundle\DataFixtures\OrganizationInterview;

use Doctrine\Common\DataFixtures\AbstractFixture;
use Doctrine\Common\Persistence\ObjectManager;
use YPKY\ProductBundle\Entity\QuestionTemplate;
use Doctrine\Common\DataFixtures\DependentFixtureInterface;
use YPKY\ProductBundle\Entity\QuestionInfoCollectionType;


class OrganizationInterviewQuestionTemplateData extends AbstractFixture implements DependentFixtureInterface
{
    /**
     * @var ObjectManager
     */
    private $manager;

    public function getDependencies()
    {
        return array(
            'YPKY\AdminBundle\DataFixtures\StatesOfAmericaData',
            'YPKY\ProductBundle\DataFixtures\InfoCollectionTypeData'
        );
    }

    public function load(ObjectManager $manager)
    {
        $this->manager = $manager;

        // EIN related
        $this
            ->addEinNumberQuestion()
            ->addEnterEinNumber()
            ->addHelpObtainEin()
        ;

        // Incorporation related
        $this
            ->addIncorporatedQuestion()
            ->addDateIncorporated()
            ->addStateIncorporated()
            ->addArticlesOfIncorporation()
            ->addArticlesOfIncorporationFile()
            ->addArticlesOfIncorporationFormLinks()
            ->addAuthorizedRep()
            ->addRepFirmName()
            ->addRepMailingAddress1()
            ->addRepMailingAddress2()
            ->addRepCity()
            ->addRepUsState()
            ->addRepZip()
            ->addRepOfficePhone()
            ->addRepOfficeFax()
        ;

        $this
            ->addLimitedPowerOfAttorney()
            ->addSS4()
            ->addForm2848()
            ->addBudgetRange()
            ->addNumberOfEmployees()
            ->addDigitalSignature()
            ->addMonthAnnualAccountingPeriodEnds()
        ;

        $this->manager->flush();

    }

    private function buildQuestionInfoCollectionType(QuestionTemplate $questionTemplate)
    {
        $questionInfoCollectionType = new QuestionInfoCollectionType();
        $questionInfoCollectionType->setInfoCollectionType($this->getReference('ProductBundle:InfoCollectionType-MemberProfile'));
        $questionInfoCollectionType->setQuestionTemplate($questionTemplate);

        $this->manager->persist($questionInfoCollectionType);
    }

    private function buildQuestionTemplate($properties)
    {
        $question = new QuestionTemplate();
        $question->setName($properties['name']);
        $question->setQuestion($properties['question']);
        $question->setExample($properties['example']);
        $question->setHelpText($properties['help_text']);
        $question->setNotes($properties['notes']);
        $question->setWidgetMetadata($properties['widget_metadata']);
        $question->setStatus($properties['status']);

        $this->buildQuestionInfoCollectionType($question);

        $this->manager->persist($question);
        $this->addReference("ProductBundle:OrganizationInterviewQuestionTemplate-".$properties['name'], $question);
    }

    /**
     *
     * @return \YPKY\ProductBundle\DataFixtures\OrganizationProfile\OrganizationInterviewQuestionTemplateData
     */
    private function addEinNumberQuestion()
    {
        $this->buildQuestionTemplate(array(
            'name'     => 'ein_number_question',
            'question' => 'Does your organization have an EIN Number?',
            'example'  => '',
            'help_text' => '',
            'notes'     => '',
            'status' => 1,
            'widget_metadata' => '{"widget_id":"radio","widget_choices":["Yes", "No"],"widget_attribute":[],"widget_constraints":[{"constraint_id":"not_blank","constraint_options":{"message":"This field is required."}}]}'
        ));

        return $this;
    }

   
    private function addEnterEinNumber()
    {
        $this->buildQuestionTemplate(array(
            'name'     => 'enter_ein',
            'question' => 'Enter EIN',
            'example'  => '',
            'help_text' => '',
            'notes'     => '',
            'status' => 1,
            'widget_metadata' => '{"widget_id":"text","widget_choices":[],"widget_attribute":[{"placeholder":"EIN number"}],"widget_constraints":[{"constraint_id":"not_blank","constraint_options":{"message":"This field is required."}}]}',
        ));

        return $this;
    }


    private function addHelpObtainEin()
    {

        $this->buildQuestionTemplate(array(
            'name'     => 'help_obtain_ein',
            'question' => 'Do you need help obtaining an EIN?',
            'example'  => '',
            'help_text' => 'YKY will obtain at no charge but can ONLY do this if: <p>Customer is over 18</p> <p>Customer is a U.S. Citizen</p>',
            'notes'     => '',
            'status' => 1,
            'widget_metadata' => '{"widget_id":"radio","widget_choices":["Yes", "No"],"widget_attribute":[],"widget_constraints":[]}',
        ));

        return $this;
    }


    private function addIncorporatedQuestion()
    {
        $this->buildQuestionTemplate(array(
            'name'     => 'incorporated_question',
            'question' => 'Has customer already incorporated the nonprofit entity in their home state? (Y/N)',
            'example'  => '',
            'help_text' => '',
            'notes'     => '',
            'status' => 1,
            'widget_metadata' => '{"widget_id":"radio","widget_choices":["Yes", "No"],"widget_attribute":[],"widget_constraints":[]}',
        ));

        return $this;
    }

    private function addDateIncorporated()
    {
        $this->buildQuestionTemplate(array(
            'name'     => 'date_incorporated',
            'question' => 'Date Incorporated',
            'example'  => '',
            'help_text' => '',
            'notes'     => '',
            'status' => 1,
            'widget_metadata' => '{"widget_id":"date", "widget_config_options":[{"widget":"single_text"}], "widget_choices":[],"widget_attribute":[{"data-provide":"datepicker"}],"widget_constraints":[]}',
        ));

        return $this;
    }

    private function addStateIncorporated()
    {
        $this->buildQuestionTemplate(array(
            'name'     => 'state_incorporated',
            'question' => 'State Incorporated',
            'example'  => '',
            'help_text' => '',
            'notes'     => '',
            'status' => 1,
            'widget_metadata' => '{"widget_id":"ypky_admin_stateChoice","widget_choices":[],"widget_attribute":[],"widget_constraints":[]}',
        ));

        return $this;
    }

    private function addArticlesOfIncorporation()
    {
        $this->buildQuestionTemplate(array(
            'name'     => 'articles_of_incorporation',
            'question' => 'Does customer have a copy of their Articles of Incorporation? (Y/N)',
            'example'  => '',
            'help_text' => '',
            'notes'     => '',
            'status' => 1,
            'widget_metadata' => '{"widget_id":"radio","widget_choices":["Yes", "No"],"widget_attribute":[],"widget_constraints":[]}',
        ));

        return $this;
    }

    private function addArticlesOfIncorporationFile()
    {
        $this->buildQuestionTemplate(array(
            'name'     => 'articles_of_incorporation_file',
            'question' => 'Upload Copy',
            'example'  => '',
            'help_text' => '',
            'notes'     => '',
            'status' => 1,
            'widget_metadata' => '{"widget_id":"file","widget_choices":[],"widget_attribute":[],"widget_constraints":[]}',
        ));

        return $this;
    }

    // TODO:
    private function addArticlesOfIncorporationFormLinks()
    {
        return $this;
    }


    private function addAuthorizedRep()
    {
        $this->buildQuestionTemplate(array(
            'name'     => 'authorized_rep',
            'question' => 'Do you have an authorized rep (y/n)?',
            'example'  => '',
            'help_text' => '',
            'notes'     => '',
            'status' => 1,
            'widget_metadata' => '{"widget_id":"radio","widget_choices":["Yes", "No"],"widget_attribute":[],"widget_constraints":[]}',
        ));


        // If yes authorized rep



        // TODO: Digital Signature


        return $this;
       
    }

    private function addRepFirmName()
    {
        $this->buildQuestionTemplate(array(
            'name'     => 'rep_firm_name',
            'question' => 'Firm Name',
            'example'  => '',
            'help_text' => '',
            'notes'     => '',
            'status' => 1,
            'widget_metadata' => '{"widget_id":"text","widget_choices":[],"widget_attribute":[],"widget_constraints":[]}',
        ));

        return $this;
    }

    private function addRepMailingAddress1()
    {
        $this->buildQuestionTemplate(array(
            'name'     => 'rep_mailing_address_1',
            'question' => 'Mailing Address 1',
            'example'  => '',
            'help_text' => '',
            'notes'     => '',
            'status' => 1,
            'widget_metadata' => '{"widget_id":"text","widget_choices":[],"widget_attribute":[],"widget_constraints":[]}',
        ));

        return $this;
    }

    private function addRepMailingAddress2()
    {
        $this->buildQuestionTemplate(array(
            'name'     => 'rep_mailing_address_2',
            'question' => 'Mailing Address 2',
            'example'  => '',
            'help_text' => '',
            'notes'     => '',
            'status' => 1,
            'widget_metadata' => '{"widget_id":"text","widget_choices":[],"widget_attribute":[],"widget_constraints":[]}',
        ));

        return $this;
    }

    private function addRepCity()
    {
        $this->buildQuestionTemplate(array(
            'name'     => 'rep_city',
            'question' => 'City',
            'example'  => '',
            'help_text' => '',
            'notes'     => '',
            'status' => 1,
            'widget_metadata' => '{"widget_id":"text","widget_choices":[],"widget_attribute":[{"placeholder":"City"}], "widget_constraints":[]}',
        ));

        return $this;
    }

    private function addRepUsState()
    {
        $this->buildQuestionTemplate(array(
            'name'     => 'rep_us_state',
            'question' => 'State',
            'example'  => 'Colorado',
            'help_text' => '',
            'notes'     => '',
            'status' => 1,
            'widget_metadata' => '{"widget_id":"ypky_admin_stateChoice","widget_choices":[],"widget_attribute":[{"placeholder":"Please select one"}],"widget_constraints":[]}',
        ));

        return $this;
    }


    private function addRepZip()
    {
        $this->buildQuestionTemplate(array(
            'name'     => 'rep_zip',
            'question' => 'Zip',
            'example'  => '80204',
            'help_text' => '',
            'notes'     => '',
            'status' => 1,
            'widget_metadata' => '{"widget_id":"text","widget_choices":[],"widget_attribute":[{"placeholder":"Zip"}], "widget_constraints":[]}',
        ));

        return $this;
    }

    private function addRepOfficePhone()
    {
        $this->buildQuestionTemplate(array(
            'name'     => 'rep_office_phone',
            'question' => 'Office Phone',
            'example'  => '',
            'help_text' => '',
            'notes'     => '',
            'status' => 1,
            'widget_metadata' => '{"widget_id":"text","widget_choices":[],"widget_attribute":[{"placeholder":"555-555-5555"}], "widget_constraints":[{"constraint_id":"regex","constraint_options":{"message":"This value is not valid.", "pattern":"/^\d{3}-\d{3}-\d{4}$/"}}]}',
        ));

        return $this;
    }

    private function addRepOfficeFax()
    {
        $this->buildQuestionTemplate(array(
            'name'     => 'rep_office_fax',
            'question' => 'Office Fax',
            'example'  => '',
            'help_text' => '',
            'notes'     => '',
            'status' => 1,
            'widget_metadata' => '{"widget_id":"text","widget_choices":[],"widget_attribute":[{"placeholder":"555-555-5555"}], "widget_constraints":[{"constraint_id":"regex","constraint_options":{"message":"This value is not valid.", "pattern":"/^\d{3}-\d{3}-\d{4}$/"}}]}',
        ));

        return $this;
    }

    private function addLimitedPowerOfAttorney()
    {
        $this->buildQuestionTemplate(array(
            'name'     => 'limited_power_of_attorney',
            'question' => 'Limited Power of Attorney',
            'example'  => '',
            'help_text' => '',
            'notes'     => '',
            'status' => 1,
            'widget_metadata' => '{"widget_id":"file","widget_choices":[],"widget_attribute":[], "widget_constraints":[]}',
        ));

        return $this;
    }

    private function addSS4()
    {
        $this->buildQuestionTemplate(array(
            'name'     => 'ss4',
            'question' => 'SS4',
            'example'  => '',
            'help_text' => '',
            'notes'     => '',
            'status' => 1,
            'widget_metadata' => '{"widget_id":"file","widget_choices":[],"widget_attribute":[], "widget_constraints":[]}',
        ));

        return $this;
    }

    private function addForm2848()
    {
        $this->buildQuestionTemplate(array(
            'name'     => 'form_2848',
            'question' => 'Form 2848',
            'example'  => '',
            'help_text' => '',
            'notes'     => '',
            'status' => 1,
            'widget_metadata' => '{"widget_id":"file","widget_choices":[],"widget_attribute":[], "widget_constraints":[]}',
        ));

        return $this;
    }

    private function addBudgetRange()
    {
        $this->buildQuestionTemplate(array(
            'name'     => 'budget_range',
            'question' => 'Budget Range',
            'example'  => '',
            'help_text' => '',
            'notes'     => '',
            'status' => 1,
            'widget_metadata' => '{"widget_id":"choice","widget_choices":["<$1000", "$1000 - $10000", "$10000 - $100000", "$1000000>"],"widget_attribute":[{"placeholder":"Please select one"}],"widget_constraints":[]}',
        ));

        return $this;
    }

    private function addNumberOfEmployees()
    {
        $this->buildQuestionTemplate(array(
            'name'     => 'number_of_employees',
            'question' => 'Number of Employees',
            'example'  => '',
            'help_text' => '',
            'notes'     => '',
            'status' => 1,
            'widget_metadata' => '{"widget_id":"choice","widget_choices":["<100", "100 - 1000", "1000>"],"widget_attribute":[{"placeholder":"Please select one"}],"widget_constraints":[]}',
        ));

        return $this;
    }

    private function addDigitalSignature()
    {
        // TODO

        return $this;
    }

    private function addMonthAnnualAccountingPeriodEnds()
    {
        $this->buildQuestionTemplate(array(
            'name'     => 'month_annual_accounting_period_ends',
            'question' => 'Month the annual accounting period ends',
            'example'  => '',
            'help_text' => '',
            'notes'     => '',
            'status' => 1,
            'widget_metadata' => '{"widget_id":"choice","widget_choices":["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],"widget_attribute":[{"placeholder":"Please select one"}],"widget_constraints":[{"constraint_id":"not_blank","constraint_options":{"message":"This field is required."}}]}'
        ));

        return $this;
    }
}