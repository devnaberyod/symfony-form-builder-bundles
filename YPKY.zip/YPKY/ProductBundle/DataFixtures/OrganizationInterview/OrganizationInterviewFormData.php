<?php
namespace YPKY\ProductBundle\DataFixtures\OrganizationInterview;

use Symfony\Component\DependencyInjection\ContainerAwareInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

use Doctrine\Common\DataFixtures\AbstractFixture;
use Doctrine\Common\DataFixtures\DependentFixtureInterface;
use Doctrine\Common\Persistence\ObjectManager;

use YPKY\ProductBundle\Entity\Form;
use YPKY\ProductBundle\Entity\FormSection;
use YPKY\ProductBundle\Entity\QuestionTemplate;
use YPKY\ProductBundle\Entity\FormQuestion;
use YPKY\ProductBundle\Entity\FormElement;
use YPKY\ProductBundle\Entity\FormElementTypes;


class OrganizationInterviewFormData extends AbstractFixture implements DependentFixtureInterface, ContainerAwareInterface
{
    /**
     * @var Form
     */
    private $form;

    /**
     * @var ObjectManager
     */
    private $manager;

    /**
     * @var ContainerInterface
     */
    private $container;

    public function setContainer(ContainerInterface $container=null)
    {
        $this->container = $container;
    }

    public function load(ObjectManager $manager)
    {
        $this->manager = $manager;

        $this->form = new Form();
        $this->form->setDateCreated(new \DateTime('now'));
        $this->form->setDescription('Description');
        $this->form->setHelpText('HelpText');
        $this->form->setName('Organization Interview');
        $this->form->setStatus(1);

        $page1 = $this->addPageSection();
        $this->addFormQuestions($page1);
        // $this->addFormQuestionDependecies();

        $manager->persist($this->form);
        $manager->flush();

        $this->setReference('ProductBundle:OrganizationInterviewForm', $this->form);
    }

    /**
     *
     * @return \YPKY\ProductBundle\Entity\FormSection
     */
    private function addPageSection()
    {
        $page1 = new FormSection();
        $page1->setDescription('Description');
        $page1->setName('Page1');
        $page1->setPosition(1);
        $page1->setForm($this->form);

        $this->manager->persist($page1);

        return $page1;
    }

    private function addFormQuestions(FormSection $page)
    {
        $questions = $this->getQuestionTemplates();
        $position = 1;

        foreach ($questions as $questionName => $formElementData) {
            $questionTemplate = $this->getReference('ProductBundle:OrganizationInterviewQuestionTemplate-'.$questionName);

            $this->buildFormQuestionFromQuestionTemplate($page, $questionTemplate, $position, $formElementData);
            $position++;
        }

    }

    public function buildFormQuestionFromQuestionTemplate(FormSection $page, QuestionTemplate $questionTemplate, $position, $formElementData)
    {
        $formElement = new FormElement();
        $formElement->setElementType(FormElementTypes::QUESTION_TEMPLATE);
        $formElement->setForm($this->form);
        $formElement->setFormSection($page);
        $formElement->setParentFormElement(null);
        $formElement->setPosition($position);
        $formElement->setRenderConfig(isset($formElementData['renderConfig']) ? json_encode($formElementData['renderConfig']) : '');
        $formElement->setText($questionTemplate->getQuestion());
        $formElement->setWidgetMetadata($questionTemplate->getWidgetMetadata());

        $formQuestion = new FormQuestion();
        $formQuestion->setExample($questionTemplate->getExample());
        $formQuestion->setForm($this->form);
        $formQuestion->setFormElement($formElement);
        $formQuestion->setHelpText($questionTemplate->getHelpText());
        $formQuestion->setName($questionTemplate->getName());
        $formQuestion->setNotes($questionTemplate->getNotes());
        $formQuestion->setQuestion($questionTemplate->getQuestion());
        $formQuestion->setQuestionTemplate($questionTemplate);

        $this->addReference("ProductBundle:OrganizationInterviewFormQuestion-".$questionTemplate->getName(), $formQuestion);

        $this->manager->persist($formElement);
        $this->manager->persist($formQuestion);
    }

    private function getQuestionTemplates()
    {
        $defaultConfig = $this->container->getParameter('form_builder.default_render_config');
        //$fullRowRenderConfig = $defaultConfig;
        //$halfRowRenderConfig = array_merge($defaultConfig, array('widget_size' => 50));
        //$configWith33WidgetSize = array_merge($defaultConfig, array('widget_size' => 33));

        return array(
            'ein_number_question' => array(
                'renderConfig' => $defaultConfig
            ),
           'enter_ein' => array(
                'renderConfig' => $defaultConfig
            ),
            'help_obtain_ein' => array(
                'renderConfig' => $defaultConfig
            ),
            'incorporated_question'  => array(
                'renderConfig' => $defaultConfig
            ),
            'date_incorporated' => array(
                'renderConfig' => $defaultConfig
            ),
            'state_incorporated'  => array(
                'renderConfig' => $defaultConfig
            ),
            'articles_of_incorporation' => array(
                'renderConfig' => $defaultConfig
            ),
            'articles_of_incorporation_file' => array(
                'renderConfig' => $defaultConfig
            ),
            'authorized_rep' => array(
                'renderConfig' => $defaultConfig
            ),
            'rep_firm_name' => array(
                'renderConfig' => $defaultConfig
            ),
            'rep_mailing_address_1' => array(
                'renderConfig' => $defaultConfig
            ),
            'rep_mailing_address_2' => array(
                'renderConfig' => $defaultConfig
            ),
            'rep_city'=> array(
                'renderConfig' => $defaultConfig
            ),
            'rep_us_state' => array(
                'renderConfig' => $defaultConfig
            ),
            'rep_zip' => array(
                'renderConfig' => $defaultConfig
            ),
            'rep_office_phone' => array(
                'renderConfig' => $defaultConfig
            ),
            'rep_office_fax' => array(
                'renderConfig' => $defaultConfig
            ),
            'limited_power_of_attorney' => array(
                'renderConfig' => $defaultConfig
            ),
            'ss4' => array(
                'renderConfig' => $defaultConfig
            ),
            'form_2848' => array(
                'renderConfig' => $defaultConfig
            ),
            'budget_range' => array(
                'renderConfig' => $defaultConfig
            ),
            'number_of_employees' => array(
                'renderConfig' => $defaultConfig
            ),
            "month_annual_accounting_period_ends" => array(
                'renderConfig' => $defaultConfig
            )
        );
    }

    public function getDependencies()
    {
        return array(
            'YPKY\ProductBundle\DataFixtures\OrganizationInterview\OrganizationInterviewQuestionTemplateData'
        );
    }
}