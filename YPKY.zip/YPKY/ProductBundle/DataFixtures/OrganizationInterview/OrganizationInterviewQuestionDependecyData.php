<?php
namespace YPKY\ProductBundle\DataFixtures\OrganizationInterview;

use Doctrine\Common\DataFixtures\AbstractFixture;
use Doctrine\Common\Persistence\ObjectManager;
use Doctrine\Common\DataFixtures\DependentFixtureInterface;
use YPKY\ProductBundle\Entity\FormQuestionDependent;


class OrganizationInterviewQuestionDependecyData extends AbstractFixture implements DependentFixtureInterface
{
    /**
     * @var ObjectManager
     */
    private $manager;

    public function getDependencies()
    {
        return array(
            'YPKY\ProductBundle\DataFixtures\DependentFormQuestionBehaviorData'
        );
    }

    public function load(ObjectManager $manager)
    {
        $this->manager = $manager;

       $this
            ->addEinDependents()
            ->addIncorporatedDependents()
            ->addArticlesOfIncorporationDependents()
            ->addAuthorizedRepDependents()
        ;

        $this->manager->flush();

    }

    private function buildFormQuestionDependent($properties = array())
    {
        $formQuestionDependent = new FormQuestionDependent();
        $formQuestionDependent->setFormQuestion($properties['form_question']);
        $formQuestionDependent->setDependentFormQuestion($properties['dependent_form_question']);
        $formQuestionDependent->setDependentFormQuestionBehavior($properties['behavior']);
        $formQuestionDependent->setEvent($properties['event']);
        $formQuestionDependent->setValue($properties['value']);

        $this->manager->persist($formQuestionDependent);

        return $formQuestionDependent;
    }

    private function addEinDependents()
    {   
        $einNumberQuestion = $this->getReference('ProductBundle:OrganizationInterviewFormQuestion-ein_number_question');
        $event = 'change';

        // If Yes
        $enterEin = $this->getReference('ProductBundle:OrganizationInterviewFormQuestion-enter_ein');
        $yesBehavior = $this->getReference('ProductBundle:DependentFormQuestionBehavior-show');

        $this->buildFormQuestionDependent(array(        
            'event'         => $event,
            'value'         => 'Yes',
            'behavior'      => $yesBehavior,
            'form_question' => $einNumberQuestion,
            'dependent_form_question' => $enterEin
        ));

        // If No
        $helpObtainEin = $this->getReference('ProductBundle:OrganizationInterviewFormQuestion-help_obtain_ein');
        $noBehavior = $this->getReference('ProductBundle:DependentFormQuestionBehavior-hide');

        $this->buildFormQuestionDependent(array(        
            'event'         => $event,
            'value'         => 'No',
            'behavior'      => $noBehavior,
            'form_question' => $einNumberQuestion,
            'dependent_form_question' => $helpObtainEin
        ));


        return $this;
    }

    private function addIncorporatedDependents()
    {
        $incorporatedQuestion = $this->getReference('ProductBundle:OrganizationInterviewFormQuestion-incorporated_question');
        $event = 'change';

        // If No
        $noBehavior = $this->getReference('ProductBundle:DependentFormQuestionBehavior-hide');
        $noReferences = array(
            'date_incorporated',
            'state_incorporated',
            'articles_of_incorporation'
        );

        foreach ($noReferences as $reference) {
            $dependentEntity = $this->getReference("ProductBundle:OrganizationInterviewFormQuestion-$reference");
            $this->buildFormQuestionDependent(array(        
                'event'         => $event,
                'value'         => 'No',
                'behavior'      => $noBehavior,
                'form_question' => $incorporatedQuestion,
                'dependent_form_question' => $dependentEntity
            ));
        }

        // TODO: If Yes

        return $this;
    }

    private function addArticlesOfIncorporationDependents()
    {   
        $incorporatedQuestion = $this->getReference('ProductBundle:OrganizationInterviewFormQuestion-articles_of_incorporation');
        $event = 'change';

        // If Yes
        $dependentEntity = $this->getReference("ProductBundle:OrganizationInterviewFormQuestion-articles_of_incorporation_file");
        $yesBehavior = $this->getReference('ProductBundle:DependentFormQuestionBehavior-show');

        $this->buildFormQuestionDependent(array(        
            'event'         => $event,
            'value'         => 'Yes',
            'behavior'      => $yesBehavior,
            'form_question' => $incorporatedQuestion,
            'dependent_form_question' => $dependentEntity
        ));


        // TODO: IF No
        return $this;
    }

    private function addAuthorizedRepDependents()
    {
        $authorizedRep = $this->getReference('ProductBundle:OrganizationInterviewFormQuestion-authorized_rep');
        $event = 'change';

        // If No
        $yesBehavior = $this->getReference('ProductBundle:DependentFormQuestionBehavior-show');
        $yesReferences = array(
            'rep_firm_name',
            'rep_mailing_address_1',
            'rep_mailing_address_2',
            'rep_city',
            'rep_us_state',
            'rep_zip',
            'rep_office_phone',
            'rep_office_fax'
        );

        foreach ($yesReferences as $reference) {
            $dependentEntity = $this->getReference("ProductBundle:OrganizationInterviewFormQuestion-$reference");
            $this->buildFormQuestionDependent(array(        
                'event'         => $event,
                'value'         => 'No',
                'behavior'      => $yesBehavior,
                'form_question' => $authorizedRep,
                'dependent_form_question' => $dependentEntity
            ));
        }

        return $this;
    }
}