<?php
namespace YPKY\ProductBundle\DataFixtures;

use Doctrine\Common\DataFixtures\AbstractFixture;
use Doctrine\Common\DataFixtures\DependentFixtureInterface;
use Doctrine\Common\Persistence\ObjectManager;

use YPKY\ProductBundle\Entity\FormElement;
use YPKY\ProductBundle\Entity\FormElementTypes;

class FormSection1FormElementData extends AbstractFixture implements  DependentFixtureInterface
{
    public function load(ObjectManager $manager)
    {
        $formSection = $this->getReference('ProductBundle:FormSection-1');

        $element1 = new FormElement();
        $element1->setElementType(FormElementTypes::QUESTION_TEMPLATE);
        $element1->setText('This is form element text.');
        $element1->setPosition(1);
        $element1->setForm($formSection->getForm());
        $element1->setFormSection($formSection);
        $element1->setRenderConfig('Test Configuration');
        $element1->setWidgetMetadata('meta data');

        $element2 = new FormElement();
        $element2->setElementType(FormElementTypes::QUESTION_TEMPLATE);
        $element2->setText('This is form element text.');
        $element2->setPosition(2);
        $element2->setRenderConfig('Test Configuration');
        $element2->setWidgetMetadata('metadata');
        $element2->setParentFormElement($element1);
        $element2->setForm($formSection->getForm());
        $element2->setFormSection($formSection);

        $manager->persist($element1);
        $manager->persist($element2);
        $manager->flush();

        $this->addReference('ProductBundle:FormElement-1', $element1);
    }

    public function getDependencies()
    {
        return array(
            'YPKY\ProductBundle\DataFixtures\Form1FormSectionData'
        );
    }
}