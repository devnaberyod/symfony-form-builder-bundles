<?php
namespace YPKY\ProductBundle\DataFixtures;

use Doctrine\Common\DataFixtures\AbstractFixture;
use Doctrine\Common\Persistence\ObjectManager;
use YPKY\ProductBundle\Entity\InfoCollectionType;
class InfoCollectionTypeData extends AbstractFixture
{
    public function load(ObjectManager $manager)
    {
        $member = new InfoCollectionType();
        $member->setName('Member Profile');
        $member->setStatus(1);

        $manager->persist($member);
        $manager->flush();

        $this->addReference('ProductBundle:InfoCollectionType-MemberProfile', $member);
    }
}