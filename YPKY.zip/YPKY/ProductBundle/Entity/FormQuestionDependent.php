<?php

namespace YPKY\ProductBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * FormQuestionDependent
 */
class FormQuestionDependent
{
    /**
     * @var integer
     */
    private $id;

    /**
     * @var string
     */
    private $event;

    /**
     * @var string
     */
    private $value;

    /**
     * @var \YPKY\ProductBundle\Entity\DependentFormQuestionBehavior
     */
    private $dependentFormQuestionBehavior;

    /**
     * @var \YPKY\ProductBundle\Entity\FormQuestion
     */
    private $formQuestion;

    /**
     * @var \YPKY\ProductBundle\Entity\FormQuestion
     */
    private $dependentFormQuestion;


    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set event
     *
     * @param string $event
     * @return FormQuestionDependent
     */
    public function setEvent($event)
    {
        $this->event = $event;

        return $this;
    }

    /**
     * Get event
     *
     * @return string 
     */
    public function getEvent()
    {
        return $this->event;
    }

    /**
     * Set value
     *
     * @param string $value
     * @return FormQuestionDependent
     */
    public function setValue($value)
    {
        $this->value = $value;

        return $this;
    }

    /**
     * Get value
     *
     * @return string 
     */
    public function getValue()
    {
        return $this->value;
    }

    /**
     * Set dependentFormQuestionBehavior
     *
     * @param \YPKY\ProductBundle\Entity\DependentFormQuestionBehavior $dependentFormQuestionBehavior
     * @return FormQuestionDependent
     */
    public function setDependentFormQuestionBehavior(\YPKY\ProductBundle\Entity\DependentFormQuestionBehavior $dependentFormQuestionBehavior = null)
    {
        $this->dependentFormQuestionBehavior = $dependentFormQuestionBehavior;

        return $this;
    }

    /**
     * Get dependentFormQuestionBehavior
     *
     * @return \YPKY\ProductBundle\Entity\DependentFormQuestionBehavior 
     */
    public function getDependentFormQuestionBehavior()
    {
        return $this->dependentFormQuestionBehavior;
    }

    /**
     * Set formQuestion
     *
     * @param \YPKY\ProductBundle\Entity\FormQuestion $formQuestion
     * @return FormQuestionDependent
     */
    public function setFormQuestion(\YPKY\ProductBundle\Entity\FormQuestion $formQuestion = null)
    {
        $this->formQuestion = $formQuestion;

        return $this;
    }

    /**
     * Get formQuestion
     *
     * @return \YPKY\ProductBundle\Entity\FormQuestion 
     */
    public function getFormQuestion()
    {
        return $this->formQuestion;
    }

    /**
     * Set dependentFormQuestion
     *
     * @param \YPKY\ProductBundle\Entity\FormQuestion $dependentFormQuestion
     * @return FormQuestionDependent
     */
    public function setDependentFormQuestion(\YPKY\ProductBundle\Entity\FormQuestion $dependentFormQuestion = null)
    {
        $this->dependentFormQuestion = $dependentFormQuestion;

        return $this;
    }

    /**
     * Get dependentFormQuestion
     *
     * @return \YPKY\ProductBundle\Entity\FormQuestion 
     */
    public function getDependentFormQuestion()
    {
        return $this->dependentFormQuestion;
    }
}