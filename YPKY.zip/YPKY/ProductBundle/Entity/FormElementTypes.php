<?php
namespace YPKY\ProductBundle\Entity;

final class FormElementTypes
{
    const QUESTION_TEMPLATE = 1;
    
    const HTML_ELEMENT = 2;
}