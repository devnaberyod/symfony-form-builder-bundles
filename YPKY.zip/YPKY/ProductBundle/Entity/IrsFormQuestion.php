<?php

namespace YPKY\ProductBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use JMS\Serializer\Annotation\SerializedName;

/**
 * IrsFormQuestion
 */
class IrsFormQuestion
{
    /**
     * @var integer
     */
    private $id;

    /**
     * @var string
     * @SerializedName("irsSection")
     */
    private $irsSection;

    /**
     * @var string
     * @SerializedName("irsQuestion")
     */
    private $irsQuestion;

    /**
     * @var string
     * @SerializedName("irsQuestionNo")
     */
    private $irsQuestionNo;

    /**
     * @var string
     * @SerializedName("developersNotes")
     */
    private $developersNotes;

    /**
     * @var \Doctrine\Common\Collections\Collection
     * @SerializedName("formQuestions")
     */
    private $formQuestions;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->formQuestions = new \Doctrine\Common\Collections\ArrayCollection();
    }

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set irsSection
     *
     * @param string $irsSection
     * @return IrsFormQuestion
     */
    public function setIrsSection($irsSection)
    {
        $this->irsSection = $irsSection;

        return $this;
    }

    /**
     * Get irsSection
     *
     * @return string 
     */
    public function getIrsSection()
    {
        return $this->irsSection;
    }

    /**
     * Set irsQuestion
     *
     * @param string $irsQuestion
     * @return IrsFormQuestion
     */
    public function setIrsQuestion($irsQuestion)
    {
        $this->irsQuestion = $irsQuestion;

        return $this;
    }

    /**
     * Get irsQuestion
     *
     * @return string 
     */
    public function getIrsQuestion()
    {
        return $this->irsQuestion;
    }

    /**
     * Set irsQuestionNo
     *
     * @param string $irsQuestionNo
     * @return IrsFormQuestion
     */
    public function setIrsQuestionNo($irsQuestionNo)
    {
        $this->irsQuestionNo = $irsQuestionNo;

        return $this;
    }

    /**
     * Get irsQuestionNo
     *
     * @return string 
     */
    public function getIrsQuestionNo()
    {
        return $this->irsQuestionNo;
    }

    /**
     * Set developersNotes
     *
     * @param string $developersNotes
     * @return IrsFormQuestion
     */
    public function setDevelopersNotes($developersNotes)
    {
        $this->developersNotes = $developersNotes;

        return $this;
    }

    /**
     * Get developersNotes
     *
     * @return string 
     */
    public function getDevelopersNotes()
    {
        return $this->developersNotes;
    }

    /**
     * Add formQuestions
     *
     * @param \YPKY\ProductBundle\Entity\FormQuestion $formQuestions
     * @return IrsFormQuestion
     */
    public function addFormQuestion(\YPKY\ProductBundle\Entity\FormQuestion $formQuestions)
    {
        $this->formQuestions[] = $formQuestions;

        return $this;
    }

    /**
     * Remove formQuestions
     *
     * @param \YPKY\ProductBundle\Entity\FormQuestion $formQuestions
     */
    public function removeFormQuestion(\YPKY\ProductBundle\Entity\FormQuestion $formQuestions)
    {
        $this->formQuestions->removeElement($formQuestions);
    }

    /**
     * Get formQuestions
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getFormQuestions()
    {
        return $this->formQuestions;
    }
}
