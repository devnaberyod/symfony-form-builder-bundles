<?php

namespace YPKY\ProductBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * QuestionInfoCollectionType
 */
class QuestionInfoCollectionType
{
    /**
     * @var integer
     */
    private $id;

    /**
     * @var \YPKY\ProductBundle\Entity\InfoCollectionType
     */
    private $infoCollectionType;

    /**
     * @var \YPKY\ProductBundle\Entity\QuestionTemplate
     */
    private $questionTemplate;


    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set infoCollectionType
     *
     * @param \YPKY\ProductBundle\Entity\InfoCollectionType $infoCollectionType
     * @return QuestionInfoCollectionType
     */
    public function setInfoCollectionType(\YPKY\ProductBundle\Entity\InfoCollectionType $infoCollectionType = null)
    {
        $this->infoCollectionType = $infoCollectionType;

        return $this;
    }

    /**
     * Get infoCollectionType
     *
     * @return \YPKY\ProductBundle\Entity\InfoCollectionType 
     */
    public function getInfoCollectionType()
    {
        return $this->infoCollectionType;
    }

    /**
     * Set questionTemplate
     *
     * @param \YPKY\ProductBundle\Entity\QuestionTemplate $questionTemplate
     * @return QuestionInfoCollectionType
     */
    public function setQuestionTemplate(\YPKY\ProductBundle\Entity\QuestionTemplate $questionTemplate = null)
    {
        $this->questionTemplate = $questionTemplate;

        return $this;
    }

    /**
     * Get questionTemplate
     *
     * @return \YPKY\ProductBundle\Entity\QuestionTemplate 
     */
    public function getQuestionTemplate()
    {
        return $this->questionTemplate;
    }
}