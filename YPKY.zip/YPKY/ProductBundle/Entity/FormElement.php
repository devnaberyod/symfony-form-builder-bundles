<?php

namespace YPKY\ProductBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use JMS\Serializer\Annotation\MaxDepth;
use JMS\Serializer\Annotation\SerializedName;

/**
 * FormElement
 */
class FormElement
{
    /**
     * @var integer
     */
    private $id;

    /**
     * @var integer
     * @SerializedName("elementType")
     */
    private $elementType;

    /**
     * @var integer
     * @SerializedName("isHiddenToMember")
     */
    private $isHiddenToMember;

    /**
     * @var integer
     * @SerializedName("isLocked")
     */
    private $isLocked;

    /**
     * @var string
     */
    private $text;


    /**
     * @var string
     * @SerializedName("renderConfig")
     */
    private $renderConfig;

    /**
     * @var string
     * @SerializedName("widgetMetadata")
     */
    private $widgetMetadata;

    /**
     * @var integer
     */
    private $position;

    /**
     * @var \YPKY\ProductBundle\Entity\FormElement
     */
    private $parentFormElement;

    /**
     * @var \YPKY\ProductBundle\Entity\FormSection
     * 
     * @MaxDepth(1)
     * @SerializedName("formSection")
     */
    private $formSection;

    /**
     * @MaxDepth(1)
     * @var \YPKY\ProductBundle\Entity\Form
     */
    private $form;


    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set elementType
     *
     * @param integer $elementType
     * @return FormElement
     */
    public function setElementType($elementType)
    {
        $this->elementType = $elementType;

        return $this;
    }

    /**
     * Get elementType
     *
     * @return integer
     */
    public function getElementType()
    {
        return $this->elementType;
    }

    /**
     * Set isHiddenToMember
     *
     * @param integer $isHiddenToMember
     * @return FormElement
     */
    public function setIsHiddenToMember($isHiddenToMember)
    {
        $this->isHiddenToMember = $isHiddenToMember;

        return $this;
    }

    /**
     * Get isHiddenToMember
     *
     * @return integer
     */
    public function getIsHiddenToMember()
    {
        return $this->isHiddenToMember;
    }

    /**
     * Set isLocked
     *
     * @param integer $isLocked
     * @return FormElement
     */
    public function setIsLocked($isLocked)
    {
        $this->isLocked = $isLocked;

        return $this;
    }

    /**
     * Get isHiddenToMember
     *
     * @return integer
     */
    public function getIsLocked()
    {
        return $this->isLocked;
    }
    /**
     * Set text
     *
     * @param string $text
     * @return FormElement
     */
    public function setText($text)
    {
        $this->text = $text;

        return $this;
    }

    /**
     * Get text
     *
     * @return string
     */
    public function getText()
    {
        return $this->text;
    }

    /**
     * Set renderConfig
     *
     * @param string $renderConfig
     * @return FormElement
     */
    public function setRenderConfig($renderConfig)
    {
        $this->renderConfig = $renderConfig;

        return $this;
    }

    /**
     * Get renderConfig
     *
     * @return string
     */
    public function getRenderConfig()
    {
        return $this->renderConfig;
    }

    /**
     * Set widgetMetadata
     *
     * @param string $widgetMetadata
     * @return FormElement
     */
    public function setWidgetMetadata($widgetMetadata)
    {
        $this->widgetMetadata = $widgetMetadata;

        return $this;
    }

    /**
     * Get widgetMetadata
     *
     * @return string
     */
    public function getWidgetMetadata()
    {
        return $this->widgetMetadata;
    }


    /**
     * Set parentFormElement
     *
     * @param \YPKY\ProductBundle\Entity\FormElement $parentFormElement
     * @return FormElement
     */
    public function setParentFormElement(\YPKY\ProductBundle\Entity\FormElement $parentFormElement = null)
    {
        $this->parentFormElement = $parentFormElement;

        return $this;
    }

    /**
     * Get parentFormElement
     *
     * @return \YPKY\ProductBundle\Entity\FormElement
     */
    public function getParentFormElement()
    {
        return $this->parentFormElement;
    }


    /**
     * Set position
     *
     * @param integer $position
     * @return FormElement
     */
    public function setPosition($position)
    {
        $this->position = $position;

        return $this;
    }

    /**
     * Get position
     *
     * @return integer
     */
    public function getPosition()
    {
        return $this->position;
    }


    /**
     * Set formSection
     *
     * @param \YPKY\ProductBundle\Entity\FormSection $formSection
     * @return FormElement
     */
    public function setFormSection(\YPKY\ProductBundle\Entity\FormSection $formSection = null)
    {
        $this->formSection = $formSection;

        return $this;
    }

    /**
     * Get formSection
     *
     * @return \YPKY\ProductBundle\Entity\FormSection
     */
    public function getFormSection()
    {
        return $this->formSection;
    }


    /**
     * Set form
     *
     * @param \YPKY\ProductBundle\Entity\Form $form
     * @return FormElement
     */
    public function setForm(\YPKY\ProductBundle\Entity\Form $form = null)
    {
        $this->form = $form;

        return $this;
    }

    /**
     * Get form
     *
     * @return \YPKY\ProductBundle\Entity\Form
     */
    public function getForm()
    {
        return $this->form;
    }
    /**
     * @var \YPKY\ProductBundle\Entity\FormQuestion
     *
     * @MaxDepth(1)
     * @SerializedName("formQuestion") 
     */
    private $formQuestion;


    /**
     * Set formQuestion
     *
     * @param \YPKY\ProductBundle\Entity\FormQuestion $formQuestion
     * @return FormElement
     */
    public function setFormQuestion(\YPKY\ProductBundle\Entity\FormQuestion $formQuestion = null)
    {
        $this->formQuestion = $formQuestion;

        return $this;
    }

    /**
     * Get formQuestion
     *
     * @return \YPKY\ProductBundle\Entity\FormQuestion 
     */
    public function getFormQuestion()
    {
        return $this->formQuestion;
    }
    /**
     * @var integer
     */
    private $parentFormElementId;


    /**
     * Set parentFormElementId
     *
     * @param integer $parentFormElementId
     * @return FormElement
     */
    public function setParentFormElementId($parentFormElementId)
    {
        $this->parentFormElementId = $parentFormElementId;

        return $this;
    }

    /**
     * Get parentFormElementId
     *
     * @return integer 
     */
    public function getParentFormElementId()
    {
        return $this->parentFormElementId;
    }
}
