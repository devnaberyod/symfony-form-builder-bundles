<?php

namespace YPKY\ProductBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

use JMS\Serializer\Annotation\MaxDepth;
use JMS\Serializer\Annotation\SerializedName;

/**
 * FormQuestion
 */
class FormQuestion
{
    /**
     * @var integer
     */
    private $id;

    /**
     * @var string
     */
    private $question;

    /**
     * @var string
     */
    private $name;

    /**
     * @var string
     */
    private $example;

    /**
     * @var integer
     * @SerializedName("isGlobal")
     */
    private $isGlobal;

    /**
     * @var string
     */
    private $notes;

    /**
     * @var string
     * @SerializedName("helpText")
     */
    private $helpText;

    /**
     * @var string
     * @SerializedName("subLabel")
     */
    private $subLabel;

    /**
     * @var \YPKY\ProductBundle\Entity\QuestionTemplate
     * 
     * @MaxDepth(1)
     * @SerializedName("questionTemplate")
     */
    private $questionTemplate;

    /**
     * @var \YPKY\ProductBundle\Entity\Form
     * 
     * @MaxDepth(1)
     */
    private $form;

    /**
     * @var \YPKY\ProductBundle\Entity\FormElement
     * 
     * @MaxDepth(1)
     * @SerializedName("formElement")
     */
    private $formElement;

    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set question
     *
     * @param string $question
     * @return FormQuestion
     */
    public function setQuestion($question)
    {
        $this->question = $question;

        return $this;
    }

    /**
     * Get question
     *
     * @return string
     */
    public function getQuestion()
    {
        return $this->question;
    }

    /**
     * Set name
     *
     * @param string $name
     * @return FormQuestion
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set example
     *
     * @param string $example
     * @return FormQuestion
     */
    public function setExample($example)
    {
        $this->example = $example;

        return $this;
    }

    /**
     * Get example
     *
     * @return string
     */
    public function getExample()
    {
        return $this->example;
    }

    /**
     * Set notes
     *
     * @param string $notes
     * @return FormQuestion
     */
    public function setNotes($notes)
    {
        $this->notes = $notes;

        return $this;
    }

    /**
     * Get notes
     *
     * @return string
     */
    public function getNotes()
    {
        return $this->notes;
    }

    /**
     * Set helpText
     *
     * @param string $helpText
     * @return FormQuestion
     */
    public function setHelpText($helpText)
    {
        $this->helpText = $helpText;

        return $this;
    }

    /**
     * Get helpText
     *
     * @return string
     */
    public function getHelpText()
    {
        return $this->helpText;
    }

    /**
     * Set subLabel
     *
     * @param string $subLabel
     * @return FormQuestion
     */
    public function setSubLabel($subLabel)
    {
        $this->subLabel = $subLabel;

        return $this;
    }

    /**
     * Get helpText
     *
     * @return string
     */
    public function getSubLabel()
    {
        return $this->subLabel;
    }

    /**
     * Set questionTemplate
     *
     * @param \YPKY\ProductBundle\Entity\QuestionTemplate $questionTemplate
     * @return FormQuestion
     */
    public function setQuestionTemplate(\YPKY\ProductBundle\Entity\QuestionTemplate $questionTemplate = null)
    {
        $this->questionTemplate = $questionTemplate;

        return $this;
    }

    /**
     * Get questionTemplate
     *
     * @return \YPKY\ProductBundle\Entity\QuestionTemplate
     */
    public function getQuestionTemplate()
    {
        return $this->questionTemplate;
    }

    /**
     * Set form
     *
     * @param \YPKY\ProductBundle\Entity\Form $form
     * @return FormQuestion
     */
    public function setForm(\YPKY\ProductBundle\Entity\Form $form = null)
    {
        $this->form = $form;

        return $this;
    }

    /**
     * Get form
     *
     * @return \YPKY\ProductBundle\Entity\Form
     */
    public function getForm()
    {
        return $this->form;
    }

    /**
     * Set formElement
     *
     * @param \YPKY\ProductBundle\Entity\FormElement $formElement
     * @return FormQuestion
     */
    public function setFormElement(\YPKY\ProductBundle\Entity\FormElement $formElement = null)
    {
        $this->formElement = $formElement;

        return $this;
    }

    /**
     * Get formElement
     *
     * @return \YPKY\ProductBundle\Entity\FormElement
     */
    public function getFormElement()
    {
        return $this->formElement;
    }

    /**
     * Set isGlobal
     *
     * @param integer $isGlobal
     * @return FormQuestion
     */
    public function setIsGlobal($isGlobal)
    {
        $this->isGlobal = $isGlobal;

        return $this;
    }

    /**
     * Get isGlobal
     *
     * @return integer 
     */
    public function getIsGlobal()
    {
        return $this->isGlobal;
    }
    /**
     * @var \YPKY\ProductBundle\Entity\IrsFormQuestion
     */
    private $irsFormQuestion;


    /**
     * Set irsFormQuestion
     *
     * @param \YPKY\ProductBundle\Entity\IrsFormQuestion $irsFormQuestion
     * @return FormQuestion
     */
    public function setIrsFormQuestion(\YPKY\ProductBundle\Entity\IrsFormQuestion $irsFormQuestion = null)
    {
        $this->irsFormQuestion = $irsFormQuestion;

        return $this;
    }

    /**
     * Get irsFormQuestion
     *
     * @return \YPKY\ProductBundle\Entity\IrsFormQuestion 
     */
    public function getIrsFormQuestion()
    {
        return $this->irsFormQuestion;
    }
}
 
