<?php

namespace YPKY\ProductBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

use JMS\Serializer\Annotation\MaxDepth;
use JMS\Serializer\Annotation\SerializedName;

/**
 * Form
 */
class Form
{
    const STATUS_DRAFT = 0;
    const STATUS_ACTIVE = 1;
    const STATUS_INACTIVE = 2;

    /**
     * @var integer
     */
    private $id;

    /**
     * @var string
     * @SerializedName("irsFormName")
     */
    private $irsFormName;

    /**
     * @var string
     * @SerializedName("name")
     */
    private $name;

    /**
     * @var string
     */
    private $description;

    /**
     * @var string
     * @SerializedName("helpText")
     */
    private $helpText;

    /**
     * @var string
     * @SerializedName("videoLink")
     */
    private $videoLink;

     /**
     * @var string
     * @SerializedName("price")
     */
    private $price;


    /**
     * @var \DateTime
     * @SerializedName("dateCreated")
     */
    private $dateCreated;

    /**
     * @var \DateTime
     * @SerializedName("dateModified")
     */
    private $dateModified;

    /**
     * @var integer
     */
    private $status;

    /**
     * @var \Doctrine\Common\Collections\Collection
     * 
     * @SerializedName("formSections")
     */
    private $formSections;

    /**
     * @var \Doctrine\Common\Collections\Collection
     * @SerializedName("formLinks")
     */
    private $formLinks;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->formSections = new \Doctrine\Common\Collections\ArrayCollection();
        $this->formLinks = new \Doctrine\Common\Collections\ArrayCollection();
    }

    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set name
     *
     * @param string $name
     * @return Form
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set description
     *
     * @param string $description
     * @return Form
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Set helpText
     *
     * @param string $helpText
     * @return Form
     */
    public function setHelpText($helpText)
    {
        $this->helpText = $helpText;

        return $this;
    }

    /**
     * Get helpText
     *
     * @return string
     */
    public function getHelpText()
    {
        return $this->helpText;
    }

    /**
     * Set videoLink
     *
     * @param string $videoLink
     * @return Form
     */
    public function setVideoLink($videoLink)
    {
        $this->videoLink = $videoLink;

        return $this;
    }

    /**
     * Get videoLink
     *
     * @return string
     */
    public function getVideoLink()
    {
        return $this->videoLink;
    }

    /**
     * Set price
     *
     * @param string $price
     * @return Form
     */
    public function setPrice($price)
    {
        $this->price = $price;

        return $this;
    }

    /**
     * Get price
     *
     * @return string
     */
    public function getPrice()
    {
        return $this->price;
    }

    /**
     * Set dateCreated
     *
     * @param \DateTime $dateCreated
     * @return Form
     */
    public function setDateCreated($dateCreated)
    {
        $this->dateCreated = $dateCreated;

        return $this;
    }

    /**
     * Get dateCreated
     *
     * @return \DateTime
     */
    public function getDateCreated()
    {
        return $this->dateCreated;
    }

    /**
     * Set dateModified
     *
     * @param \DateTime $dateModified
     * @return Form
     */
    public function setDateModified($dateModified)
    {
        $this->dateModified = $dateModified;

        return $this;
    }

    /**
     * Get dateModified
     *
     * @return \DateTime
     */
    public function getDateModified()
    {
        return $this->dateModified;
    }

    /**
     * Set status
     *
     * @param integer $status
     * @return Form
     */
    public function setStatus($status)
    {
        $this->status = $status;

        return $this;
    }

    /**
     * Get status
     *
     * @return integer
     */
    public function getStatus()
    {
        return $this->status;
    }

    /**
     * Add formLinks
     *
     * @param \YPKY\ProductBundle\Entity\FormLink $formLinks
     * @return Forms
     */
    public function addFormLink(\YPKY\ProductBundle\Entity\FormLink $formLinks)
    {
        $formLinks->setForm($this);

        $this->formLinks[] = $formLinks;

        return $this;
    }

    /**
     * Remove formLinks
     *
     * @param \YPKY\ProductBundle\Entity\FormLink $formLinks
     */
    public function removeFormLink(\YPKY\ProductBundle\Entity\FormLink $formLinks)
    {
        $this->formLinks->removeElement($formLinks);
    }

    /**
     * Get formLinks
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getFormLinks()
    {
        return $this->formLinks;
    }
    
    /**
     * Add formSections
     *
     * @param \YPKY\ProductBundle\Entity\FormSection $formSections
     * @return Form
     */
    public function addFormSection(\YPKY\ProductBundle\Entity\FormSection $formSections)
    {
        $this->formSections[] = $formSections;

        return $this;
    }

    /**
     * Remove formSections
     *
     * @param \YPKY\ProductBundle\Entity\FormSection $formSections
     */
    public function removeFormSection(\YPKY\ProductBundle\Entity\FormSection $formSections)
    {
        $this->formSections->removeElement($formSections);

        return $this;
    }

    /**
     * Get formSections
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getFormSections()
    {
        return $this->formSections;
    }

    /**
     * Set irsFormName
     *
     * @param string $irsFormName
     * @return Form
     */
    public function setIrsFormName($irsFormName)
    {
        $this->irsFormName = $irsFormName;

        return $this;
    }

    /**
     * Get irsFormName
     *
     * @return string 
     */
    public function getIrsFormName()
    {
        return $this->irsFormName;
    }
    /**
     * @var integer
     * @SerializedName("wpFormId")
     */
    private $wpFormId;


    /**
     * Set wpFormId
     *
     * @param integer $wpFormId
     * @return Form
     */
    public function setWpFormId($wpFormId)
    {
        $this->wpFormId = $wpFormId;

        return $this;
    }

    /**
     * Get wpFormId
     *
     * @return integer 
     */
    public function getWpFormId()
    {
        return $this->wpFormId;
    }

    /**
     * @var \Doctrine\Common\Collections\Collection
     * 
     * @MaxDepth(1)
     * @SerializedName("formQuestions")
     */
    private $formQuestions;


    /**
     * Add formQuestions
     *
     * @param \YPKY\ProductBundle\Entity\FormQuestion $formQuestions
     * @return Form
     */
    public function addFormQuestion(\YPKY\ProductBundle\Entity\FormQuestion $formQuestions)
    {
        $this->formQuestions[] = $formQuestions;

        return $this;
    }

    /**
     * Remove formQuestions
     *
     * @param \YPKY\ProductBundle\Entity\FormQuestion $formQuestions
     */
    public function removeFormQuestion(\YPKY\ProductBundle\Entity\FormQuestion $formQuestions)
    {
        $this->formQuestions->removeElement($formQuestions);
    }

    /**
     * Get formQuestions
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getFormQuestions()
    {
        return $this->formQuestions;
    }
    
    public function __toString()
    {
        return $this->name;
    }
}
