<?php

namespace YPKY\ProductBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * FormSection
 */
class FormSection
{
    /**
     * @var integer
     */
    private $id;

    /**
     * @var string
     */
    private $name;

    /**
     * @var string
     */
    private $description;

    /**
     * @var \YPKY\ProductBundle\Entity\Form
     */
    private $form;

    /**
     * @var integer
     */
    private $position;


    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set name
     *
     * @param string $name
     * @return FormSection
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set description
     *
     * @param string $description
     * @return FormSection
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Set form
     *
     * @param \YPKY\ProductBundle\Entity\Form $form
     * @return FormSection
     */
    public function setForm(\YPKY\ProductBundle\Entity\Form $form = null)
    {
        $this->form = $form;

        return $this;
    }

    /**
     * Get form
     *
     * @return \YPKY\ProductBundle\Entity\Form
     */
    public function getForm()
    {
        return $this->form;
    }


    /**
     * Set position
     *
     * @param integer $position
     * @return FormSection
     */
    public function setPosition($position)
    {
        $this->position = $position;

        return $this;
    }

    /**
     * Get position
     *
     * @return integer
     */
    public function getPosition()
    {
        return $this->position;
    }
} 
