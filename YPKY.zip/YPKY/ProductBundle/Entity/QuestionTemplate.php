<?php

namespace YPKY\ProductBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use JMS\Serializer\Annotation\SerializedName;

/**
 * QuestionTemplate
 */
class QuestionTemplate
{
    /**
     * @var integer
     */
    private $id;

    /**
     * @var string
     */
    private $name;

    /**
     * @var string
     */
    private $example;

    /**
     * @var string
     */
    private $notes;

    /**
     * @var string
     * @SerializedName("helpText")
     */
    private $helpText;

    /**
     * @var string
     * @SerializedName("subLabel")
     */
    private $subLabel;

    /**
     * @var string
     */
    private $question;

    /**
     * @var string
     * @SerializedName("widgetMetadata")
     */
    private $widgetMetadata;

    /**
     * @var integer
     */
    private $status;


    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set name
     *
     * @param string $name
     * @return QuestionTemplate
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string 
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set example
     *
     * @param string $example
     * @return QuestionTemplate
     */
    public function setExample($example)
    {
        $this->example = $example;

        return $this;
    }

    /**
     * Get example
     *
     * @return string 
     */
    public function getExample()
    {
        return $this->example;
    }

    /**
     * Set notes
     *
     * @param string $notes
     * @return QuestionTemplate
     */
    public function setNotes($notes)
    {
        $this->notes = $notes;

        return $this;
    }

    /**
     * Get notes
     *
     * @return string 
     */
    public function getNotes()
    {
        return $this->notes;
    }

    /**
     * Set helpText
     *
     * @param string $helpText
     * @return QuestionTemplate
     */
    public function setHelpText($helpText)
    {
        $this->helpText = $helpText;

        return $this;
    }

    /**
     * Get helpText
     *
     * @return string 
     */
    public function getHelpText()
    {
        return $this->helpText;
    }

    /**
     * Set question
     *
     * @param string $question
     * @return QuestionTemplate
     */
    public function setQuestion($question)
    {
        $this->question = $question;

        return $this;
    }

    /**
     * Get question
     *
     * @return string 
     */
    public function getQuestion()
    {
        return $this->question;
    }

    /**
     * Set subLabel
     *
     * @param string $subLabel
     * @return QuestionTemplate
     */
    public function setSubLabel($subLabel)
    {
        $this->subLabel = $subLabel;

        return $this;
    }

    /**
     * Get helpText
     *
     * @return string
     */
    public function getSubLabel()
    {
        return $this->subLabel;
    }

    /**
     * Set widgetMetadata
     *
     * @param string $widgetMetadata
     * @return QuestionTemplate
     */
    public function setWidgetMetadata($widgetMetadata)
    {
        $this->widgetMetadata = $widgetMetadata;

        return $this;
    }

    /**
     * Get widgetMetadata
     *
     * @return string 
     */
    public function getWidgetMetadata()
    {
        return $this->widgetMetadata;
    }

    /**
     * Set status
     *
     * @param integer $status
     * @return QuestionTemplate
     */
    public function setStatus($status)
    {
        $this->status = $status;

        return $this;
    }

    /**
     * Get status
     *
     * @return integer 
     */
    public function getStatus()
    {
        return $this->status;
    }
}
 
