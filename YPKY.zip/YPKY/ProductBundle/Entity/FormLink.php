<?php

namespace YPKY\ProductBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * FormLinks
 */
class FormLink
{
    /**
     * @var integer
     */
    private $id;

    /**
     * @var string
     */
    private $title;

    /**
     * @var integer
     */
    private $link;

    /**
     * @var \YPKY\ProductBundle\Entity\Form
     */
    private $form;


    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set title
     *
     * @param string $title
     * @return FormLinks
     */
    public function setTitle($title)
    {
        $this->title = $title;

        return $this;
    }

    /**
     * Get title
     *
     * @return string 
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * Set link
     *
     * @param integer $link
     * @return FormLinks
     */
    public function setLink($link)
    {
        $this->link = $link;

        return $this;
    }

    /**
     * Get link
     *
     * @return integer 
     */
    public function getLink()
    {
        return $this->link;
    }

    /**
     * Set form
     *
     * @param \YPKY\ProductBundle\Entity\Forms $form
     * @return FormLinks
     */
    public function setForm(\YPKY\ProductBundle\Entity\Form $form)
    {
        $this->form = $form;

        return $this;
    }

    /**
     * Get form
     *
     * @return \YPKY\ProductBundle\Entity\Forms 
     */
    public function getForm()
    {
        return $this->form;
    }
}