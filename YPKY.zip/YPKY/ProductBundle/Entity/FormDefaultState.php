<?php 

namespace YPKY\ProductBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

class FormDefaultState
{
    private $id;

    private $form;
    
    private $state;

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set form
     *
     * @param \YPKY\ProductBundle\Entity\Form $form
     * @return FormDefaultState
     */
    public function setForm(\YPKY\ProductBundle\Entity\Form $form = null)
    {
        $this->form = $form;

        return $this;
    }

    /**
     * Get form
     *
     * @return \YPKY\ProductBundle\Entity\Form 
     */
    public function getForm()
    {
        return $this->form;
    }

    /**
     * Set state
     *
     * @param \YPKY\AdminBundle\Entity\State $state
     * @return FormDefaultState
     */
    public function setState(\YPKY\AdminBundle\Entity\State $state = null)
    {
        $this->state = $state;

        return $this;
    }

    /**
     * Get state
     *
     * @return \YPKY\AdminBundle\Entity\State 
     */
    public function getState()
    {
        return $this->state;
    }
}
