<?php

namespace YPKY\NotificationBundle\Services;

use YPKY\NotificationBundle\Classes\MailerService;
use SendGrid;

/**
 * @author  Farly Taboada
 */
class SendGridMailerService implements MailerService
{

    /**
     * username crendential for sendgrid
     */
    private $username;


    /**
     * password used for the username
     */
    private $password;


    /**
     * sender of email
     */
    private $from;

    private $cc;


    /**
     * 
     * @return self
     */
    public function init($options=array())
    {
        $this->sendgrid = new \SendGrid($this->username, $this->password, $options);

        return $this;
    }


    public function setUsername($username)
    {
        $this->username = $username;

        return $this;
    }

    public function setPassword($password)
    {
        $this->password = $password;

        return $this;
    }

    public function setFrom($from)
    {
        $this->email->setFrom($from);

        return $this;
    }

    public function addTo($to)
    {
        $this->email->addTo($to);

        return $this;
    }


    public function setTos(array $to)
    {
        $this->email->setTos($to);

        return $this;
    }

    public function send()
    {
        $this->sendgrid->send($this->getEmail());

        return $this;
    }

    public function setText($text)
    {
        $this->email->setText($text);

        return $this;
    }

    public function setHtml($html)
    {
        $this->email->setHtml($html);

        return $this;
    }

    public function setSubject($subject)
    {
        $this->email->setSubject($subject);

        return $this;
    }


    public function setEmail(SendGridEmail $email)
    {
        $this->email = $email;

        return $this;
    }

    public function getEmail()
    {
        return $this->email->getObject();
    }

    public function addCc($email)
    {
        $this->email->addCc($email);

        return $this;
    }

    public function setFromName($fromName)
    {
        $this->email->setFromName($fromName);

        return $this;
    }
}