<?php

namespace YPKY\NotificationBundle\Services;

class SendGridEmail
{
    public function init()
    {
        $this->email = new \SendGrid\Email();

        return $this;
    }

    public function addTo($to)
    {
        $this->email->addTo($to);

        return $this;
    }

    public function setTos(array $to)
    {
        $this->email->setTos($to);

        return $this;
    }

    public function setFrom($from)
    {
        $this->email->setFrom($from);

        return $this;
    }

    public function setFromName($fromName)
    {
        $this->email->setFromName($fromName);

        return $this;
    }

    public function setSubject($subject)
    {
        $this->email->setSubject($subject);

        return $this;
    }

    public function setText($text)
    {
        $this->email->setText($text);

        return $this;
    }

    public function setHtml($html)
    {
        $this->email->setHtml($html);

        return $this;
    }

    public function getObject()
    {
        return $this->email;
    }
    
    public function addCc($email)
    {
        $this->email->addTo($email);

        return $this;
    }
}