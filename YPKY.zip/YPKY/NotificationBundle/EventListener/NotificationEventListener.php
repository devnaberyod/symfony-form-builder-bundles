<?php

namespace YPKY\NotificationBundle\EventListener;

use Symfony\Component\Templating\EngineInterface;
use Symfony\Component\Routing\Router;
use Symfony\Component\EventDispatcher\GenericEvent;

use YPKY\NotificationBundle\Classes\MailerService;
use YPKY\HelperBundle\Event\RequestPasswordEvent;
use YPKY\UserBundle\Event\UserEvent;
use YPKY\UserBundle\Event\UserUpdateEvent;
use YPKY\AdminBundle\Event\AdminUserEvent;


// use Symfony\Bundle\TwigBundle\Debug\TimedTwigEngine

class NotificationEventListener
{
    private $emailService;

    public function setMailerService(MailerService $emailService)
    {
        $this->emailService = $emailService;
    }


    public function setRouter(Router $router)
    {
        $this->router = $router;
    }

    public function setTemplating(EngineInterface $templating)
    {
        $this->templating = $templating;
    }

    /**
     * @todo  change
     */
    public function onRequestResetPassword(RequestPasswordEvent $event)
    {
        $token = $event->getToken();

        $user = $token->getUser();

        $data = array(
            'link' => $this->router->generate('member_password_recovery', array('token' => $token->getToken()), true)
        );

        $this->emailService->addTo($user->getEmail())
                           ->setSubject('Reset Password')
                           ->setHtml($this->templating->render('NotificationBundle:Email\User:resetPassword.html.twig', $data))
                           ->send();
    }

    public function onUpdatePassword(UserUpdateEvent $event)
    {
        $user = $event->getUser();

        $data = array(
            'link' => $this->router->generate('member_login', array(), TRUE)
        );

        $this->emailService->addTo($user->getEmail())
                           ->setSubject('Password Changed')
                           ->setHtml($this->templating->render('NotificationBundle:Email\User:changePassword.html.twig', $data))
                           ->send();
    }

    public function onRegistration(UserEvent $event)
    {
        $token = $event->getToken();
        $user = $token->getUser();

        $url = $this->router->generate('member_email_confirmation', array('token' => $token->getToken(), 'user' => 'new'), true);
        $data = array('link' => $url);

        $this->emailService->addTo($user->getEmail())
                           ->setSubject('Email confirmation')
                           ->setHtml($this->templating->render('NotificationBundle:Email\User:emailConfirmation.html.twig', $data))
                           ->send();
    }

    public function onCreateAdmin(AdminUserEvent $event)
    {
        $token = $event->getToken();
        $user = $token->getUser();
        $password = $event->getPassword();

        $data = array(
            'link' => $this->router->generate('admin_user_email_confirmation', array('token' => $token->getToken()), true),
            'password' => $password,
        );

        $this->emailService->addTo($user->getEmail())
                           ->setSubject('Email confirmation')
                           ->setHtml($this->templating->render('NotificationBundle:Email\User:emailConfirmation.html.twig', $data))
                           ->send();
    }
    
    public function onCreateUserFromAdmin(GenericEvent $event)
    {
        $user = $event->getSubject();
        $password = $event->getArgument('password');

        $loginUrl = $this->router->generate('member_login', array(), true);
        $data = array('link' => $loginUrl, 'email' => $user->getEmail(), 'password' => $password);

        $this->emailService->addTo($user->getEmail())
        ->setFromName('Yippiekiyay Nonprofit Solutions')
        ->setSubject('Welcome to Yippiekiyay Nonprofit Solutions!')
        ->setHtml($this->templating->render('NotificationBundle:Email\User:createdFromAdminEmailConfirmation.html.twig', $data))
        ->send();
    }
}