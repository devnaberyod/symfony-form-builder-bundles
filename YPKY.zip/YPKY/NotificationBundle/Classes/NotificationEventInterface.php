<?php

namespace YPKY\NotificationBundle\Classes;

use YPKY\UserBundle\Entity\User;

interface NotificationEventInterface
{
    public function setUser(User $user);
}