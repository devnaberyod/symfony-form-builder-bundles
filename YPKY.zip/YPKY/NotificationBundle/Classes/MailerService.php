<?php
    
namespace YPKY\NotificationBundle\Classes;

interface MailerService 
{
}