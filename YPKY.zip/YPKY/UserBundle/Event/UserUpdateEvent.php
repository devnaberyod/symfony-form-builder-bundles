<?php

namespace YPKY\UserBundle\Event;

use YPKY\UserBundle\Entity\User;
use Symfony\Component\EventDispatcher\Event;

class UserUpdateEvent extends Event
{
    private $user;

    public function setUser(User $user)
    {
        $this->user = $user;

        return $this;
    }

    public function getUser()
    {
        return $this->user;
    }
}