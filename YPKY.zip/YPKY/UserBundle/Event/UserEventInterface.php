<?php


namespace YPKY\UserBundle\Event;
use YPKY\UserBundle\Entity\UserAccessToken;

interface UserEventInterface
{
    public function setToken(UserAccessToken $token);
    public function getToken();
}