<?php

namespace YPKY\UserBundle\Event;

class UserAccessTokenEvent extends UserEvent
{
}