<?php

namespace YPKY\UserBundle\Event;

use YPKY\UserBundle\Event\UserEventInterface;
use YPKY\UserBundle\Entity\UserAccessToken;
use Symfony\Component\EventDispatcher\Event;

class UserEvent extends Event implements UserEventInterface
{
    private $token;

    public function setToken(UserAccessToken $token)
    {
        $this->token = $token;

        return $this;
    }

    public function getToken()
    {
        return $this->token;
    }
}