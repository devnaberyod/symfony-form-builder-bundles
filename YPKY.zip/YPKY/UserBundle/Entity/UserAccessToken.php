<?php

namespace YPKY\UserBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * UserAccessToken
 */
class UserAccessToken implements \YPKY\HelperBundle\Classes\Token
{
    /**
     * @var integer
     */
    private $id;

    /**
     * @var string
     */
    private $token;

    /**
     * @var \DateTime
     */
    private $expiration;

    /**
     * @var \YPKY\UserBundle\Entity\User
     */
    private $user;


    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set token
     *
     * @param string $token
     * @return UserAccessToken
     */
    public function setToken($token)
    {
        $this->token = $token;

        return $this;
    }

    /**
     * Get token
     *
     * @return string 
     */
    public function getToken()
    {
        return $this->token;
    }

    /**
     * Set expiration
     *
     * @param \DateTime $expiration
     * @return UserAccessToken
     */
    public function setExpiration($expiration)
    {
        $this->expiration = $expiration;

        return $this;
    }

    /**
     * Get expiration
     *
     * @return \DateTime 
     */
    public function getExpiration()
    {
        return $this->expiration;
    }

    /**
     * Set user
     *
     * @param \YPKY\UserBundle\Entity\Users $user
     * @return UserAccessToken
     */
    public function setUser(\YPKY\UserBundle\Entity\User $user = null)
    {
        $this->user = $user;

        return $this;
    }

    /**
     * Get user
     *
     * @return \YPKY\UserBundle\Entity\User
     */
    public function getUser()
    {
        return $this->user;
    }
}
