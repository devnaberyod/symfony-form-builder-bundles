<?php

namespace YPKY\UserBundle\Services;

use Doctrine\Bundle\DoctrineBundle\Registry;

/**
 * @author  Farly Taboada
 * @todo Some methods are useless and/or redundant. Please refactor.
 */
class UserTokenService
{
    private $doctrine;

    public function setDoctrine(Registry $registry)
    {
        $this->doctrine = $registry;
    }

    public function update($token)
    {
        $em = $this->doctrine->getManager();

        $em->flush();
    }

    public function save($token)
    {
        $em = $this->doctrine->getManager();

        $em->persist($token);
        $em->flush();
    }

    public function remove($token)
    {
        $em = $this->doctrine->getManager();

        $em->remove($token);
        $em->flush();
    }

    public function findToken($accessToken, $accessKey = null)
    {
        $token = $this->doctrine->getRepository('UserBundle:UserAccessToken')->findActiveToken($accessToken, $accessKey);

        return $token;
    }

    /**
     * extends user access tokens expiration
     * @param string $accessToken token assigned upon login
     * @param integer $lifetime   lifetime of session. in seconds. 
     */
    public function extendExpiration($accessToken, $lifetime)
    {

        //$oneHourInSeconds = 60 * 60;
        //$expirationInHours = $lifetime / $oneHourInSeconds;
        //var_dump($lifetime); exit;

        $intervalSpec = "PT{$lifetime}S";

        $dateInterval = new \DateInterval($intervalSpec);

        // $token = $this->findToken($accessToken);
        $token = $this->doctrine->getRepository('UserBundle:UserAccessToken')->findOneByToken($accessToken);

        $now = new \DateTime();

        if (!is_null($token)) {
            $token->setExpiration($now->add($dateInterval));

            $em = $this->doctrine->getManager();
            $em->flush();
        }
    }

    static function getTokenExpiration()
    {
        $expiration = 24 * 30;

        return $expiration;
    }
}