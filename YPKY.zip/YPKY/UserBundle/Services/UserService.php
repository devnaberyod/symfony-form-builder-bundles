<?php

namespace YPKY\UserBundle\Services;


use YPKY\UserBundle\Classes\PasswordServiceInterface;
use YPKY\UserBundle\Entity\User;

/**
 * @author  Farly Taboada
 */
class UserService
{

    /**
     * Services\PasswordService
     */
    private $passwordService;

    /**
     * Entity\User
     */
    private $user;

    public function __construct()
    {
        $this->user = null;
    }

    public function setPasswordService(PasswordServiceInterface $passwordService)
    {
        $this->passwordService = $passwordService;
    }

    public function setUser(User $user = null)
    {
        if (is_null($user)) {
            $this->user = new User();
        } else {
            $this->user = $user;
        }

        return $this;
    }

    public function setEmail($email)
    {
        $this->user->setEmail($email);

        return $this;
    }

    public function setPassword($password)
    {

        $this->passwordService->setEncoder($this->user);

        $this->user->setPassword($this->passwordService->encode($password, $this->user->getSalt()));

        return $this;
    }

    public function setSalt($salt)
    {
        $this->user->setSalt($salt);

        return $this;
    }

    public function setStatus($status)
    {
        $this->user->setStatus($status);

        return $this;
    }

    public function setDateCreated($dateCreated)
    {
        $this->user->setDateCreated($dateCreated);

        return $this;
    }

    public function getUser()
    {
        return $this->user;
    }
}