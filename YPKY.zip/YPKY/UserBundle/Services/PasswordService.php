<?php

namespace YPKY\UserBundle\Services;

use Symfony\Component\Security\Core\Encoder\EncoderFactory;
/**
 * @author  Farly Tabaoda
 */
class PasswordService implements \YPKY\UserBundle\Classes\PasswordServiceInterface
{
    private $factory;

    const DEFAULT_PASSWORD_LENGTH = 8;
    const PASSWORD_CHARS = 'abcdefghijklmnopqrstuvwxyz1234567890';

    public function __construct(EncoderFactory $factory)
    {
        $this->factory = $factory;
    }

    public function setEncoder($user)
    {
        $this->encoder = $this->factory->getEncoder($user);

        return $this;
    }

    public function encode($password, $salt)
    {
        $password = $this->encoder->encodePassword($password, $salt);

        return $password;
    }
    
    public function generatePassword($length = 0)
    {
        $length = $length ?: self::DEFAULT_PASSWORD_LENGTH;

        return substr(str_shuffle(self::PASSWORD_CHARS), 0, $length);
    }
}