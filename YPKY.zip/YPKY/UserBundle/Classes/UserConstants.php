<?php

namespace YPKY\UserBundle\Classes;

class UserConstants
{
    const ACTIVE = 1;

    const SUSPENDED = 2;
}