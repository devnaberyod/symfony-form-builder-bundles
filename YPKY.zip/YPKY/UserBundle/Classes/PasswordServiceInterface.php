<?php

namespace YPKY\UserBundle\Classes;

interface PasswordServiceInterface
{
    public function encode($password, $salt);
}