<?php
namespace YPKY\UserBundle\DataFixtures;

use Doctrine\Common\DataFixtures\AbstractFixture;
use Doctrine\Common\DataFixtures\DependentFixtureInterface;
use Doctrine\Common\Persistence\ObjectManager;
use YPKY\UserBundle\Entity\User;
use Symfony\Component\DependencyInjection\ContainerAwareInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use YPKY\AdminBundle\Entity\AdminUser;
class AdminUserData extends AbstractFixture implements ContainerAwareInterface
{
    /**
     * @var ContainerInterface
     */
    private $container;

    public function setContainer(ContainerInterface $container = null)
    {
        $this->container = $container;
    }

    public function load(ObjectManager $manager)
    {
        $user = new User();
        $user->setDateCreated(new \DateTime('now'));
        $user->setEmail('admin@chromedia.com');
        $user->setSalt('');
        $user->setStatus(1);

        $passwordService = $this->container->get('user.service.password');
        $passwordService->setEncoder($user);
        $user->setPassword($passwordService->setEncoder($user)->encode('123456', $user->getSalt()));

        $manager->persist($user);
        $manager->flush();

        $adminuser = new AdminUser();
        $adminuser->setUser($user)
        ->setType(1);
        $manager->persist($adminuser);
        $manager->flush();

        $this->addReference('UserBundle:User-AdminUser', $user);
    }
}