<?php

namespace YPKY\UserBundle\EventListener;

use Doctrine\Bundle\DoctrineBundle\Registry;
use YPKY\UserBundle\Event\UserUpdateEvent;

class UserUpdateEventListener
{
    private $doctrine;

    public function setDoctrine(Registry $registry)
    {
        $this->doctrine = $registry;
    }

    public function onUserUpdate(UserUpdateEvent $event)
    {
        $em = $this->doctrine->getManager();

        $user = $event->getUser();

        $em->persist($user);
        $em->flush();
    }
}