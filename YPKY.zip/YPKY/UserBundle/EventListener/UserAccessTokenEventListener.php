<?php

namespace YPKY\UserBundle\EventListener;

use YPKY\UserBundle\Services\UserTokenService;
use YPKY\UserBundle\Event\UserAccessTokenEvent;
use YPKY\UserBundle\Event\UserEventInterface;

use Symfony\Component\HttpKernel\HttpKernelInterface;
use Symfony\Component\HttpKernel\Event\GetResponseEvent;

class UserAccessTokenEventListener
{
    private $userTokenService;

    public function setUserTokenService(UserTokenService $userTokenService)
    {
        $this->userTokenService = $userTokenService;
    }


    public function onExpiredToken(UserAccessTokenEvent $event)
    {
        $token = $event->getToken();

        $this->userTokenService->remove($token);
    }

    public function onNewToken(UserEventInterface $event)
    {
        $token = $event->getToken();

        $this->userTokenService->save($token);
    }

    public function onRemoveToken(UserAccessTokenEvent $event)
    {
        $token = $event->getToken();

        $this->userTokenService->remove($token);
    }

    public function onRequest(GetResponseEvent $event)
    {
        if (HttpKernelInterface::MASTER_REQUEST !== $event->getRequestType()) {
            return;
        }

        $session = $event->getRequest()->getSession();
        $lifetime = $session->getMetadataBag()->getLifetime();

        $lifetime = $lifetime > 0 ? $lifetime : 7200;

        if ($session->has('access_token')) {
            $this->userTokenService->extendExpiration($session->get('access_token'), $lifetime);

            // if (!is_null($token)) {
            //     $this->userTokenService->update($token);
            // }
        }

        return;
    }
}