<?php

namespace YPKY\UserBundle\Security;

/**
 * @author  Farly
 */
interface UserInterface
{

}