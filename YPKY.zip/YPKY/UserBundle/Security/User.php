<?php

namespace YPKY\UserBundle\Security;


/**
 * @author  Farly Taboada
 * 
 * @todo  Please refactor \YPKY\UserBundle\Security\UserInterface maybe unneccessary
 */
class User implements \Symfony\Component\Security\Core\User\UserInterface, \YPKY\UserBundle\Security\UserInterface
{

    private $user;
    private $salt;
    private $roles;
    
    public function __construct(\YPKY\UserBundle\Entity\User $user, $salt, $roles)
    {
        $this->user = $user;
        $this->salt = $salt;
        $this->roles = $roles;
    }

    public function getUsername()
    {
        return $this->user->getEmail();
    }

    public function getPassword()
    {
        return $this->user->getPassword();
    }

    public function getSalt()
    {
        return $this->salt;
    }

    public function getRoles()
    {
        return $this->roles;
    }

    public function getUser()
    {
        return $this->user; 
    }

    public function eraseCredentials()
    {
    }
}