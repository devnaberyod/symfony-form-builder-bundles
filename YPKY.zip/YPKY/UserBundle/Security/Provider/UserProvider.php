<?php


namespace YPKY\UserBundle\Security\Provider;

use Symfony\Component\Security\Core\User\UserProviderInterface;
use Symfony\Component\Security\Core\User\UserInterface;
use Symfony\Component\Security\Core\Exception\BadCredentialsException;
use Symfony\Component\Security\Core\Exception\UsernameNotFoundException;
use Symfony\Component\Security\Core\Exception\UnsupportedUserException;

use Doctrine\ORM\EntityManager;
use YPKY\UserBundle\Security\User;

use YPKY\AdminBundle\Classes\AdminUserConstants;

class UserProvider implements UserProviderInterface
{

    private $entityManager;

    public function __construct(EntityManager $entityManager)
    {
        $this->entityManager = $entityManager;
    }


    public function loadUserByUsername($username)
    {

        $user = $this->entityManager->getRepository('UserBundle:User')->findOneByEmail($username);

        if (is_null($user)) {
           throw new UsernameNotFoundException(
                sprintf('Username "%s" does not exist.', $username)
            );
        }

        $adminUser = $this->entityManager->getRepository('AdminBundle:AdminUser')->findOneByUser($user);
        $member = $this->entityManager->getRepository('MemberBundle:Member')->findOneByUser($user);

         /**
         * @todo  needs improvement. use separate user provider per context.
         */
        $context = '';
        if (is_null($adminUser) && !is_null($member)) {
            $context = 'member';
        } elseif (is_null($member) && !is_null($adminUser)) {
            $context = 'admin';
        }
       
        if ($context === 'admin') {
            if ($user->getStatus() === AdminUserConstants::SUSPENDED) {
                throw new BadCredentialsException("Account is suspended");
            }

            return new User($user, $user->getSalt(), AdminUserConstants::$ROLE[$adminUser->getType()]);
        } elseif ($context === 'member') {
            $user->setMember($member);
            return new User($user, $user->getSalt(), array('ROLE_MEMBER'));
        }        

        throw new UsernameNotFoundException(
            sprintf('Email "%s" does not exist.', $username)
        );
    }

    public function refreshUser(UserInterface $user)
    {
        if (!$user instanceof User) {
            throw new UnsupportedUserException(
                sprintf('Instances of "%s" are not supported.', get_class($user))
            );
        }

        return $this->loadUserByUsername($user->getUsername());
    }

    public function supportsClass($class)
    {
        return $class === 'YPKY\UserBundle\Security\User';
    }
}

