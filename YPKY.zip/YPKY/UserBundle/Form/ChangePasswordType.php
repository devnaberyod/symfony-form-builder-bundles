<?php

namespace YPKY\UserBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;

class ChangePasswordType extends AbstractType
{

    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder->add('password', 'repeated', 
            array(
                'type' => 'password',
                'first_options' => array(
                    'label' => 'Password',
                    'constraints' => array(
                        new \Symfony\Component\Validator\Constraints\NotBlank()
                    ),
                ),
                'second_options' => array(
                    'label' => 'Confrim Password',
                    'constraints' => array(
                        new \Symfony\Component\Validator\Constraints\NotBlank()
                    ),
                ),
                'invalid_message' => 'Passwords did not match'
        ));
    }

    public function getName()
    {
        return 'ypky_change_password';
    }
}
