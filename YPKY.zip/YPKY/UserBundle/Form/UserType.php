<?php

namespace YPKY\UserBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;

class UserType extends AbstractType
{
    private $addPassword;

    public function __construct($addPassword=true)
    {
        $this->addPassword = $addPassword;
    }


    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder->add('email', 'email', 
            array(
                'attr' => array('placeholder' => 'Email Address'),
                'constraints' => array(
                    new \Symfony\Component\Validator\Constraints\NotBlank()
                )
        ));

        if ($this->addPassword) {
            $builder->add('password', 'password');
        }
    }

    /**
     * @param OptionsResolverInterface $resolver
     */
    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'YPKY\UserBundle\Entity\User'
        ));
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'ypky_adminbundle_user';
    }
}
