<?php
namespace YPKY\MemberBundle\DataFixtures;

use Doctrine\Common\DataFixtures\AbstractFixture;
use Doctrine\Common\DataFixtures\DependentFixtureInterface;
use Doctrine\Common\Persistence\ObjectManager;
use Symfony\Component\DependencyInjection\ContainerAwareInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

use YPKY\UserBundle\Entity\User;
use YPKY\MemberBundle\Entity\Member;

class MemberUserData extends AbstractFixture implements ContainerAwareInterface
{
    /**
     * @var ContainerInterface
     */
    private $container;

    public function setContainer(ContainerInterface $container = null)
    {
        $this->container = $container;
    }

    public function load(ObjectManager $manager)
    {
        $user = new User();
        $user->setDateCreated(new \DateTime('now'));
        $user->setEmail('developers.chromedia@gmail.com');
        $user->setSalt('123456');
        $user->setStatus(1);

        $passwordService = $this->container->get('user.service.password');
        $passwordService->setEncoder($user);
        $user->setPassword($passwordService->setEncoder($user)->encode('123456', $user->getSalt()));

        $manager->persist($user);
        $manager->flush();

        $member = new Member();
        $member->setUser($user);

        $manager->persist($member);
        $manager->flush();

        $this->addReference('UserBundle:User-AdminUser', $user);
    }
}