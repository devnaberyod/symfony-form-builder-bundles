<?php

namespace YPKY\MemberBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Member
 */
class Member
{
    /**
     * @var integer
     */
    private $id;

    /**
     * @var \YPKY\UserBundle\Entity\User
     */
    private $user;

    /**
     * @var \YPKY\MemberBundle\Entity\Organization
     */
    private $organization;

    /**
     * @var \YPKY\MemberBundle\Entity\MemberType
     */
    private $memberType;

    /**
     * @var string
     */
    private $name;

    /**
     * @var integer
     */
    private $hasTakenTour;

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set user
     *
     * @param \YPKY\UserBundle\Entity\User $user
     * @return Member
     */
    public function setUser(\YPKY\UserBundle\Entity\User $user = null)
    {
        $this->user = $user;

        return $this;
    }

    /**
     * Get user
     *
     * @return \YPKY\UserBundle\Entity\User 
     */
    public function getUser()
    {
        return $this->user;
    }

    /**
     * Set organization
     *
     * @param \YPKY\MemberBundle\Entity\Organization $organization
     * @return Member
     */
    public function setOrganization(\YPKY\MemberBundle\Entity\Organization $organization = null)
    {
        $this->organization = $organization;

        return $this;
    }

    /**
     * Get organization
     *
     * @return \YPKY\MemberBundle\Entity\Organization 
     */
    public function getOrganization()
    {
        return $this->organization;
    }

    /**
     * Set memberType
     *
     * @param \YPKY\MemberBundle\Entity\MemberType $memberType
     * @return Member
     */
    public function setMemberType(\YPKY\MemberBundle\Entity\MemberType $memberType = null)
    {
        $this->memberType = $memberType;

        return $this;
    }

    /**
     * Get memberType
     *
     * @return \YPKY\MemberBundle\Entity\MemberType 
     */
    public function getMemberType()
    {
        return $this->memberType;
    }

    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    public function getName()
    {
        return $this->name;
    }

    /**
     * Set hasTakenTour
     *
     * @param integer $hasTakenTour
     * @return Member
     */
    public function setHasTakenTour($hasTakenTour)
    {
        $this->hasTakenTour = $hasTakenTour;

        return $this;
    }

    /**
     * Get hasTakenTour
     *
     * @return integer 
     */
    public function getHasTakenTour()
    {
        return $this->hasTakenTour;
    }
}
