<?php

namespace YPKY\MemberBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * MemberFormPermission
 */
class MemberFormPermission
{
    /**
     * @var integer
     */
    private $id;

    /**
     * @var \YPKY\MemberBundle\Entity\MemberForm
     */
    private $memberForm;

    /**
     * @var \YPKY\MemberBundle\Entity\Member
     */
    private $member;


    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set memberForm
     *
     * @param \YPKY\MemberBundle\Entity\MemberForm $memberForm
     * @return MemberFormPermission
     */
    public function setMemberForm(\YPKY\MemberBundle\Entity\MemberForm $memberForm = null)
    {
        $this->memberForm = $memberForm;

        return $this;
    }

    /**
     * Get memberForm
     *
     * @return \YPKY\MemberBundle\Entity\MemberForm 
     */
    public function getMemberForm()
    {
        return $this->memberForm;
    }

    /**
     * Set member
     *
     * @param \YPKY\MemberBundle\Entity\Member $member
     * @return MemberFormPermission
     */
    public function setMember(\YPKY\MemberBundle\Entity\Member $member = null)
    {
        $this->member = $member;

        return $this;
    }

    /**
     * Get member
     *
     * @return \YPKY\MemberBundle\Entity\Member 
     */
    public function getMember()
    {
        return $this->member;
    }
}
