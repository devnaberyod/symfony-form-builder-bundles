<?php

namespace YPKY\MemberBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * MemberFormAnswer
 */
class MemberFormAnswer
{
    /**
     * @var integer
     */
    private $id;

    /**
     * @var string
     */
    private $answer;

    /**
     * @var integer
     */
    private $lastEditedBy;

    /**
     * @var \YPKY\ProductBundle\Entity\FormQuestion
     */
    private $formQuestion;

    /**
     * @var \YPKY\MemberBundle\Entity\MemberForm
     */
    private $memberForm;


    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set answer
     *
     * @param string $answer
     * @return MemberFormAnswer
     */
    public function setAnswer($answer)
    {
        $this->answer = $answer;

        return $this;
    }

    /**
     * Get answer
     *
     * @return string 
     */
    public function getAnswer()
    {
        return $this->answer;
    }

    /**
     * Set lastEditedBy
     *
     * @param integer $lastEditedBy
     * @return MemberFormAnswer
     */
    public function setLastEditedBy($lastEditedBy)
    {
        $this->lastEditedBy = $lastEditedBy;

        return $this;
    }

    /**
     * Get lastEditedBy
     *
     * @return integer 
     */
    public function getLastEditedBy()
    {
        return $this->lastEditedBy;
    }

    /**
     * Set formQuestion
     *
     * @param \YPKY\ProductBundle\Entity\FormQuestion $formQuestion
     * @return MemberFormAnswer
     */
    public function setFormQuestion(\YPKY\ProductBundle\Entity\FormQuestion $formQuestion = null)
    {
        $this->formQuestion = $formQuestion;

        return $this;
    }

    /**
     * Get formQuestion
     *
     * @return \YPKY\ProductBundle\Entity\FormQuestion 
     */
    public function getFormQuestion()
    {
        return $this->formQuestion;
    }

    /**
     * Set memberForm
     *
     * @param \YPKY\MemberBundle\Entity\MemberForm $memberForm
     * @return MemberFormAnswer
     */
    public function setMemberForm(\YPKY\MemberBundle\Entity\MemberForm $memberForm = null)
    {
        $this->memberForm = $memberForm;

        return $this;
    }

    /**
     * Get memberForm
     *
     * @return \YPKY\MemberBundle\Entity\MemberForm 
     */
    public function getMemberForm()
    {
        return $this->memberForm;
    }
}
