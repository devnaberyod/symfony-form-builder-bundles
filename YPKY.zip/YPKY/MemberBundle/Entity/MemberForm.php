<?php

namespace YPKY\MemberBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * MemberForm
 */
class MemberForm
{
    /**
     * @var integer
     */
    private $id;

    /**
     * @var integer
     */
    private $currentPage;

    /**
     * @var \DateTime
     */
    private $dateCreated;

    /**
     * @var \DateTime
     */
    private $dateModified;

    /**
     * @var integer
     */
    private $status;

    /**
     * @var \Doctrine\Common\Collections\Collection
     */
    private $memberFormAnswers;

    /**
     * @var \YPKY\MemberBundle\Entity\Member
     */
    private $member;

    /**
     * @var \YPKY\ProductBundle\Entity\Form
     */
    private $form;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->memberFormAnswers = new \Doctrine\Common\Collections\ArrayCollection();
    }

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set currentPage
     *
     * @param integer $currentPage
     * @return MemberForm
     */
    public function setcurrentPage($currentPage)
    {
        $this->currentPage = $currentPage;

        return $this;
    }

    /**
     * Get currentPage
     *
     * @return integer 
     */
    public function getcurrentPage()
    {
        return $this->currentPage;
    }

    /**
     * Set dateCreated
     *
     * @param \DateTime $dateCreated
     * @return MemberForm
     */
    public function setDateCreated($dateCreated)
    {
        $this->dateCreated = $dateCreated;

        return $this;
    }

    /**
     * Get dateCreated
     *
     * @return \DateTime 
     */
    public function getDateCreated()
    {
        return $this->dateCreated;
    }

    /**
     * Set dateModified
     *
     * @param \DateTime $dateModified
     * @return MemberForm
     */
    public function setDateModified($dateModified)
    {
        $this->dateModified = $dateModified;

        return $this;
    }

    /**
     * Get dateModified
     *
     * @return \DateTime 
     */
    public function getDateModified()
    {
        return $this->dateModified;
    }

    /**
     * Set status
     *
     * @param integer $status
     * @return MemberForm
     */
    public function setStatus($status)
    {
        $this->status = $status;

        return $this;
    }

    /**
     * Get status
     *
     * @return integer 
     */
    public function getStatus()
    {
        return $this->status;
    }

    /**
     * Add memberFormAnswers
     *
     * @param \YPKY\MemberBundle\Entity\MemberFormAnswer $memberFormAnswers
     * @return MemberForm
     */
    public function addMemberFormAnswer(\YPKY\MemberBundle\Entity\MemberFormAnswer $memberFormAnswers)
    {
        $this->memberFormAnswers[] = $memberFormAnswers;

        return $this;
    }

    /**
     * Remove memberFormAnswers
     *
     * @param \YPKY\MemberBundle\Entity\MemberFormAnswer $memberFormAnswers
     */
    public function removeMemberFormAnswer(\YPKY\MemberBundle\Entity\MemberFormAnswer $memberFormAnswers)
    {
        $this->memberFormAnswers->removeElement($memberFormAnswers);
    }

    /**
     * Get memberFormAnswers
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getMemberFormAnswers()
    {
        return $this->memberFormAnswers;
    }

    /**
     * Set member
     *
     * @param \YPKY\MemberBundle\Entity\Member $member
     * @return MemberForm
     */
    public function setMember(\YPKY\MemberBundle\Entity\Member $member = null)
    {
        $this->member = $member;

        return $this;
    }

    /**
     * Get member
     *
     * @return \YPKY\MemberBundle\Entity\Member 
     */
    public function getMember()
    {
        return $this->member;
    }

    /**
     * Set form
     *
     * @param \YPKY\ProductBundle\Entity\Form $form
     * @return MemberForm
     */
    public function setForm(\YPKY\ProductBundle\Entity\Form $form = null)
    {
        $this->form = $form;

        return $this;
    }

    /**
     * Get form
     *
     * @return \YPKY\ProductBundle\Entity\Form 
     */
    public function getForm()
    {
        return $this->form;
    }
}
