<?php 

namespace YPKY\MemberBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

class MemberFormQuestionLastActivity
{

    private $id;

    private $formQuestion;

    private $member;

    private $dateCreated;


    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set dateCreated
     *
     * @param \DateTime $dateCreated
     * @return MemberFormQuestionLastActivity
     */
    public function setDateCreated($dateCreated)
    {
        $this->dateCreated = $dateCreated;

        return $this;
    }

    /**
     * Get dateCreated
     *
     * @return \DateTime 
     */
    public function getDateCreated()
    {
        return $this->dateCreated;
    }

    /**
     * Set formQuestion
     *
     * @param \YPKY\ProductBundle\Entity\FormQuestion $formQuestion
     * @return MemberFormQuestionLastActivity
     */
    public function setFormQuestion(\YPKY\ProductBundle\Entity\FormQuestion $formQuestion = null)
    {
        $this->formQuestion = $formQuestion;

        return $this;
    }

    /**
     * Get formQuestion
     *
     * @return \YPKY\ProductBundle\Entity\FormQuestion 
     */
    public function getFormQuestion()
    {
        return $this->formQuestion;
    }

    /**
     * Set member
     *
     * @param \YPKY\MemberBundle\Entity\Member $member
     * @return MemberFormQuestionLastActivity
     */
    public function setMember(\YPKY\MemberBundle\Entity\Member $member = null)
    {
        $this->member = $member;

        return $this;
    }

    /**
     * Get member
     *
     * @return \YPKY\MemberBundle\Entity\Member 
     */
    public function getMember()
    {
        return $this->member;
    }
}
