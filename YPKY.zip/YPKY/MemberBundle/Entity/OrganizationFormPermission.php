<?php

namespace YPKY\MemberBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * OrganizationFormPermission
 */
class OrganizationFormPermission
{
    /**
     * @var integer
     */
    private $id;

    /**
     * @var \DateTime
     */
    private $dateExpiry;

    /**
     * @var \DateTime
     */
    private $dateCreated;

    /**
     * @var \YPKY\ProductBundle\Entity\Form
     */
    private $form;

    /**
     * @var \YPKY\MemberBundle\Entity\Organization
     */
    private $organization;


    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set dateExpiry
     *
     * @param \DateTime $dateExpiry
     * @return OrganizationFormPermission
     */
    public function setDateExpiry($dateExpiry)
    {
        $this->dateExpiry = $dateExpiry;

        return $this;
    }

    /**
     * Get dateExpiry
     *
     * @return \DateTime 
     */
    public function getDateExpiry()
    {
        return $this->dateExpiry;
    }

    /**
     * Set dateCreated
     *
     * @param \DateTime $dateCreated
     * @return OrganizationFormPermission
     */
    public function setDateCreated($dateCreated)
    {
        $this->dateCreated = $dateCreated;

        return $this;
    }

    /**
     * Get dateCreated
     *
     * @return \DateTime 
     */
    public function getDateCreated()
    {
        return $this->dateCreated;
    }

    /**
     * Set form
     *
     * @param \YPKY\ProductBundle\Entity\Form $form
     * @return OrganizationFormPermission
     */
    public function setForm(\YPKY\ProductBundle\Entity\Form $form = null)
    {
        $this->form = $form;

        return $this;
    }

    /**
     * Get form
     *
     * @return \YPKY\ProductBundle\Entity\Form 
     */
    public function getForm()
    {
        return $this->form;
    }

    /**
     * Set organization
     *
     * @param \YPKY\MemberBundle\Entity\Organization $organization
     * @return OrganizationFormPermission
     */
    public function setOrganization(\YPKY\MemberBundle\Entity\Organization $organization = null)
    {
        $this->organization = $organization;

        return $this;
    }

    /**
     * Get organization
     *
     * @return \YPKY\MemberBundle\Entity\Organization 
     */
    public function getOrganization()
    {
        return $this->organization;
    }
}
