<?php

namespace YPKY\MemberBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * GlobalMemberAnswer
 */
class GlobalMemberAnswer
{
    /**
     * @var integer
     */
    private $id;

    /**
     * @var string
     */
    private $answer;

    /**
     * @var \YPKY\ProductBundle\Entity\QuestionTemplate
     */
    private $questionTemplate;

    /**
     * @var \YPKY\MemberBundle\Entity\Member
     */
    private $member;


    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set answer
     *
     * @param string $answer
     * @return GlobalMemberAnswer
     */
    public function setAnswer($answer)
    {
        $this->answer = $answer;

        return $this;
    }

    /**
     * Get answer
     *
     * @return string 
     */
    public function getAnswer()
    {
        return $this->answer;
    }

    /**
     * Set questionTemplate
     *
     * @param \YPKY\ProductBundle\Entity\QuestionTemplate $questionTemplate
     * @return GlobalMemberAnswer
     */
    public function setQuestionTemplate(\YPKY\ProductBundle\Entity\QuestionTemplate $questionTemplate = null)
    {
        $this->questionTemplate = $questionTemplate;

        return $this;
    }

    /**
     * Get questionTemplate
     *
     * @return \YPKY\ProductBundle\Entity\QuestionTemplate 
     */
    public function getQuestionTemplate()
    {
        return $this->questionTemplate;
    }

    /**
     * Set member
     *
     * @param \YPKY\MemberBundle\Entity\Member $member
     * @return GlobalMemberAnswer
     */
    public function setMember(\YPKY\MemberBundle\Entity\Member $member = null)
    {
        $this->member = $member;

        return $this;
    }

    /**
     * Get member
     *
     * @return \YPKY\MemberBundle\Entity\Member 
     */
    public function getMember()
    {
        return $this->member;
    }
}
