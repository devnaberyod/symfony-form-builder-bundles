$(function() {
    //Edit Form Manager Initialization
    var $viewform = $('#edit-form');

    // Initialize Form Question Dependencies
    var config, dependencyParser;
    $('.form-question[data-dependents-config]').each(function(){
        config = $(this).data('dependents-config');
        dependencyParser = new DependencyConfigParser($(this), config);
        dependencyParser.apply();
    });

    //set image in modal
    var source = $('#logo').attr('src');
    $('#logo-img-modal').prop('src', source);

    $(window).on('beforeunload', function(e) {
        // code to execute when browser is closed
        if ((editFormManager.dataChanged) && (editFormManager.clickLink)) {
            return "You are about to close window. You might lose any changes you've made.";
        }
    });

    
    editFormManager.lastFormQuestionWorking = currentFormQuestionWorking;
    //Edit form Manager initialization
    editFormManager.init($viewform);
});
 
