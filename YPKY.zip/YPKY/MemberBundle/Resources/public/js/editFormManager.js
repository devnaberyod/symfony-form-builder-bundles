/*
    Edit Form Manager 
    Using Modular Pattern Object Literal
    by: Diovannie
*/

var editFormManager = (function(self, $) {

    self.form = null; //private property
    self.formInputElements;
    self.formInputRadioElements;
    self.formGlobalInputElements;
    self.globalEditButtons;

    self.currentFormQuestionId;
    self.currentSelectedFormQuestionId;
    self.lastFormQuestionWorking;

    self.pageLinks;

    self.confirmChangesModal;
    self.saveChangesAndContinueBtn;

    self.dataChanged = false;
    self.clickLink = true;
    self.gotoPageUri = null;

    //Initialization Edit Form Manager
    self.init = function(form) {
        self.form = form;

        // set form input elements (input, select, textarea)   
        self.formInputElements = form.find('.fields input, .fields textarea, .fields select');

          // set form all elements (input, select, textarea, radio, checkbox)
        self.formAllElements = form.find('.fields input, .fields textarea, .fields select, input[type="radio"], input[type="checkbox"]');

        // set form input elements (radio)
        self.formInputRadioElements = form.find('input[type="radio"]');

        // set form global input elements
        self.formGlobalInputElements = form.find('.global input, .global select, .global textarea');

        // set global edit buttons
        self.globalEditButtons = form.find('.form-question .global-edit');

        // Modal related elements
        self.confirmChangesModal = $('#confirm-changes-modal');
        self.saveChangesAndContinueBtn = self.confirmChangesModal.find('#continue');
        self.ignoreChangesAndContinueBtn = self.confirmChangesModal.find('#redirect-to-page');

        self.pageLinks = $('a:not("#redirect-to-page, .global-edit, .open-menu, .close-menu")');

        //last form question id container
        self.lastFormQuestionHiddenInput = form.find('input[name="lastFormQuestionWorking"]');

        self.bindFormElementsFunction();
    };

    self.bindFormElementsFunction = function() {
        //Unselect radio button elements
        $.each(self.formInputRadioElements, function() {
            $(this).data('prevstate', $(this).is(':checked'));
        });
        self.formInputRadioElements.click(function() {
            var val = $(this).val();
            var prevState = $(this).data('prevstate');
            $(this).attr('checked', !prevState);
            $(this).parents('.choices:first').find('input[type="radio"]').each(function() {
                $(this).data('prevstate', $(this).is(':checked'));
            });
        })

        // Disabled all global input/select/textarea fields on page load.
        self.formGlobalInputElements.prop('disabled', true);

        self.applyCustomElemAndMultiSelectBlurEvent();

        //last form question element activity highlight
        self.formInputElements.each(function() {
            var formQuestionId;
            var inputType = $(this).attr('type');

            if (inputType == 'checkbox' || inputType == 'radio') {
                formQuestionIdDiv = $(this).closest('.choices, .global-field');
                if (formQuestionIdDiv.data('formquestionid') == self.lastFormQuestionWorking) {
                    formQuestionIdDiv.css('border', '1px solid rgb(7, 47, 252)');
                }
                return;
            }
            formQuestionId = $(this).data('formquestionid');
            if (formQuestionId == self.lastFormQuestionWorking) {
                $(this).css('border', '1px solid rgb(7, 47, 252)');
            }
        });
        
        // Bind change event to form input elements for saving last form question activity(input, select, textarea, checkbox, radio).
        self.formInputElements.change(function(e) {
            self.dataChanged = true;
            self.clickLink = true;

            var inputType = $(this).attr('type');
            var formQuestionId = $(this).data('formquestionid');
            if (inputType == 'checkbox' || inputType == 'radio') {
                formQuestionId = $(this).closest('.choices, .global-field').data('formquestionid');
            }

            self.lastFormQuestionHiddenInput.val(formQuestionId);

            self.currentSelectedFormQuestionId = formQuestionId;
        });

        // Bind blur event to all form global input fields
        var currentElem;
        self.formGlobalInputElements.blur(function(e) {
            if($(this).parents('.form-question:first').find('select').length > 1) {
                return;
            }

            if($(e.target).prop('type').toLowerCase() === 'file') {
                return;
            }

            $(this).prop('disabled', true);
        });


        // Bind click event to all global edit buttons
        self.globalEditButtons.click(function() {
            $(this).parent()
                .removeClass('global').addClass('choices edit-mode')
                .find('input, select, textarea').prop('disabled', false).first().focus();
        });


        // Bind click event to all page links
        self.pageLinks.on('click', function(e) {
            if (self.hasDataChanges()) {
                e.preventDefault();
                self.gotoPageUri = $(this).attr('href');
                self.showConfirmSaveChangesDialog();
            }
        });


        //confirm changes modal on show
        self.confirmChangesModal.on('show.bs.modal', function(e) {
            self.saveChangesAndContinueBtn.on('click', function() {
                self.submitForm();
               });
        });

        //confirm changes modal on hide
        self.confirmChangesModal.on('hide.bs.modal', function(e) {
             self.clickLink = true;
        });

        // Bind form submit event.
        self.form.submit(function() {
            self.clickLink = false;

            //exclude input fields with class exclude-me in form submission
            $(this).find('.fields input, .fields textarea, .fields select').not('.exclude-me').prop('disabled', false);
        });

    };

    self.hasDataChanges = function() {
        return self.dataChanged;
    };

    self.showConfirmSaveChangesDialog = function() {
        self.clickLink = false;
        self.ignoreChangesAndContinueBtn.prop('href', self.gotoPageUri);
        self.confirmChangesModal.modal('show');
    };

    
    // Apply blur event to custom radio/checkbox elements and multiple select element like date.
    self.applyCustomElemAndMultiSelectBlurEvent = function()
    {
        $('body').click(function(e){

            // Disable Radio buttons for global questions.
            var globalRadioEditModeContainer = $('.choices.edit-mode');
            if(globalRadioEditModeContainer.length) {
                var disableRadioElems = true;
                var allElems = globalRadioEditModeContainer.parents('.form-question:first').find('*');
                $.each(allElems, function(){
                    if($(this).get(0) == e.target) {
                        disableRadioElems = false;
                        return;
                    }
                });

                if(disableRadioElems) {
                    globalRadioEditModeContainer
                        .addClass('global').removeClass('choices edit-mode')
                        .find('input:radio, input:checkbox, select').prop('disabled', true);
                }
            }
        });
    };

    self.submitForm = function() {
        self.form
            .attr('action', '?redirect=' + encodeURIComponent(self.gotoPageUri))
            .submit();
    };

    return self;

})(editFormManager || {}, jQuery);