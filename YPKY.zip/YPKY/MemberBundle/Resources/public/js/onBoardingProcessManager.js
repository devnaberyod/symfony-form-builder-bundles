var onBoardingProcessManager = (function(self, $){
	self.form = null;
	self.tabContainer = $('.onboarding-tab-header li');
	self.mainContainer = $('.modal-content');
	self.modal = $('#onboardingModal');
	self.tabContent = $('.tab-content');
	self.btnNext = $('#btn-next-onboarding');
	self.btnPrev = $('#btn-prev-onboarding');
	self.currentStep = 1;
	self.formId = null;
	self.finishedStep = 4;
	self.gotoDashboard = 'dashboard';
	self.alertSaveForm = $('#alert-success');
	self.tab = self.mainContainer.find('a[data-toggle="tab"]');

	//bind on click button next
	self.btnNext.on('click', function() {	
		var nextButton = $(this);
		var currentTab = self.tabContainer.filter('.active').find('a[class="onboarding-step"]');
		self.setFormStep(currentTab);

		if (self.currentStep == 1) {
			self.gotoNextTab();
			self.currentStep++;
			return;
		}
		self.saveFormStep(nextButton);
	});

	//bind on click button previous
	self.btnPrev.on('click', function() {
		self.currentStep = self.currentStep - 1;
		if (self.currentStep == 0) {
			self.currentStep = 1;
		}
		var currentTab = self.tabContainer.filter('.active').prev('li').find('a[data-toggle="tab"]').tab('show');
		self.setFormStep(currentTab);
	});

	//set current form in current tab
	self.setFormStep = function(currentTab) {
		//current tab link data-id same as form id
		formId = $(currentTab).data('id');
		console.log(formId);
		self.form = $('#' + formId);
	};
	//post request on saving form step
	self.saveFormStep = function(nextButton) {
		$.ajax({
			url: 'onboarding-step-save/' + self.currentStep,
			type: 'POST',
			dataType: 'json',
			data: self.form.serialize(),
			beforeSend: function() {nextButton.button('loading')},
			success:function(data) {
				console.log(data);
				if (data.error == 0) {
					self.currentStep++;
					if (self.currentStep > self.finishedStep) {
						window.location.href = self.gotoDashboard;
						return;
					}
					
					self.alertSaveForm.show().addClass('fade in');
					setTimeout(function(){
						self.alertSaveForm.hide();
					}, 2000);
					//got to next tab
					self.gotoNextTab();
					//update step
					
					nextButton.button('reset');
					return;
				}
				alert('Error saving form. Please report this bug.');
			}
		})
	}

	//go to next tab
	self.gotoNextTab = function() {
		var curretTab = self.tabContainer.filter('.active').next('li').find('a[class="onboarding-step"]').tab('show');
	};

	//bind on click on each tab for disabling navigation
	self.tab.on('click', function() {
		// self.currentStep = $(this).data('step');
		return false;
	});

})(onBoardingProcessManager || {}, jQuery);