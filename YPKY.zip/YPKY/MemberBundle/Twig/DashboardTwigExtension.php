<?php 

/**
 * @author Adelbert Silla
 */

namespace YPKY\MemberBundle\Twig;

use Symfony\Component\Security\Core\SecurityContext;
use YPKY\MemberBundle\Services\InternalFormService;
use YPKY\MemberBundle\Services\MemberFormService;
use YPKY\MemberBundle\Services\MemberFormQuestionLastActivityService;
use YPKY\MemberBundle\Services\NewlyRegisteredMemberTourService;

class DashboardTwigExtension extends \Twig_Extension
{
    private $internalFormService;
    private $memberFormService;
    private $lastActivityService;
    private $memberTourService;
    private $productForms; 
    
    const TEMPLATE_PATH = 'MemberBundle:Widgets\TwigExtensionTemplates\dashboard:';

    public function __construct(InternalFormService $service, MemberFormService $memberFormService, 
                                MemberFormQuestionLastActivityService $lastActivityService, NewlyRegisteredMemberTourService $membrerTourService, array $productForms)
    {
        $this->internalFormService = $service;
        $this->memberFormService = $memberFormService;
        $this->lastActivityService = $lastActivityService;
        $this->memberTourService = $membrerTourService;
        $this->productForms = $productForms;
    }

    public function getName()
    {
        return 'member_dashboard_twig_extension';
    }

    public function getFunctions()
    {
        $params = array('is_safe' => array('html'), 'needs_environment' => true);

        return array(
            new \Twig_SimpleFunction('renderCompleteProfileAlerts', array($this, 'renderCompleteProfileAlerts'), $params),
            new \Twig_SimpleFunction('renderNewlyAddedForms', array($this, 'renderNewlyAddedForms'), $params),
            new \Twig_SimpleFunction('renderLastModifiedForm', array($this, 'renderLastModifiedForm'), $params),
        );
    }

    /** 
     * TODO: Remove this function. Not being used anymore.
     */
    public function renderCompleteProfileAlerts(\Twig_Environment $twig)
    {
        $params['internalForms'] = $this->internalFormService->getInternalForms();
        $params['memberInfo'] = $this->internalFormService->getMemberInfo($this->getMember());
        $params['orgInfo'] = $this->internalFormService->getOrganizationInfo($this->getMember());

        return $twig->render( self::TEMPLATE_PATH . 'completeProfileAlerts.html.twig', $params);
    }
    
    public function renderNewlyAddedForms(\Twig_Environment $twig)
    {

        $params = array(
            'memberNewlyAddedForms' => $this->memberTourService->getForms(),
            'productForms' => $this->productForms
        );

        if(empty($params['memberNewlyAddedForms'])) {
            return;
        }

        return $twig->render( self::TEMPLATE_PATH . 'newlyAddedForms.html.twig', $params);
    }

    public function renderLastModifiedForm(\Twig_Environment $twig)
    {
        $lastActivity = $this->lastActivityService->getMemberFormQuestionLastActivityByMember($this->getMember());

        if(!$lastActivity || !$lastActivity->getFormQuestion()) {
            return;
        }

        $params['formQuestion'] = $lastActivity->getFormQuestion();
        $params['form'] = $params['formQuestion']->getForm();
        $params['formSections'] = $params['form']->getFormSections();
        $params['activeFormSection'] = $params['formQuestion']->getFormElement()->getFormSection();

        return $twig->render( self::TEMPLATE_PATH . 'lastModifiedForm.html.twig', $params);
    }

    private function getMember()
    {
        return $this->memberFormService->getMember();
    }
}

