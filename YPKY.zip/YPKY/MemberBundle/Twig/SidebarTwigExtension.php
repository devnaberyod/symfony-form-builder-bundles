<?php 

/**
 * @author Adelbert Silla
 */

namespace YPKY\MemberBundle\Twig;

use Symfony\Component\Security\Core\SecurityContext;
use YPKY\MemberBundle\Services\InternalFormService;
use YPKY\MemberBundle\Services\MemberFormService;
use YPKY\MemberBundle\Services\NewlyRegisteredMemberTourService;

class SidebarTwigExtension extends \Twig_Extension
{
    private $securityContext;
    private $internalFormService;
    private $memberFormService;
    private $productForms;

    public function __construct(SecurityContext $securityContext, InternalFormService $service, MemberFormService $memberFormService, $productForms)
    {
        $this->securityContext = $securityContext;
        $this->internalFormService = $service;
        $this->memberFormService = $memberFormService;
        $this->productForms = $productForms;
    }

    public function getFunctions()
    {
        $params = array('is_safe' => array('html'), 'needs_environment' => true);

        return array(
            new \Twig_SimpleFunction('renderMemberAndOrgInfo', array($this, 'renderMemberAndOrgInfo'), $params),
            new \Twig_SimpleFunction('renderMemberActiveForms', array($this, 'renderMemberActiveForms'), $params),
        );
    }


    public function renderMemberAndOrgInfo(\Twig_Environment $twig)
    {
        $internalForms = $this->internalFormService->getInternalForms();
        $memberInfo = $this->internalFormService->getMemberInfo($this->getMember());
        $orgInfo = $this->internalFormService->getOrganizationInfo($this->getMember());

        $params = array('orgInfo' => $orgInfo, 'internalForms' => $internalForms, 'fullName' => $this->getMember()->getName());

        $template = 'MemberBundle:Widgets\TwigExtensionTemplates\sidebar:memberInfo.html.twig';

        return $twig->render($template, $params);
    }

    public function renderMemberActiveForms(\Twig_Environment $twig)
    {
        $activeForms = $this->memberFormService->groupForms($this->memberFormService->getActiveForms());

        $productFormsAlias = array_flip($this->productForms);
        
        $params = array('memberActiveForms' => $activeForms['productForms'], 'productFormsAlias' => $productFormsAlias);

        $template = 'MemberBundle:Widgets\TwigExtensionTemplates\sidebar:memberActiveForms.html.twig';
    
        return $twig->render($template, $params);
    }

    private function getMember()
    {
        return $this->securityContext->getToken()->getUser()->getUser()->getMember();
    }

    public function getName()
    {
        return 'member_info_twig_extension';
    }
}

