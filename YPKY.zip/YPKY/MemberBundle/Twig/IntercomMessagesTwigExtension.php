<?php 

/*
    Class Intercom Messages Twig Extension
    @author Diovannie 
    @created Feb 5 2015
*/

namespace YPKY\MemberBundle\Twig;

use Symfony\Component\Security\Core\SecurityContext;

class IntercomMessagesTwigExtension extends \Twig_Extension
{

    private $securityContext;
    private $intercomClientHelper;

    public function __construct(SecurityContext $securityContext, $intercomClientHelper)
    {
        $this->securityContext = $securityContext;
        $this->intercomClientHelper= $intercomClientHelper;
    }

    public function getFunctions()
    {
        return array(
            new \Twig_SimpleFunction('renderIntercomMessages', array($this, 'renderIntercomMessages'), array(
            'is_safe' => array('html'),
            'needs_environment' => true,
            )),
        );
    }

    public function renderIntercomMessages(\Twig_Environment $twig)
    {
        $unreadStatus = null;

        return $twig->render('MemberBundle:Widgets\TwigExtensionTemplates:intercomMessages.html.twig', array(
            'intercomConversationMessage' => $this->intercomClientHelper->getUserConversations($this->getUser(), $unreadStatus)
        ));
    }

    private function getUser()
    {
        return $this->securityContext->getToken()->getUser()->getUser();
    }

    public function getName()
    {
        return 'member_intercom_messages_twig_extension';
    }
}

