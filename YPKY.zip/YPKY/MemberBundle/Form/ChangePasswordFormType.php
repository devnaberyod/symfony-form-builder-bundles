<?php

namespace YPKY\MemberBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Validator\Constraints\NotBlank;
use Symfony\Component\Validator\Constraints\Length;

class ChangePasswordFormType extends AbstractType
{
    
    public function getName()
    {
        return 'changePassword';
    }
    
    public function buildForm(FormBuilderInterface $builder, array $options=array())
    {
        $builder->add('password', 'repeated', array(
            //'error_bubbling' => true,
            'type' => 'password',
            'invalid_message' => 'The passwords you enter must match.',
            'required' => true,
            'first_options'  => array('label' => 'New Password'),
            'second_options' => array('label' => 'Confirm New Password'),
            'constraints' => array(
                    new NotBlank(),
                    new Length(array('min' => 7))
                )
        ));
    }
}