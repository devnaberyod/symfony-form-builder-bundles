<?php

namespace YPKY\MemberBundle\Form\OnBoardingProcessFormType;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Validator\Constraints as Constraints;

use YPKY\ProductBundle\Entity\QuestionTemplate;
use YPKY\MemberBundle\Entity\GlobalMemberAnswer;

use Symfony\Component\Security\Core\SecurityContext;
use Doctrine\Bundle\DoctrineBundle\Registry;

use YPKY\MemberBundle\Form\EventListener\MemberInternalFormSubscriber;

class StepThreeForm extends AbstractType
{
    const NAME = 'member_on_boarding_form_step_three';
    private $securityContext;
    private $doctrine;
    private $questionTemplateName;

    public function __construct(SecurityContext $securityContext, Registry $doctrine, $questionTemplateName)
    {
        $this->securityContext = $securityContext;
        $this->doctrine = $doctrine;
        $this->questionTemplateName = $questionTemplateName['organization_profile']['information'];
    }

    public function getName()
    {
        return self::NAME;
    }

   public function buildForm(FormBuilderInterface $builder, array $options = array())
   {
       $builder
           ->add($this->questionTemplateName['org_name'], 'text', array(
               'attr' => array('placeholder' => 'Fullname of Organization')
           ))
           ->add($this->questionTemplateName['org_office_phone'], 'text', array(
               'attr' => array('placeholder' => 'Phone Number')
           ))
           ->add($this->questionTemplateName['org_office_fax'], 'text', array(
               'attr' => array('placeholder' => 'Fax Number')
           ))
           ->add($this->questionTemplateName['org_website'], 'text', array(
               'attr' => array('placeholder' => 'Website')
           ));
           
        $builder->addEventSubscriber(new MemberInternalFormSubscriber($this->questionTemplateName, $this->doctrine, $this->getMember())); 
   }

   private function getMember()
   {
       $user = $this->securityContext->getToken()->getUser()->getUser();
       return $user->getMember();
   }

  public function setDefaultOptions(\Symfony\Component\OptionsResolver\OptionsResolverInterface $resolver)
  {
       $resolver->setDefaults(array(
          'csrf_protection' => false,
       ));
  }

}
