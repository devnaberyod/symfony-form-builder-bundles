<?php

namespace YPKY\MemberBundle\Form\OnBoardingProcessFormType;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Validator\Constraints as Constraints;

use Doctrine\Bundle\DoctrineBundle\Registry;
use Symfony\Component\Security\Core\SecurityContext;

use YPKY\MemberBundle\Form\EventListener\MemberInternalFormSubscriber;

class StepFourForm extends AbstractType
{
    const NAME = 'member_on_boarding_form_step_four';
    private $doctrine;
    private $questionTemplateName;
    private $securityContext;

    public function __construct(SecurityContext $securityContext, Registry $doctrine, $questionTemplateName)
    {
        $this->securityContext = $securityContext;
        $this->doctrine = $doctrine;
        $this->questionTemplateName = $questionTemplateName['organization_profile']['mailing_address'];
    }

    public function getName()
    {
        return self::NAME;
    }


    public function buildForm(FormBuilderInterface $builder, array $options = array())
    {

        $builder
            ->add( $this->questionTemplateName['org_care_of_name'], 'text', array(
                'attr' => array('placeholder' => 'Mail Documents Care of')
            ))
            ->add( $this->questionTemplateName['org_mailing_address_1'], 'text', array(
                'attr' => array('placeholder' => 'Mailing Address Primary')
            ))
            ->add( $this->questionTemplateName['org_city'], 'text', array(
                'attr' => array('placeholder' => 'City')
            ))
            ->add($this->questionTemplateName['org_us_state'], 'ypky_admin_stateChoice', array(
                'attr' => array('placeholder' => 'State'),
            ))
            ->add( $this->questionTemplateName['org_zip'], 'text', array(
                'attr' => array('placeholder' => 'Zip Code')
            ));

            $builder->addEventSubscriber(new MemberInternalFormSubscriber($this->questionTemplateName, $this->doctrine, $this->getMember())); 
    }

    private function getMember()
    {
        $user = $this->securityContext->getToken()->getUser()->getUser();
        return $user->getMember();
    }

    public function setDefaultOptions(\Symfony\Component\OptionsResolver\OptionsResolverInterface $resolver)
    {
         $resolver->setDefaults(array(
            'csrf_protection' => false,
         ));
    }

}
