<?php 

namespace YPKY\MemberBundle\Form\EventListener;

use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

class MemberInternalFormSubscriber implements EventSubscriberInterface
{
    private $questionTemplateName;
    private static $doctrine;
    private static $member;
    private static $globalAnswer = array();
    private static $instance;

    public function __construct($questionTemplateName, $doctrine, $member)
    {
        $this->questionTemplateName = $questionTemplateName;
        if (!self::$instance) {
            self::$instance = 1;
            self::$member = $member;
            self::$doctrine = $doctrine;
        }
    }

    public static function getSubscribedEvents()
    {
        // Tells the dispatcher that you want to listen on the form.pre_set_data
        // event and that the preSetData method should be called.
        return array(FormEvents::PRE_SET_DATA => 'preSetData');
    }

    public function preSetData(FormEvent $event)
    { 
        $formFieldsSetting= array();
        $this->mapGlobalAnswers();

        foreach ($this->questionTemplateName as $questionTemplateName) {  
            if (isset(self::$globalAnswer[$questionTemplateName])) {
                $formFieldsSetting[$questionTemplateName] = self::$globalAnswer[$questionTemplateName];
            }

        }

        $event->setData($formFieldsSetting);
    }

    //Map global answer
    private function mapGlobalAnswers()
    {
        if (!empty(self::$globalAnswer)) return self::$globalAnswer;

        $globalAnswers = self::$doctrine->getRepository('MemberBundle:GlobalMemberAnswer')->findByMember(self::$member);
        if (!empty($globalAnswers)) {
            foreach ($globalAnswers as $each) {
                self::$globalAnswer[$each->getQuestionTemplate()->getName()] = $each->getAnswer();
            }
        }
    }
}

