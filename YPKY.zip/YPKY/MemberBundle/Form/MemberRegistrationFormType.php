<?php

namespace YPKY\MemberBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Validator\Constraints\NotBlank;

class MemberRegistrationFormType extends AbstractType
{
    const NAME = 'memberRegistrationForm';
    
    /** 
     * @var boolean
     */
    private $hasName;

    /** 
     * @param boolean $hasName
     */
    public function __construct($hasName = false)
    {
        $this->hasName = $hasName;
    }

    public function getName()
    {
        return self::NAME;
    }

    public function buildForm(FormBuilderInterface $builder, array $options = array())
    {

        $builder->add('email', 'email', array(
            'constraints' => array(new NotBlank(array('message' => 'Email is required'))),
            'attr' => array('placeholder' => 'Email Address'),
            'error_bubbling' => true,
        ));

        $builder->add('password', 'repeated', array(
            'constraints' => array(new NotBlank(array('message' => 'Password is required'))),
            'error_bubbling' => true,
            'type' => 'password',
            'invalid_message' => 'The password fields must match.',
            'options' => array('attr' => array('class' => 'password-field')),
            'required' => true,
            'first_options'  => array('attr' => array('placeholder' => 'Password')),
            'second_options' => array('attr' => array('placeholder' => 'Repeat Password')),
        ));

        if($this->hasName) {
            $this->addNameFields($builder);
        }
    }

    
    private function addNameFields(FormBuilderInterface $builder)
    {
        $constraintFirstname = array(new NotBlank(array('message' => 'Firstname is required')));
        $constraintLastname = array(new NotBlank(array('message' => 'Lastname is required')));
        
        $builder->add('first_name', 'text', array(
            'mapped' => false,
            'constraints' => $constraintFirstname,
            'error_bubbling' => true)
        );
    
        $builder->add('last_name', 'text', array(
            'mapped' => false,
            'constraints' => $constraintLastname,
            'error_bubbling' => true)
        );
    }
}
