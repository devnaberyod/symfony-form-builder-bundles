<?php
namespace YPKY\MemberBundle\Tests\Controller;

use YPKY\HelperBundle\Test\WebTestCase;

class OrganizationProfileControllerTest extends WebTestCase
{
    protected $client = null;

    public function setUp()
    {
        $this->client = static::createClient();
    }

    public function testFillUpAction()
    {
        $this->loadFixtures(array(
            'YPKY\ProductBundle\DataFixtures\OrganizationProfile\OrganizationProfileFormData',
            'YPKY\ProductBundle\DataFixtures\OrganizationInterview\OrganizationInterviewFormData',
            'YPKY\ProductBundle\DataFixtures\OrganizationInterview\OrganizationInterviewQuestionDependecyData',
            'YPKY\MemberBundle\DataFixtures\MemberUserData'
        ));
    }

    // public function testFillUpAction()
    // {
    //     $this->loadFixtures(array(
    //         'YPKY\ProductBundle\DataFixtures\OrganizationProfile\OrganizationProfileFormData',
    //         'YPKY\MemberBundle\DataFixtures\MemberUserData'
    //     ));


    //     $this->loginClient();

    //     $response = $this->client->request('GET', $this->getUrl('client_organizationProfile_fillUp'));

    //     $this->assertTrue($this->client->getResponse()->isSuccessful());

    //     // assert all fields are present
    // }

    // public function testPostFillUpAction()
    // {
    //     $this->loadFixtures(array(
    //         'YPKY\ProductBundle\DataFixtures\OrganizationProfile\OrganizationProfileFormData',
    //         'YPKY\MemberBundle\DataFixtures\MemberUserData'
    //     ));

    //     $formParams = array(
    //     	'form_question:1' => 'The Org Name',// org name
    //     	'form_question:2' => 'To be care of', // care of name
    //         'form_question:3' => 'Unit 602', // address 2
    //         'form_question:4' => 'Keppel Business', // address 1
    //         'form_question:5' => 'Cebu City', // city
    //         'form_question:6' => 1, // US State
    //         'form_question:7' => 6000, // Zip
    //         'form_question:8' => '123-123-1234', // office phone
    //         'form_question:9' => '123-123-1234', // office fax
    //         'form_question:10' => 'http://www.chromedia.com', // Company Url
    //         'form_question:11' => 'Type1', // Org Type

    //     );

    //     $this->loginClient();
    //     $response = $this->sendPostRequest($this->getUrl('client_organizationProfile_postFillUp'), array('parameters' => array('form' => $formParams)));

    //     file_put_contents('/Users/allejochrisvelarde/Desktop/debug.html', $response->getContent());
    // }
}