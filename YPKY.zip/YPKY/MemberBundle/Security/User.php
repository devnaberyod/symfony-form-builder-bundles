<?php

namespace YPKY\MemberBundle\Security;

use YPKY\MemberBundle\Entity\Member;

class User implements \Symfony\Component\Security\Core\User\UserInterface
{

    private $user;
    private $salt;
    private $roles;
    
    public function __construct(Member $user, $salt, $roles)
    {
        $this->user = $user;
        $this->salt = $salt;
        $this->roles = $roles;
    }

    public function getUsername()
    {
        return $this->user->getEmail();
    }

    public function getPassword()
    {
        return $this->user->getPassword();
    }

    public function getSalt()
    {
        return $this->salt;
    }

    public function getRoles()
    {
        return $this->roles;
    }

    public function getUser()
    {
        return $this->user; 
    }

    public function eraseCredentials()
    {
    }

    // public function equals(UserInterface $user)
    // {
    //     if (!$user instanceof User) {
    //         return false;
    //     }

    //     if ($this->user->getPassword() !== $user->getPassword()) {
    //         return false;
    //     }

    //     if ($this->getSalt() !== $user->getSalt()) {
    //         return false;
    //     }

    //     if ($this->user->getEmail() !== $user->getUsername()) {
    //         return false;
    //     }

    //     return true;
    // }

    // public function isEqualTo(UserInterface $user)
    // {
    //     if (!$user instanceof User) {
    //         return false;
    //     }

    //     if ($this->password !== $user->getPassword()) {
    //         return false;
    //     }

    //     if ($this->getSalt() !== $user->getSalt()) {
    //         return false;
    //     }

    //     if ($this->username !== $user->getUsername()) {
    //         return false;
    //     }

    //     return true;
    // }
}