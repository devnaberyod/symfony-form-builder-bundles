<?php

namespace YPKY\MemberBundle\Security;

use Symfony\Component\Security\Http\Authentication\AuthenticationSuccessHandlerInterface;
use Symfony\Component\Security\Http\Authentication\AuthenticationFailureHandlerInterface;
use Symfony\Component\Security\Core\Exception\AuthenticationException;
use Symfony\Component\Security\Core\Authentication\Token\TokenInterface;
use Symfony\Component\Security\Core\SecurityContext;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\Routing\Router;
use Symfony\Component\Security\Http\Logout\LogoutSuccessHandlerInterface;

use YPKY\HelperBundle\Service\UserTokenizerService;

/**
 * Class that handles successful or failed login
 *
 * @author Farly Taboada
 */
class MemberAuthenticationHandler implements AuthenticationSuccessHandlerInterface, AuthenticationFailureHandlerInterface, LogoutSuccessHandlerInterface
{
    private $service;


    private $securityContext;

    public function setUserTokenizerService(UserTokenizerService $service)
    {
        $this->service = $service;
    }

    public function setSecurityContext(SecurityContext $securityContext)
    {
        $this->securityContext = $securityContext;
    }

    public function setRouter(Router $router)
    {
        $this->router = $router;
    }

    // public function setMemberService(MemberService $memberService)
    // {
    //     $this->memberService = $memberService;
    // }

    public function onAuthenticationSuccess(Request $request, TokenInterface $token)
    {
        $user = $this->securityContext->getToken()->getUser()->getUser();

        $token = $this->service->generateUserToken($user);
        $this->service->save($token);

        $request->getSession()->set('access_token', $token->getToken());

        // if ($this->memberService->isFirstLogin()) {
        //     $url = $this->memberService->getFirstLoginUrl();

        //     return new RedirectResponse($this->router->generate($url));
        // }

        return new RedirectResponse($this->router->generate('member_homepage'));
    }

    public function onAuthenticationFailure(Request $request, AuthenticationException $exception)
    {

    }

    public function onLogoutSuccess(Request $request)
    {
        $session = $request->getSession();

        if ($session->has('access_token')) {
            $token = $this->service->findToken($session->remove('access_token'));
            $this->service->remove($token);
        }
        
        $response = new RedirectResponse($this->router->generate('member_login'));        
        return $response;
    }
}
