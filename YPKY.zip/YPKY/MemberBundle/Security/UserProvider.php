<?php


namespace YPKY\MemberBundle\Security;

use Symfony\Component\Security\Core\User\UserProviderInterface;
use Symfony\Component\Security\Core\User\UserInterface;
// use Symfony\Component\Security\Core\Exception\BadCredentialsException;
use Symfony\Component\Security\Core\Exception\UsernameNotFoundException;
use Symfony\Component\Security\Core\Exception\UnsupportedUserException;

use Doctrine\ORM\EntityManager;
use YPKY\UserBundle\Security\User;

class UserProvider implements UserProviderInterface
{

    private $entityManager;

    public function __construct(EntityManager $entityManager)
    {
        $this->entityManager = $entityManager;
    }

    public function loadUserByUsername($username)
    {        
        $user = $this->entityManager->getRepository('UserBundle:User')->findOneByEmail($username);

        if (!is_null($user) && $user->getStatus() !== \YPKY\UserBundle\Classes\UserConstants::SUSPENDED) { 
            /**
            * @todo  improve this
            */
            $member = $this->entityManager->getRepository('MemberBundle:Member')->findOneByUser($user);

            if (is_null($member)) {
                throw new UsernameNotFoundException(
                    sprintf('Username "%s" does not exist.', $username)
                );
            }

            $user->setMember($member);

            return new User($user, $user->getSalt(), array('ROLE_MEMBER'));
        } 
        
        throw new UsernameNotFoundException(
            sprintf('Email "%s" does not exist.', $username)
        );
    }

    public function refreshUser(UserInterface $user)
    {
        if (!$user instanceof User) {
            throw new UnsupportedUserException(
                sprintf('Instances of "%s" are not supported.', get_class($user))
            );
        }

        return $this->loadUserByUsername($user->getUsername());
    }

    public function supportsClass($class)
    {
        return $class === 'YPKY\MemberBundle\Security\User';
    }
}

