<?php

namespace YPKY\MemberBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\EventDispatcher\GenericEvent;


class StripeController extends MemberAwareController
{ 

    public function checkoutCallbackAction()
    {
        $body = @file_get_contents( 'php://input' );
        
        $response = json_decode( $body, true );
        
        if ( empty( $response ) ) {
        
            if ( strpos( $body, 'ipn_is_json' ) !== false )
                $response = json_decode( $_POST, true );
        
            if ( empty( $response ) ) {
                exit;
            }
        }
        
        echo '<pre>';
        var_dump($response);
        exit;
    }
}
