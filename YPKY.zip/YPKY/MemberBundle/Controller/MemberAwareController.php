<?php
namespace YPKY\MemberBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use YPKY\UserBundle\Entity\User;

abstract class MemberAwareController extends Controller
{
    /**
     * @return \YPKY\MemberBundle\Entity\Member
     */
    protected function getMember()
    {
        $member = null;
        if ($this->getUser()) {
            $userEntity = $this->getUser()->getUser();
            if ($userEntity instanceof User) {
            	$member = $userEntity->getMember();
            }
        }

        if (!$member) {
            // throw exception; all member aware controller should have a logged in member
            throw new \Exception('Invalid member');
        }

        return $member;
    }
}