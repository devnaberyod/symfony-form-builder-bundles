<?php

namespace YPKY\MemberBundle\Controller;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\EventDispatcher\GenericEvent;
use Symfony\Component\Security\Core\SecurityContext;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;

use YPKY\MemberBundle\Entity\Member;
use YPKY\MemberBundle\Form\MemberRegistrationFormType;
use YPKY\UserBundle\Event\UserUpdateEvent;
use YPKY\UserBundle\Event\UserAccessTokenEvent;
use YPKY\UserBundle\Services\UserTokenService;


class MemberAccountController extends Controller
{
    public function registerAction(Request $request)
    {
        $form = $this->createForm(new MemberRegistrationFormType(), new \YPKY\UserBundle\Entity\User());

        if($request->isMethod('POST')) {
            $form->handleRequest($request);
            
            if($form->isValid()) {
                $member = $this->get('member.registration')->registerMember($form->getData());

                $token = $this->get('helper.user.tokenizer')->generateUserToken($member->getUser(), UserTokenService::getTokenExpiration());

                $event = new \YPKY\UserBundle\Event\UserAccessTokenEvent();
                $event->setToken($token);

                $this->get('event_dispatcher')->dispatch('user.access.token.new', $event);
                $this->get('event_dispatcher')->dispatch('notification.user.new', $event);


                // Set Member and Organization Forms permission
                $this->get('member.internal_form_service')->addFormOrgAndMemberPermission($member);


                // Displatch event for intercom user register.
                $this->get('event_dispatcher')->dispatch('intercom.user.register', new GenericEvent($member->getUser()));

                $this->get('helper.flash_messenge')->showSuccessMessage('Please check your email to activate account!');
            } else {
                foreach ($form->getErrors() as $error) {
                    $this->get('helper.flash_messenge')->showErrorMessage($error->getMessage());
                }
            }
        }

        return $this->render('MemberBundle:MemberAccount:register.html.twig', array('form' => $form->createView()));
    }

    public function loginAction(Request $request)
    {
        $form = $this->createForm(new MemberRegistrationFormType());
        // $request = $this->getRequest();
        $session = $request->getSession();

        // get the login error if there is one
        if ($request->attributes->has(SecurityContext::AUTHENTICATION_ERROR)) {
            $error = $request->attributes->get(SecurityContext::AUTHENTICATION_ERROR);
        } else {
            $error = $session->get(SecurityContext::AUTHENTICATION_ERROR);
            $session->remove(SecurityContext::AUTHENTICATION_ERROR);
        }

        if($error) { 
            $this->get('helper.flash_messenge')->showErrorMessage('Invalid Username or Password!');
        }
        
        return $this->render('MemberBundle:MemberAccount:login.html.twig', array(
            // last username entered by the user
            'lastUsername' => $session->get(SecurityContext::LAST_USERNAME),
        ));
    }


    public function requestResetPasswordAction(Request $request)
    {
        if ($request->isMethod('POST')) {
            $email = $request->get('email');

            $user = $this->getDoctrine()->getManager()->getRepository('UserBundle:User')->findOneByEmail($email);

            if (!is_null($user)) {
                $token = $this->get('helper.user.tokenizer')->generateUserToken($user, 1);

                $event = new \YPKY\HelperBundle\Event\RequestPasswordEvent();
                $event->setToken($token);
                $this->get('event_dispatcher')->dispatch('helper.user.request_reset_password', $event);
                $this->get('event_dispatcher')->dispatch('notification.user.request_reset_password', $event);

                $this->get('helper.flash_messenge')->showSuccessMessage('Successfully requested to reset password. Please check your email!');
            } else {
                $this->get('helper.flash_messenge')->showErrorMessage('Email address does not match an account in our records.');
            }
        }

        return $this->render('MemberBundle:MemberAccount:resetPassword.html.twig');
    }

    public function resetPasswordAction(Request $request)
    {
        $token = $request->get('token');
        $token = $this->getDoctrine()->getRepository('UserBundle:UserAccessToken')->findOneByToken($token);

        if (!is_null($token)) {

            $now = new \DateTime();
            $now = $now->getTimestamp();

            if ($token->getExpiration()->getTimestamp() > $now) {
                $form = $this->createForm(new \YPKY\MemberBundle\Form\ChangePasswordFormType());

                if ($request->isMethod('POST')) {
                    $form->bind($request);

                    if ($form->isValid()) {
                        $password = $form->get('password')->getData(); 
                        $service = $this->get('user.service');

                        $user = $service->setUser($token->getUser())
                                        ->setPassword($password)
                                        ->getUser();

                        $eventDispatcher = $this->get('event_dispatcher');

                        $userUpdateEvent = new \YPKY\UserBundle\Event\UserUpdateEvent();
                        $eventDispatcher->dispatch('user.update.info', $userUpdateEvent->setUser($user));
                        $eventDispatcher->dispatch('user.update.password', $userUpdateEvent);

                        $userAccessToken = new \YPKY\UserBundle\Event\UserAccessTokenEvent();
                        $eventDispatcher->dispatch('user.token.expired', $userAccessToken->setToken($token));

                        $authorizedUser = new \YPKY\UserBundle\Security\User($user, $user->getSalt(), array('ROLE_MEMBER'));

                        $token = new \Symfony\Component\Security\Core\Authentication\Token\UsernamePasswordToken($authorizedUser, $authorizedUser->getPassword(), 'member_area', $authorizedUser->getRoles());
                        $request->getSession()->set('_security_member_area', serialize($token));

                        $event = new \Symfony\Component\Security\Http\Event\InteractiveLoginEvent($request, $token);
                        $eventDispatcher->dispatch("security.interactive_login", $event);

                        return new RedirectResponse($this->generateUrl('member_homepage'));
                    } 
                }
            } else {
                $this->get('helper.flash_messenge')->showErrorMessage('Expired Token!');
            }

        } else {
            $this->get('helper.flash_messenge')->showErrorMessage('Invalid Token!');
        }

        $data = array(
            'form' => isset($form) ? $form->createView() : ''
        );

        return $this->render('MemberBundle:MemberAccount:changePassword.html.twig', $data);
    }

    public function confirmEmailAction(Request $request)
    {
        $requestToken = $request->get('token');
        return $this->forward('MemberBundle:MemberAccount:authenticateMember', array('token' => $requestToken));
    }

    public function authenticateMemberAction(Request $request)
    {
        $token = $request->get('token');

        $repository = $this->getDoctrine()->getManager()->getRepository('UserBundle:UserAccessToken');
        
        // expiration not here not being checked
        $userToken = $repository->findOneByToken($token);

        if (!is_null($userToken)) {
          
            $eventDispatcher = $this->get('event_dispatcher');

            $user = $userToken->getUser();
            $user->setStatus(\YPKY\UserBundle\Classes\UserConstants::ACTIVE);

            $authorizedUser = new \YPKY\UserBundle\Security\User($user, $user->getSalt(), array('ROLE_MEMBER'));

            $token = new \Symfony\Component\Security\Core\Authentication\Token\UsernamePasswordToken($authorizedUser, $authorizedUser->getPassword(), 'member_area', $authorizedUser->getRoles());
            $request->getSession()->set('_security_member_area', serialize($token));

            $event = new \Symfony\Component\Security\Http\Event\InteractiveLoginEvent($request, $token);
            $eventDispatcher->dispatch("security.interactive_login", $event);

            // Set Member and Organization Forms permission
            $this->get('member.internal_form_service')->addFormOrgAndMemberPermission($user->getMember());

            $event = new \YPKY\UserBundle\Event\UserUpdateEvent();
            $event->setUser($user);
            $eventDispatcher->dispatch('user.update.info', $event);
            
            $repository->delete($userToken);

            //redirect to organisation info for first login
            return new RedirectResponse($this->generateUrl('member_homepage', array('new_member' => 1)));
            
        } else {
            return new RedirectResponse($this->generateUrl('member_login'));
        }
    }

}
