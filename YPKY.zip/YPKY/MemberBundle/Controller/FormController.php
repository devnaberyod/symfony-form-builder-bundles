<?php
namespace YPKY\MemberBundle\Controller;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\EventDispatcher\GenericEvent;

use YPKY\FormBuilderBundle\Services\FormProductFactory;
use YPKY\MemberBundle\Services\FlashMessageService;

class FormController extends MemberAwareController
{
    const DEFAULT_PAGE = 1;
    const SUBMIT_NEXT_VALUE = 'Save, go to Next Step';
    const SUBMIT_FINISH_VALUE = 'Finish';
    const SUBMIT_DASHBOARD_VALUE = 'Save, return to Dashboard';
    const SUBMIT_REDIRECT_PAGE = 1;
    
    public function viewFormAction(Request $request)
    {
        if($this->getMember()->getHasTakenTour() !== 1) {
            $this->get('member.form_service')->endMemberTour($this->getMember());
        }

        // check form 
        $formEntity = $this->getDoctrine()->getRepository('ProductBundle:Form')->find($request->get('form_id'));
        if (!$formEntity) {
            throw $this->createNotFoundException('Form is not valid.');
        }
        
        $criteria = array('form' => $formEntity, 'organization' => $this->getMember()->getOrganization());
        $hasFormAccess = $this->getDoctrine()->getRepository('MemberBundle:OrganizationFormPermission')->findOneBy($criteria);
        
        if (!$hasFormAccess) {
            throw $this->createNotFoundException('You do not have yet to access to this form.');
        }

        if($formSectionId = $request->get('form_section_id')) {
            $formSection = $this->getDoctrine()->getRepository('ProductBundle:FormSection')->find($formSectionId);
        } else {
            $formSection = $formEntity->getFormSections()->first();
        }

        $form = $this->get('form_builder.form_product_factory')->createForm($formEntity, $formSection);

        if($request->isMethod('POST')) {

            $form->submit($request);

            if ($form->isValid()) {
               
                $incrementPage = false;
                $redirectPage = $request->get('redirect', null);

                $redirectUrl = (!isset($redirectPage) ? $this->generateUrl('member_homepage') : $redirectPage);
                
                if (!isset($redirectPage)) {
                    switch($action = $request->get('submit_action')) {
                        case self::SUBMIT_NEXT_VALUE :
                        case self::SUBMIT_DASHBOARD_VALUE :
                            $formSections = $formEntity->getFormSections()->toArray();
                            $index = array_search($formSection, $formSections);
                            $nextFormSection = $formSections[$index + 1];
                            $incrementPage = true;

                            if($action == self::SUBMIT_NEXT_VALUE) {
                                $urlParams = array('form_id' => $formEntity->getId(), 'form_section_id' => $nextFormSection->getId());
                                $redirectUrl = $this->generateUrl('member_form_view', $urlParams);
                            }
                            break;
                    }
                }
                
                $memberForm = $this->get('member.form_service')->prepareMemberForm($formEntity);
                $isNewForm = !$memberForm->getId();

                // var_dump($memberForm->getId()); exit;
                $this->get('member.form_service')->saveMemberFormEntity($memberForm, $formSection, $incrementPage);
                $this->get('member.form_service')->saveMemberFormAnswers($memberForm, $formSection, $form, $request->files->all());

                // Displatch event for saving member form.
                $eventParams = array('memberForm' => $memberForm, 'isNewForm' => $isNewForm);
                $event = new GenericEvent($this->getMember()->getUser(), $eventParams);
                $this->get('event_dispatcher')->dispatch('intercom.user.form.save', $event);

                $this->get('helper.flash_messenge')->showSuccessMessage('Your answers were saved.', 'Great Job');

                //Update last form question activity
                $this->get('member.form_question_last_activity')->updateMemberFormLastActivity($this->getMember(), $form->getData(), $request->get('lastFormQuestionWorking'));
                
                // $this->get('member.internal_form_service')->saveOrgNameStoredProc($this->getMember()->getOrganization(), 'storeprocnew');
                
                return $this->redirect($redirectUrl);
            }
            else{
                $this->get('helper.flash_messenge')->showErrorMessage('Please check the form for some errors.');
            }
        }

        $lastFormQuestionWorking = $this->get('member.form_question_last_activity')->getMemberFormQuestionLastActivityByMember($this->getMember());

        return $this->render('MemberBundle:Form:viewForm.html.twig', array(
        	'form' => $form->createView(),
            'formEntity' => $formEntity,
            'formSection' => $formSection,
            'memberForm' => null,//$memberForm,
            'submitNextValue' => self::SUBMIT_NEXT_VALUE,
            'submitFinishValue' => self::SUBMIT_FINISH_VALUE,
            'submitDashboardValue' => self::SUBMIT_DASHBOARD_VALUE,
            'lastFormQuestionWorking' =>  $lastFormQuestionWorking,
        ));
    }

    public function viewMemberFormAnswersAction(Request $request)
    {
        $formEntity = $this->getDoctrine()->getRepository('ProductBundle:Form')->find($request->get('form_id'));

        if (!$formEntity) {
            throw $this->createNotFoundException('Form is not valid.');
        }

        $memberForm = $this->getDoctrine()->getRepository('MemberBundle:MemberForm')
            ->findByMemberAndForm($this->getMember(), $formEntity);

        if (!$memberForm) {
            $this->get('helper.flash_messenge')->showNoticeMessage('You have not yet fill up '.$formEntity->getName());
            return $this->redirect($this->generateUrl('member_homepage'));
        }

        return $this->render('MemberBundle:Form:viewMemberFormAnswers.html.twig', array(
            'memberForm' => $memberForm,
            'formEntity' => $formEntity
        ));
    }


}

