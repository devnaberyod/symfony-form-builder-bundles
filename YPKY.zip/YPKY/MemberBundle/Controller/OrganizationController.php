<?php
namespace YPKY\MemberBundle\Controller;

use Symfony\Component\HttpFoundation\Request;

class OrganizationController extends MemberAwareController
{

}