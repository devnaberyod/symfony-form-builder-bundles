<?php

namespace YPKY\MemberBundle\Controller;

use FOS\RestBundle\Controller\FOSRestController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;

use Symfony\Component\EventDispatcher\GenericEvent;

use YPKY\ProductBundle\Entity\Form;
use YPKY\MemberBundle\Entity\Member;

class OnBoardingProcessController extends FOSRestController
{
    private static $lastStep = 4;
    /*
        Save Form step
        @return on success of saving form Go to next step
    */
    public function saveStepFormAction(Request $request)
    {
        if ($request->isXmlHttpRequest() && 'POST' == $request->getMethod()) {
            $step = $request->get('step', null);
            $stepForms = $this->getCurrentStepFormAndEntity($step);
            $stepForms['formType']->handleRequest($request);

            if ($stepForms['formType']->isValid()) {
                $formData = $request->request->get($stepForms['formStepName']);
                $user = $this->get('security.context')->getToken()->getUser()->getUser();

                $memberForm = $this->get('member.form_service')->prepareMemberForm($stepForms['formEntity']);
                $isNewForm = !$memberForm->getId();

                //save member and global forms answers
                $this->get('member.internal_form_service')->saveGlobalAndMemberFormAnswers($memberForm, $formData);

                $eventParams = array('memberForm' => $memberForm, 'isNewForm' => $isNewForm);
                $event = new GenericEvent($user, $eventParams);
                $this->get('event_dispatcher')->dispatch('intercom.user.form.save', $event);

                if (self::$lastStep == $step) {
                    $this->get('helper.flash_messenge')->showSuccessMessage('You have completed the requirements for your profile. Welcome to Yippiekiyay.com', 'Congratulations');
                }

                $view = new JsonResponse(array('error' => 0, 'message' => 'Succesfully save form'));
            } else {
                $view = $this->view($stepForms['formType']);
            }

            return $view;
        }

        throw new \Exception("Invalid request type", 1);

    }
    /*
        Get Internal Form Type and Entity
        @param Int $step
        @return Array
    */
    private function getCurrentStepFormAndEntity($step)
    {
        switch ($step) {
            case 2:
                $formStepName = 'member_on_boarding_form_step_two';
                $formType = $this->createForm('member_on_boarding_form_step_two');
                $formEntity = $this->get('member.internal_form_service')->getInternalFormByName('member_profile');
                break;
            case 3:
                $formStepName = 'member_on_boarding_form_step_three';
                $formType = $this->createForm('member_on_boarding_form_step_three');
                $formEntity= $this->get('member.internal_form_service')->getInternalFormByName('organization_profile');
                break;
            case 4:
                $formStepName = 'member_on_boarding_form_step_four';
                $formType = $this->createForm('member_on_boarding_form_step_four');
                $formEntity = $this->get('member.internal_form_service')->getInternalFormByName('organization_profile');
                break;
            default:
                throw $this->createNotFoundException('Invalid request step');
                break;
        }
        return array('formType' => $formType, 'formEntity' => $formEntity, 'formStepName' => $formStepName);
    }
}




