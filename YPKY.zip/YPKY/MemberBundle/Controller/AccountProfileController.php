<?php
namespace YPKY\MemberBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;

class AccountProfileController extends Controller
{
    public function viewAccountDetailsFormAction()
    {

    }
}