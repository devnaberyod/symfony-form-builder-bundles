<?php

namespace YPKY\MemberBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\EventDispatcher\GenericEvent;


class DashboardController extends MemberAwareController
{
    const NEW_MEMBER = 'new_member';

    public function indexAction(Request $request)
    {
        $member = $this->getMember();
        $onBoardingProcessForms = null;
        $showOnBoardingProcess = $request->get(self::NEW_MEMBER, false) || !$this->hasProfileMemberForm();

        if ($showOnBoardingProcess) {
            $onBoardingProcessForms = array(
                'stepOne' => array('email' => $member->getUser()->getEmail()),
                'stepTwo' => $this->createForm('member_on_boarding_form_step_two')->createView(),
                'stepThree' => $this->createForm('member_on_boarding_form_step_three')->createView(),
                'stepFour' => $this->createForm('member_on_boarding_form_step_four')->createView()
            );
        }


        $params = array(
            'member' => $member,
            'showMemberTour' => $member->getHasTakenTour() !== 1 && !$showOnBoardingProcess,
            'onBoardingProcessForm' => $onBoardingProcessForms,
        );
        
        return $this->render('MemberBundle:Dashboard:index.html.twig', $params);
    }

    public function intercomAppJsAction()
    {
        $memberProfile  = $this->get('member.internal_form_service')->getMemberInfo($this->getMember());
        $data = array(
            'intercom_app_id' => $this->get('helper.intercom_client')->getAppId(),
            'name' => ucfirst($memberProfile->firstName()) .' '. ucfirst($memberProfile->lastName())
        );
        $response = $this->render('MemberBundle:Dashboard:intercomAppScript.js.twig', $data);
        $response->headers->set('content-type', 'application/javascript');
        $response->headers->addCacheControlDirective('no-cache', true);
        $response->headers->addCacheControlDirective('no-store', true);

        return $response;
    }

    public function memberTourJsAction()
    {
        $memberProfile  = $this->get('member.internal_form_service')->getMemberInfo($this->getMember());
        $param = array(
            'tourSteps' => json_encode($this->get('member.newly_registred_tour')->getMemberTourConfig())
        );

        $response = $this->render('MemberBundle:Dashboard:memberTour.js.twig', $param);
        $response->headers->set('content-type', 'application/javascript');
        $response->headers->addCacheControlDirective('no-cache', true);
        $response->headers->addCacheControlDirective('no-store', true);

        return $response;
    }

    public function endMemberTourAction(Request $request)
    {
        try {
            $this->get('member.form_service')->endMemberTour($this->getMember());
        } catch(\Exception $e) {}
    }
    
    private function hasProfileMemberForm()
    {
        $memberProfile = $this->get('member.internal_form_service')->getInternalFormByName('member_profile');
        $memberForm = $this->get('member.form_service')->prepareMemberForm($memberProfile);
        
        return $memberForm->getId();
    }
}
