<?php
namespace YPKY\MemberBundle\Exception;

class MemberFormException extends \Exception
{
    static public function submittedInvalidFormQuestion($formQuestionId)
    {
        return new self("Invalid FormQuestion[{$formQuestionId}] in submitted form data.");
    }

    static public function entityCannotBeConvertedToString($object)
    {
        return new self(get_class($object).' should implement __toString()');
    }
}