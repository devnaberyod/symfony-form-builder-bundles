<?php

namespace YPKY\MemberBundle\Listener;

use Symfony\Component\EventDispatcher\Event;
use YPKY\HelperBundle\Service\IntercomEventMapper;
use YPKY\HelperBundle\Service\IntercomClientService;
use YPKY\UserBundle\Entity\User;
use YPKY\MemberBundle\Entity\MemberForm;

class IntercomUserListener
{    
    /** 
     * @var IntercomEventMapper
     */
    private $intercomEventMapper;

    /**
     * @var IntercomClientService
     */
    private $intercomClientService;


    public function setIntercomEventMapper(IntercomEventMapper $intercomEventMapper)
    {
        $this->intercomEventMapper = $intercomEventMapper;
    }

    public function setIntercomClientService(IntercomClientService $service)
    {
        $this->intercomClientService = $service;
    }

    /**
     * On Register event listener. This will send a request to the intercom to create a new user.
     * 
     * @param Event $event
     */
    public function onRegister(Event $event)
    {
        $user = $event->getSubject();

        $this->intercomClientService->createUser($user);
    }

    /**
     * On form save event listener. 
     * 
     * If form is member profile. This will send an event 'user-fill-up-profile' if newly filled up.
     *  
     * @param Event $event
     */
    public function onFormSave(Event $event)
    {
        $user = $event->getSubject();
        $isNew = $event->getArgument('isNewForm');
        $memberForm = $event->getArgument('memberForm');

        if($isNew) {
            $this->createIntercomFilledUpFormEvent($memberForm, $user);
        } else {
            //$this->createIntercomCompletedFormEvent($memberForm, $user);
        }
    }

    //////////// PRIVATE FUNCTIONS //////////
    private function createIntercomFilledUpFormEvent(MemberForm $memberForm, $user)
    {
        try {
            $eventName = $this->intercomEventMapper->getEventNameByForm($memberForm->getForm());
            $metadata = array(
                'form_id' => $memberForm->getForm()->getId(),
                'form_name' => $memberForm->getForm()->getName()
            );

            $this->intercomClientService->createUserEvent($eventName, $user, $metadata);

        } catch(\Exception $e) {}
    }

    private function createIntercomCompletedFormEvent(MemberForm $memberForm, $user)
    {
        $metadata = array(
            'form_id' => $memberForm->getForm()->getId(),
            'form_name' => $memberForm->getForm()->getName()
        );

        $this->intercomClientService->createUserEvent('user-completed-form', $user, $metadata);
    }
}