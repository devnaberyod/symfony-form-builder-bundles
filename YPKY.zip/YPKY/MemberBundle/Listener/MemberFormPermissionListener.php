<?php
/**
 * Listener to add permission to Member's/Organization's forms based on what the user checked out and options they choose.
 * 
 * @author Adelbert Silla
 */
namespace YPKY\MemberBundle\Listener;

use Doctrine\Bundle\DoctrineBundle\Registry;
use Symfony\Component\EventDispatcher\Event;

use YPKY\MemberBundle\Entity\MemberForm;
use YPKY\MemberBundle\Services\MemberFormService;
use YPKY\MemberBundle\Entity\Organization;
use YPKY\HelperBundle\Service\WordpressPlatformService;
use YPKY\MemberBundle\Entity\Member;

use YPKY\HelperBundle\Service\IntercomClientService;
use YPKY\HelperBundle\Service\IntercomEventMapper;

class MemberFormPermissionListener
{
    /** 
     * @var MemberFormService
     */
    private $memberFormService;
    
    /** 
     * @var Registry
     */
    private $doctrine;
    
    /** 
     * @var array
     */
    private $productForms;

    /**
     * @var IntercomEventMapper
     */
    private $intercomEventMapper;

    /**
     * @var IntercomClientService
     */
    private $intercomClientService;


    /** 
     * @param IntercomEventMapper $intercomEventMapper
     */
    public function setIntercomEventMapper(IntercomEventMapper $intercomEventMapper)
    {
        $this->intercomEventMapper = $intercomEventMapper;
    }

    /** 
     * @param MemberFormService $service
     */
    public function setMemberFormService(MemberFormService $service)
    {
        $this->memberFormService = $service;
    }

    /**
     * Doctrine
     * 
     * @param Registry $v
     */
    public function setDoctrine(Registry $v)
    {
        $this->doctrine = $v;
    }

    /**
     * Products form ids.
     * @param unknown $formIds
     */
    public function setProductForms($formIds)
    {
        $this->productForms = $formIds;
    }

    public function setIntercomClientService(IntercomClientService $service)
    {
        $this->intercomClientService = $service;
    }

    /**
     * On addMemberFormPermission event listener. This will add a permission to the form that is being checked out.
     * 
     * @param Event $event
     */
    public function onAddMemberFormPermission(Event $event)
    {
        $member = $event->getSubject();
        $wpUserData = $event->getArgument('wp_user_data');

        // Create Organization if not exists.
        if(!$member->getOrganization()) {
            $org = new Organization();
            $org->setName('Replace with your organization');
            $org->setDateCreated(new \DateTime());
            $org->setDateModified(new \DateTime());
            $org->setStatus(1);

            $member->setOrganization($org);
        }

        if(WordpressPlatformService::NONPROFIT_FORM == $wpUserData['form_id']) {
            $this->addFormsPermissionsForNonProfitCheckout($member, $wpUserData);

        } else if(WordpressPlatformService::COMPLIANCE_FORM == $wpUserData['form_id']) {

            // Add permission to Compliance or NonProfit Form
            $formRepo = $this->doctrine->getRepository('ProductBundle:Form');
            $complianceForm = $formRepo->findOneByWpFormId($wpUserData['form_id']);
            $this->memberFormService->addFormPermissionToOrganization($complianceForm, $member);
        }



    }

    /**
     * Check options selected during signup and checkout process and 
     * enabled permissions to the forms based on the options they selected. 
     * 
     * Forms to be enabled access based on selected options: 
     * - fast501c3
     * - full501c3
     * - Articles of Incorporated (aoi)
     * - IEN
     *  
     * @param Member $member
     * @param unknown $wpUserData
     */
    private function addFormsPermissionsForNonProfitCheckout(Member $member, $wpUserData)
    {
        $signupPurchasedForms[] = '1023';
        $formRepo = $this->doctrine->getRepository('ProductBundle:Form');


        // Add permission to Articles of Incorporated Form if selected.
        if(isset($wpUserData['aoi_form'])) {
            $aoiForm = $formRepo->find($this->productForms['aoi']);
            $this->memberFormService->addFormPermissionToOrganization($aoiForm, $member, false);
            $signupPurchasedForms[] = 'aoi';
        }

        // Add permission to EIN Form if selected.
        if(isset($wpUserData['ein_form'])) {
            $einForm = $formRepo->find($this->productForms['ein']);
            $this->memberFormService->addFormPermissionToOrganization($einForm, $member, false);
            $signupPurchasedForms[] = 'ein';
        }

        if(isset($wpUserData['step2_option1']) && isset($wpUserData['step2_option2'])) {
            // Add permission to Fast 501(c)3 Form
            $fast501c3Form = $formRepo->find($this->productForms['fast501c3']);
            $this->memberFormService->addFormPermissionToOrganization($fast501c3Form, $member);

        } else {
            // Add permission to Full 501(c)3 Form
            $full501c3Form = $formRepo->find($this->productForms['full501c3']);
            $this->memberFormService->addFormPermissionToOrganization($full501c3Form, $member);
        }

        $eventKey = $this->signupPurchasedFormsToEventKey($signupPurchasedForms);
        $signupFormPurchasedEvent = $this->intercomEventMapper->getEventNameByKey($eventKey);
        $this->intercomClientService->createUserEvent($signupFormPurchasedEvent, $member->getUser());
    }

    /** 
     * @param array $forms
     * 
     * @return string
     */
    private function signupPurchasedFormsToEventKey(array $forms)
    {
        return implode('_', $forms);
    }
}