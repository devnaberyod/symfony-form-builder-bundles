<?php

namespace YPKY\MemberBundle\Services;

use Doctrine\Bundle\DoctrineBundle\Registry;

use Symfony\Component\HttpFoundation\Session\Session;

/**
 * @author  Kimberly Darl Barbadillo
 */
class FlashMessageService
{
    private $session;
 
    public function __construct(Session $session)
    {
        $this->session = $session;
    }

    public function showMessage($type, $message, $highlightedText = null)
    {
        $highlightedText = $highlightedText ?: $type;

        return $this->session->getFlashBag()->add($type, array('message' => $message, 'highlightedText' => $highlightedText));
    }

    /**
     * Show Error Message
     * 
     * @param string $message
     * @param string $highlightedText
     */
    public function showErrorMessage($message = '', $highlightedText = null)
    {
        return $this->showMessage('error', $message, $highlightedText);
    }

    /**
     * Show Success Message
     * 
     * @param string $message
     * @param string $highlightedText
     */
    public function showSuccessMessage($message = '', $highlightedText = null)
    {
        return $this->showMessage('success', $message, $highlightedText);
    }

    /**
     * Show Notice Message
     * 
     * @param string $message
     * @param string $highlightText
     */
    public function showNoticeMessage($message = '', $highlightText = null)
    {
        return $this->showMessage('warning', $message, $highlightedText);
    }
} 