<?php

/**
 * @author Adelbert Silla
 */

namespace YPKY\MemberBundle\Services;

class NewlyRegisteredMemberTourService
{
    /** 
     * @var MemberFormService
     */
    private $memberFormService;

    /** 
     * @var array
     */
    private $productForms;

    /** 
     * @var array
     */
    private $memberTourConfig;


    const FORM_NAME_PLACEHOLDER = '{FORM_NAME}';
    
    /**
     * set internal forms ids
     * 
     * @param array $productForms (this is from product.yml config)
     */
    public function setProductForms(array $productForms)
    {
        $this->productForms = $productForms;
    }


    /**
     * set internal forms ids
     *
     * @param array $memberTourConfig
     */
    public function setMemberTourConfig(array $memberTourConfig)
    {
        $this->memberTourConfig = $memberTourConfig;
    }

    /** 
     * @param MemberFormService $memberFormService
     */
    public function setMemberFormService(MemberFormService $memberFormService)
    {
        $this->memberFormService = $memberFormService;
    }
   
    public function getForms()
    {
        $newForms = $this->memberFormService->getNewMemberForms();
        $formsOrder = $this->memberTourConfig['forms_order'];
 
        $forms = array();
        foreach($formsOrder as $name) {
            $forms[$this->productForms[$name]] = array('alias' => $name, 'form' => null); 
        }
 
        foreach($newForms as $each) {
            if(isset($forms[$each->getId()])) {
                $forms[$each->getId()]['form'] = $each;
            }
        }

        foreach($forms as $key => $each) {
            if(is_null($each['form'])) {
                unset($forms[$key]);
            }
        }

        return $forms;
    }

    public function getMemberTourConfig()
    {
        $forms = $this->getForms();
        $productFormsAlias = array_flip($this->productForms);
        $stepsMessages = $this->memberTourConfig['steps_messages']; 

        $tourSteps[] = array(
            'element' => '#onboard-steps',
            'heading' => $this->memberTourConfig['intro']['heading'],
            'message' => $this->memberTourConfig['intro']['message'],
            'placement' => 'top'
        );

        $step = 1;
        foreach($forms as $id => $each) {
            if(!isset($stepsMessages[$productFormsAlias[$id]])) {
                $message = str_replace(self::FORM_NAME_PLACEHOLDER, $each['form']->getName(), $stepsMessages['default']);
            } else {
                $message = $stepsMessages[$productFormsAlias[$id]];
            }

            $tourSteps[] = array(
                'element' => '#' . $productFormsAlias[$id],
                'title' => 'Step ' . $step++,
                'message' => $message,
                'placement' => 'right'
            );
        }

        $tourSteps[] = array(
            'element' => '#personal-info',
            'title' => 'Step ' . $step++,
            'message' => $stepsMessages['member_profile'],
            'placement' => 'right'
        );

        $tourSteps[] = array(
            'element' => '#org-info',
            'title' => 'Step ' . $step++,
            'message' => $stepsMessages['organization_profile'],
            'placement' => 'right'
        );

        return $tourSteps;
    }
}