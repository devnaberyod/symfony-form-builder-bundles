<?php
namespace YPKY\MemberBundle\Services;

use YPKY\MemberBundle\Entity\Member;
use YPKY\MemberBundle\Entity\MemberForm;
use YPKY\MemberBundle\Entity\MemberFormAnswer;
use YPKY\MemberBundle\Entity\GlobalMemberAnswer;
use YPKY\MemberBundle\Entity\Organization;
use YPKY\MemberBundle\Classes\MemberInfo;
use YPKY\MemberBundle\Classes\OrganizationInfo;

use YPKY\ProductBundle\Entity\Form;
use YPKY\ProductBundle\Entity\QuestionTemplate;
use YPKY\ProductBundle\Entity\FormQuestion;
use Doctrine\Bundle\DoctrineBundle\Registry;

class InternalFormService
{
    /** 
     * @var Registry
     */
    private $doctrine;

    private $internalForms;

    private static $memberInfo;
    private static $organizationInfo;

    private static $globalAnswer = array();
    private static $memberAnswer = array();

    private $questionTemplateNames = array();
    
    public function setDoctrine(Registry $v)
    {
        $this->doctrine = $v;
    }
    
    /**
     * set internal forms ids
     * 
     * @param array $internalForms (this is from product.yml config)
     */
    public function setInternalForms($internalForms = array())
    {
        $this->internalForms = $internalForms;
    }

    public function setQuestionTemplateNames($questionTemplateName)
    {
        $this->questionTemplateNames = $questionTemplateName;
    }

    public function getMemberInfo(Member $member)
    {
        if(!static::$memberInfo) {
            $formId = $this->internalForms['member_profile'];
            $memberForm = $this->searchMemberFormAnswerByMemberAndForm($member, $formId);
            static::$memberInfo = new MemberInfo($memberForm);            
        }

        return static::$memberInfo;
    }
    
    public function getOrganizationInfo(Member $member)
    {
        if (!static::$organizationInfo) {
            $formId = $this->internalForms['organization_profile'];
            $memberForm = $this->searchMemberFormAnswerByMemberAndForm($member, $formId);
            static::$organizationInfo = new OrganizationInfo($memberForm);
        }
        return static::$organizationInfo;
    }

    public function getOrganizationAndMemberInfo(Member $member)
    {
        $formIdOrgProfile = $this->internalForms['organization_profile'];
        $formIdMemberProfile = $this->internalForms['member_profile'];
        $memberFormOrgInfo = $this->searchMemberFormAnswerByMemberAndForm($member, $formIdOrgProfile);
        $memberFormMemberInfo = $this->searchMemberFormAnswerByMemberAndForm($member, $formIdMemberProfile);
        return array('orgInfo' => new OrganizationInfo($memberFormOrgInfo), 'memberInfo' => new MemberInfo($memberFormMemberInfo));

    }
    
    private function searchMemberFormAnswerByMemberAndForm($member, $formId)
    {
        return $this->doctrine->getRepository('MemberBundle:MemberForm')->findMemberFormWithQuestionsAndAnswers($member, $formId);
    }

    public function getFormQuestionByName($formName = null , $formQuestionName = null)
    {
        $formId = $this->internalForms[$formName];

        $criteria = array('form' => $formId, 'name' => $formQuestionName);
        $formQuestion = $this->doctrine->getRepository('ProductBundle:FormQuestion')->findOneBy($criteria);
        
        return $formQuestion;
    }
    
    /**
     * Get InternalForm by name
     * 
     * @param unknown $name
     */
    public function getInternalFormByName($name)
    {
        $formId = $this->internalForms[$name];

        return $this->doctrine->getRepository('ProductBundle:Form')->find($formId);
    }

    /**
     * 
     * @return unknown
     */
    public function getInternalForms()
    {
        return $this->internalForms;
    }

    public function addFormOrgAndMemberPermission(Member $member)
    {
        $manager = $this->doctrine->getManager();
           $organization = $member->getOrganization();

        if (!$member->getOrganization()) {
            // create empty organization profile
            $organization = new \YPKY\MemberBundle\Entity\Organization;
            $organization->setDateCreated(new \DateTime('now'));
            $organization->setStatus(1);
            $manager->persist($organization);

            // set member organization
            $member->setOrganization($organization);
            $manager->persist($member);
        }

        $formOrgProfile = $this->getInternalFormByName('organization_profile');
        $criteriaOrgProfile = array('form' => $formOrgProfile, 'organization' => $organization);
           $orgProfile = $this->searchInternalForm($criteriaOrgProfile);
           
        if (!$orgProfile) {
            // add organization profile permission
            $organizationFormPermissionOrgProfile = new \YPKY\MemberBundle\Entity\OrganizationFormPermission;
            $organizationFormPermissionOrgProfile->setForm($formOrgProfile);
            $organizationFormPermissionOrgProfile->setOrganization($organization);
            $manager->persist($organizationFormPermissionOrgProfile);
        }
        
        $formMemberProfile = $this->getInternalFormByName('member_profile');
        $criteriaMemberProfile = array('form' => $formMemberProfile, 'organization' => $organization);
        $memberProfile = $this->searchInternalForm($criteriaMemberProfile);

        if (!$memberProfile) {
            // add member profile permission
            $organizationFormPermissionMemberProfile = new \YPKY\MemberBundle\Entity\OrganizationFormPermission;
            $organizationFormPermissionMemberProfile->setForm($formMemberProfile);
            $organizationFormPermissionMemberProfile->setOrganization($organization);
               $manager->persist($organizationFormPermissionMemberProfile);
        }
 
        $manager->flush();
    }

    private function searchInternalForm($criteria)
    {
        return $this->doctrine->getRepository('MemberBundle:OrganizationFormPermission')->findOneBy($criteria);
    }

    /*
        Method saveGlobalAndMemberFormAnswers
        @param MemberForm Entity, $formData Array
        @return none
    */
    public function saveGlobalAndMemberFormAnswers(MemberForm $memberForm, $formData)
    {
        $manager = $this->doctrine->getManager();
        $formQuestions = $this->doctrine->getRepository('ProductBundle:FormQuestion')->getFormQuestionsWithFormElementByForm($memberForm->getForm());
        
        if ($memberForm->getId()) {
            $this->mapGlobalAnswer($memberForm); //Map global answer
            $this->mapMemberAnswer($memberForm);  //Map member answer
        }

        foreach ($formQuestions as $key => $each) {
            if (isset($formData[$each->getQuestionTemplate()->getName()])) {
                $this->saveMemberGlobalAnswer($memberForm->getMember(), $each->getQuestionTemplate(), $formData[$each->getQuestionTemplate()->getName()]);
                $this->saveMemberFormAnswer($each, $memberForm, $formData[$each->getQuestionTemplate()->getName()]);
            }
        }
        
        $manager->flush();

        //update org name in organization table
        if (isset($formData[$this->questionTemplateNames['organization_profile']['information']['org_name']])) {
            $manager->getRepository('MemberBundle:Organization')->saveOrgNameByStoredProc($memberForm->getMember()->getOrganization(), $formData[$this->questionTemplateNames['organization_profile']['information']['org_name']]);
        }

        //update member in member table
        if (isset($formData[$this->questionTemplateNames['personal_profile']['first_name']]) || isset($formData[$this->questionTemplateNames['personal_profile']['last_name']])) {
            $lastName = isset($formData[$this->questionTemplateNames['personal_profile']['last_name']]) ? $formData[$this->questionTemplateNames['personal_profile']['last_name']] : '';
            $firstName = isset($formData[$this->questionTemplateNames['personal_profile']['first_name']]) ? $formData[$this->questionTemplateNames['personal_profile']['first_name']] : '';
            $name = $firstName . ' ' . $lastName;
            $manager->getRepository('MemberBundle:Member')->saveMemberNameByStoredProc($memberForm->getMember(), $name);
        }
    }

    /*
        Map Global Answer
        @param MemberForm Entity
    */
    private function mapGlobalAnswer(MemberForm $memberForm)
    {
        $globalAnswers = $this->doctrine->getRepository('MemberBundle:GlobalMemberAnswer')->findByMember($memberForm->getMember());
        if ($globalAnswers) {
            foreach ($globalAnswers as $each) {
                self::$globalAnswer[$each->getQuestionTemplate()->getName()] = $each;
            }
        }
    }

    /*
        Map Member Answer
        @param MemberForm Entity
    */
    private function mapMemberAnswer(MemberForm $memberForm)
    {
        $memberAnswers = $this->doctrine->getRepository('MemberBundle:MemberFormAnswer')->findAnswersByMemberForm($memberForm);
        if ($memberAnswers) {
            foreach ($memberAnswers as $each) {
                self::$memberAnswer[$each->getFormQuestion()->getId()][$memberForm->getId()] = $each;
            }
        }
    }
    /**
     * TODO: Refactor this Code. Queries inside the for loop is not advisable.
     * 
     * Save Organization Profile Information
     * 
     * @param Member Entity, $data array from form data submitted
     * @return none
    **/
    private function saveMemberGlobalAnswer(Member $member, QuestionTemplate $questionTemplate, $answer)
    {
        $manager = $this->doctrine->getManager();


        $globalAnswer = isset(self::$globalAnswer[$questionTemplate->getName()]) ? self::$globalAnswer[$questionTemplate->getName()] : null;

        if (!$globalAnswer) {
            $globalAnswer = new GlobalMemberAnswer();
        }

        $globalAnswer->setAnswer($answer);
        $globalAnswer->setMember($member);
        $globalAnswer->setQuestionTemplate($questionTemplate);
        $manager->persist($globalAnswer);

    }

    /*
        Save Member Form Answer
        @param QuestionTemplate Entity, Member Entity, answer string, Form Entity
        @return none
    */
    private function saveMemberFormAnswer(FormQuestion $formQuestion, MemberForm $memberForm, $answer)
    {
        $manager = $this->doctrine->getManager();

        $memberFormAnswer = null;
        if ($memberForm->getId()) {
            $memberFormAnswer = isset(self::$memberAnswer[$formQuestion->getId()][$memberForm->getId()]) ? self::$memberAnswer[$formQuestion->getId()][$memberForm->getId()] : null;
        }

        if (!$memberFormAnswer) {
            $memberFormAnswer = new MemberFormAnswer();
            $memberFormAnswer->setFormQuestion($formQuestion);
            $memberFormAnswer->setMemberForm($memberForm);
        }

        $memberFormAnswer->setAnswer($answer);
        $memberFormAnswer->setLastEditedBy($memberForm->getMember()->getId());

        $manager->persist($memberFormAnswer);

    }

    public function searchMemberAndOrganization($searchQuery = null, array $members)
    {
        $organizations = $orgEntities = array();
        $orgEntitiesSearch['org'][] = array();
        $orgEntitiesSearch['member'][] = array();
        $memberList = array();

        foreach ($members as $each) {

            $profile = $this->getOrganizationAndMemberInfo($each);
            if ($profile['memberInfo']->org_id() !== $searchQuery) continue;
            if ($profile['orgInfo'] && $profile['orgInfo']->org_name()) {
                
                if (!empty($searchQuery)
                    && stripos($profile['orgInfo']->org_name(), $searchQuery) === false
                    && stripos($profile['memberInfo']->organization(), $searchQuery) === false
                    && stripos($profile['memberInfo']->last_name(), $searchQuery) === false
                    && stripos($profile['memberInfo']->first_name(), $searchQuery) === false
                    && stripos($profile['memberInfo']->email(), $searchQuery) === false) continue;
                     
                $organizations[$each->getOrganization()->getId()] = array(
                    'name' => $profile['orgInfo']->org_name(),
                    'logo' => $profile['orgInfo']->org_logo()
                );
                
                $orgEntitiesSearch['org'][] = $each->getOrganization();
                $orgEntitiesSearch['member'][] = $this->mapMemberInfo($profile['memberInfo'], $profile['orgInfo']->org_name());

            } else {
                $organizations[$each->getOrganization()->getId()]['name'] = 'no name';
            }

            $orgEntitiesAll['org'][] = $each->getOrganization();
            $orgEntitiesAll['member'][] = $this->mapMemberInfo($profile['memberInfo'], $profile['orgInfo']->org_name());
        }

        $orgEntities = !empty($searchQuery) ? $orgEntitiesSearch : $orgEntitiesAll;

        return array('entities' => $orgEntities, 'organizations' => $organizations);

    }

    private function mapMemberInfo($memberInfo, $org = null)
    {
        if (!$memberInfo->email()) return;

        $dateCreated = (array)$memberInfo->date_created();
        $name = $memberInfo->first_name() . ' ' . $memberInfo->last_name();
        return array(
            'email' => $memberInfo->email(),
            'organization' => $org,
            'name' => $name,
            'dateCreated' => $memberInfo->date_created() ? $dateCreated['date'] : ''
        );
    }

    public function saveOrgNameStoredProc(Organization $org, $newOrgName)
    {
        $em = $this->doctrine->getManager();
        $storedProc = $em->getConnection()->prepare('CALL update_org_name(:id, :name)');
        $storedProc->bindValue('id', $org->getId(), \PDO::PARAM_INT);
        $storedProc->bindValue('name', $newOrgName, \PDO::PARAM_STR);
        $storedProc->execute();
    }

}