<?php
namespace YPKY\MemberBundle\Services;

use Doctrine\Bundle\DoctrineBundle\Registry;
use YPKY\MemberBundle\Entity\Member;
use Symfony\Component\Form\Form as SymfonyForm;
use YPKY\ProductBundle\Entity\Form as FormEntity;
use YPKY\MemberBundle\Entity\MemberForm;
use YPKY\MemberBundle\Exception\MemberFormException;
use YPKY\MemberBundle\Entity\MemberFormAnswer;
use YPKY\FormBuilderBundle\Services\FileUploaderInterface;
use YPKY\ProductBundle\Entity\Form;
use YPKY\ProductBundle\Entity\FormSection;
use YPKY\MemberBundle\Entity\GlobalMemberAnswer;
use YPKY\ProductBundle\Entity\FormQuestion;
use Symfony\Component\Security\Core\SecurityContext;
use YPKY\FormBuilderBundle\Form\CustomFormElementType;
use YPKY\MemberBundle\Entity\Organization;
use YPKY\AdminBundle\Entity\City;
use YPKY\FormBuilderBundle\Services\FormProductFactory;
use YPKY\MemberBundle\Entity\OrganizationFormPermission;

class MemberFormService
{ 
    static $globalMemberAnswers = array();
    
    /**
     * @var Registry
     */
    private $doctrine;
    
    /**
     * @param SecurityContext $v
     */
    private $securityContext;
    
    /** 
     * @param Member $member
     */
    private $member;

    private $formFields = array();

    public function setDoctrine(Registry $v)
    {
        $this->doctrine = $v;
    }

    public function setFileUploadService(FileUploaderInterface $fileUploadService)
    {
        $this->fileUploadService = $fileUploadService;
    }

    function setSecurityContext(SecurityContext $securityContext)
    {
        $this->securityContext = $securityContext;

        // FIXME: Condition is not required. Api service shouldn't use this service.
        if($this->securityContext->getToken()) {
            $member = $this->securityContext->getToken()->getUser()->getUser()->getMember();
            if($member)
                $this->setMember($member);
        }
    }

    function setMember(Member $member)
    {
        $this->member = $member;
    }

    function setFormFields($formFields)
    {
        $this->formFields = $formFields;
    }
    
    /**
     * set internal forms ids
     *
     * @param unknown $internalForms (this is from product.yml config)
     */
    public function setInternalForms($internalForms = array())
    {
        $this->internalForms = $internalForms;
    }

    public function getMember()
    {
        return $this->member;
    }

    public function getInternalForms() 
    {
        return $this->internalForms;
    }
    
    /**
     * Get MemberForm by Form
     *  
     * @param Form $formEntity
     * @return MemberForm $memberForm
     */
    public function getMemberForm(Form $formEntity)
    {
        $criteria = array('member' => $this->member, 'form' => $formEntity);

        return $this->doctrine->getRepository('MemberBundle:MemberForm')->findOneBy($criteria);
    }

    public function getNewMemberForms()
    {
        $memberForms = $this->doctrine->getRepository('MemberBundle:MemberForm')->findByMember($this->member);

        $memberFormIds = array();
        foreach($memberForms as $each) {
            array_push($memberFormIds, $each->getForm()->getId());
        }

        $newMemberForms = array();
        $organization = $this->member->getOrganization();
        if ($organization) {
            $newMemberForms = $this->doctrine->getRepository('MemberBundle:OrganizationFormPermission')->getNewMemberFormsByOrganization($organization, $memberFormIds);
        }

        return $newMemberForms;
    }

    public function prepareMemberForm(FormEntity $formEntity, Member $member = null)
    {
        if($member) {
            $this->member = $member;
        }

        $memberForm = $this->doctrine->getRepository('MemberBundle:MemberForm')
        ->findByMemberAndForm($this->member, $formEntity);

        if (!$memberForm) {
            $memberForm = new MemberForm();
            $memberForm->setMember($this->member);
            $memberForm->setForm($formEntity);
            $memberForm->setcurrentPage(1);
            $memberForm->setDateCreated(new \DateTime('now'));
            $memberForm->setStatus(1);
        }

        return $memberForm;
    }

    public function saveMemberFormEntity(MemberForm $memberForm, FormSection $formSection, $incrementPage = false)
    {
        $manager = $this->doctrine->getManager();

        $currentPage = $incrementPage ? $formSection->getPosition() + 1 : $formSection->getPosition();

        // check if this user already sumbitted answers for this form
        $memberForm->setCurrentPage($currentPage);
        $memberForm->setDateModified(new \DateTime('now'));

        $manager->persist($memberForm);

        $manager->flush();

        return $memberForm;
    }

    public function saveMemberFormAnswers(MemberForm $memberForm, FormSection $formSection, SymfonyForm $form, array $files)
    {
        $manager = $this->doctrine->getManager();
        $member = $memberForm->getMember();
        $memberFormId = $memberForm->getId();
        $memberOrgName = null;
        $memberLastName = null;
        $memberFirstName = null;
        // Get All Form Questions of Current Form Page
        $formQuestions = $this->doctrine->getRepository('ProductBundle:FormQuestion')->findByFormSection($formSection);
        foreach($formQuestions as $each) {
            $formQuestions[$each->getId()] = $each;
            if ($this->formFields['org_name'] == $each->getQuestionTemplate()->getId()) $memberOrgName = $each->getId();
            if ($this->formFields['last_name'] == $each->getQuestionTemplate()->getId()) $memberLastName = $each->getId();
            if ($this->formFields['first_name'] == $each->getQuestionTemplate()->getId()) $memberFirstName = $each->getId();
        }

        // Get All MemberFormAnswers 
        $memberFormAnswers = array();
        $answers = $this->doctrine->getRepository('MemberBundle:MemberFormAnswer')->findByMemberForm($memberForm);
        foreach($answers as $each) {
            $memberFormAnswers[$each->getFormQuestion()->getId() .'_'. $memberFormId] = $each;
        }

        // create member form answers
        foreach ($form->all() as $child) {

            if($child->getConfig()->getType()->getName() == CustomFormElementType::ALIAS) {
                continue;                
            }

            list($placeholder, $formQuestionId) = explode(FormProductFactory::FIELD_SEPARATOR, $child->getName());
        
            if (!isset($formQuestions[$formQuestionId])) {
                throw MemberFormException::submittedInvalidFormQuestion($formQuestionId);
            } else {
                $formQuestionEntity = $formQuestions[$formQuestionId];
            }
        
            $questionTemplate = $formQuestionEntity->getQuestionTemplate();
            
            $answer = $this->getAnswer($child);

            $widgetMetaData = json_decode($questionTemplate->getWidgetMetadata(), true);

            /**
             * @todo  improve 
             */
            $isFileWidget = isset($widgetMetaData['widget_id']) && strpos($widgetMetaData['widget_id'], 'file') !== false;
            if ($isFileWidget) {
                if(!is_object($files['form'][$child->getName()])) {
                    continue;
                }

                /**
                 * @todo  improve this. Assumed $files[form] as the uploaded files.
                 */
                if (isset($files['form'][$child->getName()])) {
                    $answer = $this->fileUploadService->uploadFile($files['form'][$child->getName()]);
                }
            }
        
            if(isset($memberFormAnswers[$formQuestionId .'_'. $memberFormId])) {
                $memberFormAnswer = $memberFormAnswers[$formQuestionId .'_'. $memberFormId];
            } else {
                $memberFormAnswer = new MemberFormAnswer();
                $memberFormAnswer->setFormQuestion($formQuestionEntity);
                $memberFormAnswer->setMemberForm($memberForm);
            }

            $memberFormAnswer->setAnswer($answer);
            $memberFormAnswer->setLastEditedBy($member->getUser()->getId());
            $manager->persist($memberFormAnswer);

            // TODO: Not needed to add answer
            $memberForm->addMemberFormAnswer($memberFormAnswer);

            // Persist to Save/Update GlobalAnswers
            $this->persistMemberGlobalAnswers($formQuestionEntity, $memberForm, $answer);
        }

        $manager->flush();
       
        //update org name in Organization table
        if (isset($memberFormAnswers[$memberOrgName .'_'. $memberFormId])) {
            $manager->getRepository('MemberBundle:Organization')->saveOrgNameByStoredProc($memberForm->getMember()->getOrganization(), $memberFormAnswers[$memberOrgName .'_'. $memberFormId]->getAnswer());
        }
        
        //update name in Member table
        if (isset($memberFormAnswers[$memberLastName .'_'. $memberFormId]) || isset($memberFormAnswers[$memberLastName .'_'. $memberFormId])) {
            $lastName = isset($memberFormAnswers[$memberLastName .'_'. $memberFormId]) ? $memberFormAnswers[$memberLastName .'_'. $memberFormId]->getAnswer() : '';
            $firstName = isset($memberFormAnswers[$memberLastName .'_'. $memberFormId]) ? $memberFormAnswers[$memberFirstName .'_'. $memberFormId]->getAnswer() : '';
            $name = $firstName . ' ' . $lastName;
            $manager->getRepository('MemberBundle:Member')->saveMemberNameByStoredProc($memberForm->getMember(), $name);
        }

    }
    
    private function getAnswer($child)
    {
        $answer = $child->getData();
       
        if (\is_object($child->getData())) {
            // FIXME: Find a better way to normalize entity data
            try {
                if(property_exists($child->getData(), 'Id')) {
                    $answer = $child->getData()->getId();
                } else {
                    $answer = (string)$child->getData();
                }
            }
            catch (\Exception $e) {
                throw MemberFormException::entityCannotBeConvertedToString($child->getData());
            }
        }
        
        if (is_null($answer)) {
            $answer = '';
        }

        return $answer;
    }
    
    private function persistMemberGlobalAnswers(FormQuestion $formQuestionEntity, MemberForm $memberForm, $answer)
    {
        $manager = $this->doctrine->getManager();
        $questionTemplate = $formQuestionEntity->getQuestionTemplate();

        if(empty(static::$globalMemberAnswers)) {
            // Get All GlobalMemberAnswers
            $globalMemberAnswers = $this->doctrine->getRepository('MemberBundle:GlobalMemberAnswer')->findByMember($memberForm->getMember());
            foreach($globalMemberAnswers as $each) {
                static::$globalMemberAnswers[$each->getQuestionTemplate()->getId()] = $each;
            }            
        }

        // Save/Update Answers in GlobalMemberAnswer
        if($formQuestionEntity->getIsGlobal()) {
            if(isset(static::$globalMemberAnswers[$questionTemplate->getId()])) {
                $globalMemberAnswer = static::$globalMemberAnswers[$questionTemplate->getId()];
            } else {
                $globalMemberAnswer = new GlobalMemberAnswer();
                $globalMemberAnswer->setMember($this->member);
                $globalMemberAnswer->setQuestionTemplate($questionTemplate);
                static::$globalMemberAnswers[$questionTemplate->getId()] = $globalMemberAnswer;
            }

            if ($answer !== null) {
                $globalMemberAnswer->setAnswer($answer);
                $manager->persist($globalMemberAnswer);              
            }

            // Persist Entities to Update MemberFormAnswers with the same QuestionTemplate
            $this->doctrine->getRepository('MemberBundle:MemberFormAnswer')->updateMemberAnswersByQuestionTemplate($memberForm->getMember(),$questionTemplate, $answer, false);
        }
    }

    private function normalizeNonScalarData($data)
    {

    }

    public function clearMemberFormAnswers(MemberForm $memberForm, FormSection $formSection)
    {
        $this->doctrine->getRepository('MemberBundle:MemberFormAnswer')
            ->deleteByMemberFormAndFormSection($memberForm, $formSection);
    }

    public function saveMemberName(Member $member, $name)
    {
        $manager = $this->doctrine->getManager();
        $fullName = $name['first_name'] . ' ' . $name['last_name'];

        $globalMemberAnswerLastname = new GlobalMemberAnswer();
        $globalMemberAnswerLastname->setMember($member);
        $globalMemberAnswerLastname->setQuestionTemplate($this->findQuestionTemplate($this->formFields['last_name']));
        $globalMemberAnswerLastname->setAnswer($name['last_name']);

        $globalMemberAnswerFirstname = new GlobalMemberAnswer();
        $globalMemberAnswerFirstname->setMember($member);
        $globalMemberAnswerFirstname->setQuestionTemplate($this->findQuestionTemplate($this->formFields['first_name']));
        $globalMemberAnswerFirstname->setAnswer($name['first_name']);

        $manager->persist($globalMemberAnswerLastname);
        $manager->persist($globalMemberAnswerFirstname);
        $manager->persist($member->setName($fullName));
        $manager->flush();
    }

    public function getActiveForms()
    {
        $organization = $this->member->getOrganization();
        $organizationForms = array();

        if ($organization) {
            $organizationForms =  $this->doctrine->getRepository('MemberBundle:OrganizationFormPermission')->getFormsByOrganization($organization);
        }

        return $organizationForms;
    }

    /**
     * Group form by internalForms and productForms
     * 
     * @param array $forms
     * @return array 
     */
    public function groupForms($forms = array())
    {
        $internalForms = array();
        $internalFormsIds = array_flip($this->internalForms);
        foreach($forms as $i => $each) {
            if(isset($internalFormsIds[$each->getId()])) {
                $internalForms[$each->getId()] = $each;
                unset($forms[$i]);
            }
        }

        return array('productForms' => $forms, 'internalForms' => $internalForms);
    }

    // TODO: Move to proper service location
    public function addFormPermissionToOrganization(Form $form, Member $member, $flush = true)
    {
        try {
            $org = $member->getOrganization();
            $organizationFormAccess = new OrganizationFormPermission();
            $organizationFormAccess->setForm($form);
            $organizationFormAccess->setOrganization($org);
            $organizationFormAccess->setDateCreated(new \DateTime());
    
            $em = $this->doctrine->getManager();
            $em->persist($organizationFormAccess);
            if(!$org->getId()) {
                $em->persist($org);
                $em->persist($member);
            }
    
            if($flush) {
                $em->flush();
            }
        }
        catch (\Exception $e) {}
    }
    
    public function endMemberTour(Member $member)
    {
        $member->setHasTakenTour(1);

        $em = $this->doctrine->getManager();
        $em->persist($member);
        $em->flush();
    }

    private function findQuestionTemplate($id)
    {
        return $this->doctrine->getRepository('ProductBundle:QuestionTemplate')
                ->find($id);
    }
}
