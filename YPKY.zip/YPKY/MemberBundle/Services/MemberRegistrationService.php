<?php

namespace YPKY\MemberBundle\Services;

use Doctrine\ORM\EntityManager;

use YPKY\UserBundle\Services\UserService;
/**
 * @author  Farly
 */
class MemberRegistrationService
{

    private $userService;


    public function setUserService(UserService $userService)
    {
        $this->userService = $userService;

        return $this;
    }


    public function setEntityManager(EntityManager $entityManager)
    {
        $this->entityManager = $entityManager;

        return $this;
    }


    public function registerMember($user)
    {

        $isArray = is_array($user);

        $user = $this->userService->setUser($isArray ? new \YPKY\UserBundle\Entity\User() : $user)
                            ->setSalt(md5(time()))
                            ->setEmail($isArray ? $user['email'] : $user->getEmail())
                            ->setPassword($isArray ?  $user['password'] : $user->getPassword())
                            ->setStatus(\YPKY\UserBundle\Classes\UserConstants::ACTIVE)
                            ->setDateCreated(new \DateTime())
                            ->getUser();

        $this->entityManager->persist($user);                    
        $this->entityManager->flush();

        $member = new \YPKY\MemberBundle\Entity\Member();
        $member->setUser($user);
        
        $this->entityManager->persist($member);
        $this->entityManager->flush();

        return $member;
    }
}