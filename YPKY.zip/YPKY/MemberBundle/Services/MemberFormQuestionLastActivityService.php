<?php

namespace YPKY\MemberBundle\Services;

use Doctrine\ORM\EntityManager;
use Doctrine\Bundle\DoctrineBundle\Registry;
use Doctrine\ORM\Query;
use YPKY\MemberBundle\Entity\Member;
use YPKY\ProductBundle\Entity\Form;
use YPKY\MemberBundle\Entity\MemberFormQuestionLastActivity;

/*
    Class MemberFormQuestionLastActivity Service
    @author Diovannie
*/
class MemberFormQuestionLastActivityService
{

    private $em;
    private $doctrine;

    private $defaultRenderConfiguration;

    /*
        Entity Manager function setter
    */
    public function setEntityManager(EntityManager $em)
    {
        $this->em = $em;
    }
    
    /*
        Doctrine Manager function setter
    */
    public function setDoctrine(Registry $doctrine)
    {
        $this->doctrine = $doctrine;
    }

    public function getMemberFormQuestionLastActivityByMember(Member $member)
    {
        return $this->doctrine->getRepository('MemberBundle:MemberFormQuestionLastActivity')->findOneByMember($member);
    }

    /*
        Save Member Form Question Last Activity
        $param MemberFormLastActivity Entity
        $return int id
    */
    public function saveFormQuestionLastActivity(MemberFormQuestionLastActivity $entity)
    {
        $entity->setDateCreated(new \DateTime());
        $this->em->persist($entity);
        $this->em->flush();

        return $entity->getId();
    }

    /*
        Update Member Form Question Last activity
        @param Member Entity, array Form Data, int LastFormQuestionId
        @return none
    */
    public function updateMemberFormLastActivity(Member $member, $formData, $lastFormQuestionIdWorking)
    {
        $isCompleteFormData = $this->isCompleteFormData($formData);

        if ($isCompleteFormData) {
            $lastFormQuestionActivity = $this->getMemberFormQuestionLastActivityByMember($member);
            if ($lastFormQuestionActivity) {
                $this->em->remove($lastFormQuestionActivity);
                $this->em->flush();
            }
        } else {
            $this->saveFormQuestionLastActivityAction($lastFormQuestionIdWorking, $member);
        }
        
    }

    /*
        Check form data completeness
        @return boolean
        @todo checking of Boolean data in the form might not work - Need thourough testing
    */
    private function isCompleteFormData($data)
    {
        $isComplete = true;

        foreach ($data as $key => $value) {
            if (is_null($value) || $value == '') {
                $isComplete = false;
                break;
            }
        }

        return $isComplete;
    }   

    /*
        Save Last Form Question activity
        @return none
    */
    private function saveFormQuestionLastActivityAction($formQuestionId, Member $member)
    {
        if (isset($formQuestionId)) {

            $formQuestionEntity = $this->doctrine->getRepository('ProductBundle:FormQuestion')->find($formQuestionId);
            $memberFormQuestionLastActivityEntity = $this->getMemberFormQuestionLastActivityByMember($member);
                                                 
                if ($memberFormQuestionLastActivityEntity) {
                    $memberFormQuestionLastActivityEntity->setMember($member);
                    $memberFormQuestionLastActivityEntity->setFormQuestion($formQuestionEntity);
                } else {
                    $memberFormQuestionLastActivityEntity = new MemberFormQuestionLastActivity();
                    $memberFormQuestionLastActivityEntity->setMember($member);
                    $memberFormQuestionLastActivityEntity->setFormQuestion($formQuestionEntity);
                }
                
                //Save Form Question Last Actvity   
                $this->saveFormQuestionLastActivity($memberFormQuestionLastActivityEntity);

        } else {
            throw new Exception("Form Question id not found", 1);
        }
    }

}
