<?php

namespace YPKY\MemberBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class MemberBundle extends Bundle
{
}
