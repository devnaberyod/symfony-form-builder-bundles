<?php

namespace YPKY\MemberBundle\Classes;

use YPKY\MemberBundle\Entity\MemberForm;

abstract class InternalFormInfo
{
    private $isComplete = true;
    private $formInfo = array();

    public function __construct(MemberForm $memberForm = null)
    {
        if($memberForm) {
            $formQuestions = $memberForm->getForm()->getFormQuestions();
            $memberFormAnswers = $memberForm->getMemberFormAnswers();
            $memberFormAnswersArr = array();

            foreach($memberFormAnswers as $each) {
                $memberFormAnswersArr[$each->getFormQuestion()->getId()] = $each->getAnswer();
            }
            
            foreach($formQuestions as $each) {
                if(isset($memberFormAnswersArr[$each->getId()]) && $memberFormAnswersArr[$each->getId()]) {
                    $this->formInfo[$each->getName()] = $memberFormAnswersArr[$each->getId()]; 
                } else {
                    $this->formInfo[$each->getName()] = '';
                    $this->isComplete = false;
                }
            }
        } else {
            $this->isComplete = false;
        }
    }

    /**
     * @todo use __set and __get if neccessary
     */
    public function __call($name, $arguments)
    {
        return isset($this->formInfo[$name]) ? $this->formInfo[$name] : null;
    }

    public function isComplete()
    {
        return $this->isComplete;
    }

    public function all()
    {
        return $this->formInfo;
    }
}