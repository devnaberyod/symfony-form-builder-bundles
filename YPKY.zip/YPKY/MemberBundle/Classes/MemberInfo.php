<?php

namespace YPKY\MemberBundle\Classes;

class MemberInfo extends InternalFormInfo
{
    
}