<?php


namespace YPKY\MemberBundle\Classes;


class OrganizationInfo extends InternalFormInfo
{

}