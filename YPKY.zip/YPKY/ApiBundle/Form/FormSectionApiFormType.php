<?php
namespace YPKY\ApiBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;
use Symfony\Component\Validator\Constraints\NotBlank;

/**
 * FormSection form that will specifically be used by API
 *
 * @author Allejo Chris G. Velarde
 *
 */
class FormSectionApiFormType extends AbstractType
{
    const NAME = 'form_section';

    public function getName()
    {
        return self::NAME;
    }

    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder->add('name', null, array('constraints' => array(new NotBlank())))
            ->add('description')
            ->add('position');
    }

    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(array(
        	'csrf_protection' => false
        ));


    }
}