<?php
namespace YPKY\ApiBundle\Form;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;
use Symfony\Component\Validator\Constraints\NotBlank;

/**
 * Dedicated form for API use.
 *
 * @author Allejo Chris G. Velarde
 *
 */
class FormQuestionApiFormType extends AbstractType
{
    private $excludedFields = array();

    /**
     * @var FormBuilderInterface
     */
    private $builder;

    public function getName()
    {
        return 'formQuestion';
    }

    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(array(
        	'csrf_protection' => false,
            'data_class' => 'YPKY\ProductBundle\Entity\FormQuestion',
            'excluded_fields' => array()
        ));
    }

    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $this->excludedFields = $options['excluded_fields'];
        $this->builder = $builder;

        $this
            ->_add('question')
            ->_add('name', null, array(
                'constraints' => array(new NotBlank())
            ))
            ->_add('example', null, array(
                //'constraints' => array(new NotBlank())
            ))
            ->_add('notes', null, array(
                //'constraints' => array(new NotBlank())
            ))
            ->_add('helpText', null, array(
                //'constraints' => array(new NotBlank())
            ))
            ->_add('subLabel', null, array(
                //'constraints' => array(new NotBlank())
            ))
            ->_add('form', null, array('property' => 'name'))
            ->_add('formElement', null, array('property' => 'text'))
            
            ->_add('isGlobal', null, array())
        ;
            
        if(!isset($options['data']) || !$options['data']->getId()) {
            $this->_add('questionTemplate', null, array('property' => 'name'));
        }
    }

    /**
     *
     * @return \YPKY\ApiBundle\Form\FormQuestionApiFormType
     */
    private function _add($field, $formType=null, $options=array())
    {
        if (!in_array($field, $this->excludedFields)) {
        	$this->builder->add($field, $formType, $options);
        }

        return $this;
    }
}