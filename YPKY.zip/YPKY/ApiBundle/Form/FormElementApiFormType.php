<?php
namespace YPKY\ApiBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;
use Symfony\Component\Validator\Constraints\NotBlank;

/**
 * Dedicated FormType for FormElement for API use
 *
 * @author Allejo Chris G. Velarde
 * @author Floricel Colibao
 */
class FormElementApiFormType extends AbstractType
{

    private $excludedFields = array();

    /**
     * @var FormBuilderInterface
     */
    private $builder;

    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(array(
        	'csrf_protection' => false,
            'data_class' => 'YPKY\ProductBundle\Entity\FormElement',
            'excluded_fields' => array()
        ));
    }

    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $this->builder = $builder;
        $this->excludedFields = $options['excluded_fields'];
        $this->builder
            ->add('elementType', null, array(
                'constraints' => array(new NotBlank())
            ))
            ->add('text', null, array(
                'constraints' => array()
            ))
            ->add('position', null, array(
                'constraints' => array(new NotBlank())
            ))
            ->add('renderConfig', null, array(
                'constraints' => array()
            ))
            ->add('widgetMetadata')
            ->add('form', null, array(
                'property' => 'name',
                'constraints' => array()
            ))
            ->add('formSection', null, array(
                'property' => 'name',
                'constraints' => array(new NotBlank())
            ))
            ->add('isHiddenToMember')
            ->add('isLocked')
        ;

        $this->_add('formQuestion',new FormQuestionApiFormType(), array(
        	'mapped' => false,
            'excluded_fields' => array('formElement'),
            'error_bubbling' => true
        ));
    }

    private function _add($field, $formType=null, $options=array())
    {
        if (!in_array($field, $this->excludedFields)) {
            $this->builder->add($field, $formType, $options);
        }

        return $this;
    }

    public function getName()
    {
        return 'formElement';
    }
}