<?php
namespace YPKY\ApiBundle\Controller;

use Chromedia\SecurityTokenBundle\Controller\TokenAuthenticatedController;

class AuthenticatedApiController extends ApiController implements TokenAuthenticatedController
{

}