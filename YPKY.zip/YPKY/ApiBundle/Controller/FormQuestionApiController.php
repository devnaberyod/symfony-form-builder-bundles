<?php
namespace YPKY\ApiBundle\Controller;

use Symfony\Component\HttpFoundation\Request;

use YPKY\ApiBundle\Controller\AuthenticatedApiController;
use YPKY\ProductBundle\Repository\FormQuestionRepository;
use YPKY\ProductBundle\Form\FormQuestionType;
use YPKY\ProductBundle\Entity\FormQuestion;
use YPKY\ApiBundle\Form\FormQuestionApiFormType;

class FormQuestionApiController extends AuthenticatedApiController
{
    public function indexAction(Request $request)
    {
        $filters = array();

        if ($formId = $request->get('form_id')) {
            $formEntity = $this->validateEntityFromRequest($formId, 'ProductBundle:Form');

            $filters['form'] = $formEntity->getId();
        }

        $data = $this->getDoctrine()->getRepository('ProductBundle:FormQuestion')
            ->findWithFilters($filters);

        return array(
            'data' => $data
        );
    }

    public function getAction(Request $request)
    {
        $formQuestion = $this->validateEntityFromRequest($request->get('id', 0), 'ProductBundle:FormQuestion');

        return $this->get('helper.entity_serializer')->toArray($formQuestion);
    }

    public function postNewAction(Request $request)
    {
        $formQuestion = new FormQuestion();

        $apiForm = $this->createForm(new FormQuestionApiFormType(), $formQuestion);
        $apiForm->submit($request->request->all());

        if ($apiForm->isValid()) {
            $formQuestion->setIsGlobal(true);

            $this->getDoctrine()->getRepository('ProductBundle:FormQuestion')->save($formQuestion);

            $viewData = $formQuestion;
        }
        else {
            $viewData = $apiForm;
        }

        return $viewData;
    }

    public function putEditAction(Request $request)
    {
        try {
            $formQuestion = $this->validateEntityFromRequest($request->get('id', 0), 'ProductBundle:FormQuestion');

            $apiForm = $this->createForm(new FormQuestionApiFormType(), $formQuestion);

            $apiForm->submit($request->request->all());

            if ($apiForm->isValid()) {
                $em = $this->getDoctrine()->getManager();

                $em->getRepository('ProductBundle:FormQuestion')->save($formQuestion);

                return $this->get('helper.entity_serializer')->toArray($formQuestion);
            } else {
                return $apiForm;
            }

        } catch(\Exception $e) {
            throw $e;
        }
    }

    public function doDeleteAction(Request $request)
    {
        try {
            $formQuestion = $this->validateEntityFromRequest($request->get('id', 0), 'ProductBundle:FormQuestion');

            $this->getDoctrine()->getRepository('ProductBundle:FormQuestion')
                ->remove($formQuestion);

            return array('success' => true);
        } catch(\Exception $e) {
            throw $e;
        }
    }

    /**
     * Saves form data
     */

    /**
     * Creates form for form question
     */
    private function createFormQuestionForm($formQuestion, $method = 'POST')
    {
        return $this->createForm(new FormQuestionType(), $formQuestion, array(
            'method' => $method,
            'csrf_protection' => false
        ));
    }
    
    /*
    Get Related form question forms
    */
    public function getRelatedFormQuestionAction(Request $request)
    {
        $formQuestion = $this->validateEntityFromRequest($request->get('id', 0), 'ProductBundle:FormQuestion');

        $repo = $this->getDoctrine()->getRepository('ProductBundle:FormQuestion');
        $relatedFormQuestions = $repo->getRelatedFormQuestion($formQuestion);

        return $relatedFormQuestions;
    }
}