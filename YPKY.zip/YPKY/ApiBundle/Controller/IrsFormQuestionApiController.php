<?php
namespace YPKY\ApiBundle\Controller;

use YPKY\ApiBundle\Controller\AuthenticatedApiController;
use Symfony\Component\HttpFoundation\Request;
use YPKY\ProductBundle\Form\IrsFormQuestionType;
use FOS\RestBundle\View\View;
use YPKY\ProductBundle\Entity\FormQuestion;
use YPKY\ProductBundle\Entity\IrsFormQuestion;

/**
 *
 * @author Diovannie / Adelbert Silla
 *
 */
class IrsFormQuestionApiController extends AuthenticatedApiController
{
    /**
     * Create new irsFormQuestion
     * 
     * @param Request $request
     * 
     * @return array
     */
    public function postCreateAction(Request $request)
    {   
        // Validate formQuestion
        $formQuestion = $this->validateEntityFromRequest($request->get('form_question_id'), 'ProductBundle:FormQuestion');

        $irsFormQuestion = new IrsFormQuestion();
        $form = $this->createForm(new IrsFormQuestionType(), $irsFormQuestion, array('csrf_protection' => false));

        $postParameters = $request->request->all();
        $form->submit($postParameters);

        if ($form->isValid()) {
            $irsFormQuestionRepo = $this->getDoctrine()->getRepository('ProductBundle:IrsFormQuestion');

            // Creates new irsFormQuestion and link it to a formQuestion.
            $irsFormQuestionRepo->saveAndLinkToFormQuestion($irsFormQuestion, $formQuestion);

            $view = View::create();
            $view->setData($irsFormQuestion);

            return $view;
        }
        else {
            $viewData = $form;
        }

        return $viewData;
    }

    /** 
     * @param Request $request
     * 
     * @return array
     */
    public function putEditAction(Request $request)
    {
        $entityAlias = 'ProductBundle:IrsFormQuestion';
        $formQuestion = $this->validateEntityFromRequest($request->get('form_question_id'), 'ProductBundle:FormQuestion');
        $irsFormQuestion = $this->validateEntityFromRequest($request->get('id'), $entityAlias);

        $form = $this->createForm(new IrsFormQuestionType(), $irsFormQuestion, array('csrf_protection' => false));
        $formData = $request->request->all();

        $form->submit($formData);

        if ($form->isValid()) {
            // Update irsFormQuestion and link it to a formQuestion.
            $this->getDoctrine()->getRepository($entityAlias)->saveAndLinkToFormQuestion($irsFormQuestion, $formQuestion);

            $viewData = $irsFormQuestion;
        }
        else {
            $viewData = $form;
        }

        return $viewData;
    }
}
