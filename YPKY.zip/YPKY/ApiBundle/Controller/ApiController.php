<?php
namespace YPKY\ApiBundle\Controller;

use FOS\RestBundle\Controller\FOSRestController;
abstract class ApiController extends FOSRestController
{
    /**
     * Convenience function to check entity
     *
     * @param int $key
     * @param string $entityShortName
     * @return Ambigous <NULL, object>
     */
    protected function validateEntityFromRequest($id, $entityShortName)
    {
        $entity = null;
        if ($id){
            $entity = $this->getDoctrine()->getRepository($entityShortName)->find($id);
        }

        if (!$entity) {
            throw $this->createNotFoundException("Invalid id:{$id} for {$entityShortName}.");
        }

        return $entity;
    }

    /**
     *
     * @param array $knownFilters
     * @return array
     */
    protected function applyFiltersFromRequest(array $knownFilters=array())
    {
        $request = $this->getRequest();

        $appliedFilters = array();
        foreach ($knownFilters as $key) {
            $val = $request->get($key, null);
            if (!\is_null($val)) {
                $appliedFilters[$key] = $val;
            }
        }

        return $appliedFilters;
    }
}