<?php
namespace YPKY\ApiBundle\Controller;

use YPKY\ApiBundle\Controller\AuthenticatedApiController;
use YPKY\ProductBundle\Form\QuestionTemplateType;
use YPKY\ProductBundle\Repository\QuestionTemplateRepository;
use YPKY\ProductBundle\Entity\QuestionTemplate;

use Symfony\Component\HttpFoundation\Request;
use Doctrine\ORM\Query;

class QuestionTemplateApiController extends AuthenticatedApiController
{
    /**
     *
     * @param Request $request
     * @return \Symfony\Component\HttpFoundation\Response
     */
    public function indexAction(Request $request)
    {
        $data = $this->getDoctrine()->getRepository('ProductBundle:QuestionTemplate')
            ->findWithFilters(array(), Query::HYDRATE_ARRAY);

        // check with_form_element_prototype flag
        if (1 == (int)$request->get('with_form_element_prototype', 0)) {
            $formElementService = $this->get('product.form_element_service');
            // build a form element prototype for this question template
            foreach ($data as &$questionTemplate) {
                $formElement = $formElementService->createPrototypeFromQuestionTemplate($questionTemplate);
                $questionTemplate['formElementPrototype'] = $formElement;
            }
        }

        $view = $this->view(array(
        	'data' => $data
        ));

        $view->setFormat('json');

        return $this->handleView($view);
    }

    /**
     *
     * @param Request $request
     * @return \Symfony\Component\HttpFoundation\Response
     */
    public function getAction(Request $request)
    {
        $questionTemplate = $this->validateEntityFromRequest($request->get('id', 0));

        return $this->get('helper.entity_serializer')->toArray($questionTemplate);
    }

    /**
     * Creates queston template
     */
    public function postNewAction(Request $request)
    {
        $questionTemplate = new QuestionTemplate();

        $form = $this->createQuestionTemplateForm($questionTemplate);
        
        return $this->save($request, $form, $questionTemplate);
    }

    /**
     * Updates queston template
     */
    public function putEditAction(Request $request)
    {
        try {
            $questionTemplate = $this->validateEntityFromRequest($request->get('id', 0));
            
            $form = $this->createQuestionTemplateForm($questionTemplate, 'PUT');
            
            return $this->save($request, $form, $questionTemplate);

        } catch(\Exception $e) {
            throw $e;
        }
    }

    /**
     * Deletes question template
     */
    public function doDeleteAction(Request $request)
    {
        try {
            $questionTemplate = $this->validateEntityFromRequest($request->get('id', 0));

            $this->getQuestionTemplateRepo()->remove($questionTemplate);

            // not sure with the return value
            return array('success' => true);
        } catch(\Exception $e) {
            throw $e;
        }
    }

    /**
     * (non-PHPdoc)
     * @see \YPKY\ApiBundle\Controller\ApiController::validateEntityFromRequest()
     *
     * @return \YPKY\ProductBundle\Entity\QuestionTemplate
     */
    protected function validateEntityFromRequest($id, $entityShortName = null)
    {
        return parent::validateEntityFromRequest($id, 'ProductBundle:QuestionTemplate');
    }

    /**
     * Do saving
     */
    private function save($request, $form, $questionTemplate)
    {
        $form->submit($request->request->all());

        if ($form->isValid()) {
            $this->getQuestionTemplateRepo()->save($questionTemplate);
            
            return $this->get('helper.entity_serializer')->toArray($questionTemplate);
        } else {
            return $form;
        }
    }

    /**
     * Creates question template form
     */
    private function createQuestionTemplateForm($questionTemplate, $method = 'POST')
    {
        return $this->createForm(new QuestionTemplateType(), $questionTemplate, array(
            'method' => $method,
            'csrf_protection' => false
        ));
    }

    /**
     * Saves question template
     */
    private function getQuestionTemplateRepo()
    {
        return $this->getDoctrine()
                    ->getManager()
                    ->getRepository('ProductBundle:QuestionTemplate');
    }
}