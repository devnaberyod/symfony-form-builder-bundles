<?php
namespace YPKY\ApiBundle\Controller;

use YPKY\ApiBundle\Controller\AuthenticatedApiController;
use YPKY\ProductBundle\Repository\FormElementRepository;
use YPKY\ProductBundle\Form\FormElementType;
use YPKY\ProductBundle\Entity\FormElement;

use Symfony\Component\HttpFoundation\Request;
use YPKY\ApiBundle\Form\FormElementApiFormType;
use YPKY\HelperBundle\Classes\QueryOption;
use Doctrine\ORM\Query;


/**
 * Handles form elements request
 */
class FormElementApiController extends AuthenticatedApiController
{
    /**
     * Returns list of form elements
     */
    public function indexAction(Request $request)
    {
        $filters = array();

        if ($request->get('form_section_id')) {
            $formSectionEntity = $this->validateEntityFromRequest($request->get('form_section_id'), 'ProductBundle:FormSection');

            $filters['formSection'] = $formSectionEntity->getId();
        }

        if ($request->get('form_id')) {
            
            $formEntity = $this->validateEntityFromRequest($request->get('form_id'), 'ProductBundle:Form');

            $filters['form'] = $formEntity->getId();
        }

        $queryOption = new QueryOption();
        $sortAsc = 0 != $request->get('sort_asc', 1); // sort_asc is default enabled unless set to 0

        // Add SortBy formSection.position ASC
        $queryOption->addOrderBy('fs.position', $sortAsc);

        $queryOption->addOrderBy($request->get('sort'), $sortAsc);
        

        $formElements = $this->get('product.form_element_service')->getFormElements($filters, Query::HYDRATE_ARRAY, $queryOption);

        $view = $this->view(array('data' => $formElements));
        $view->setFormat('json');

        return $this->handleView($view);
    }

    /**
     * Returns form element of given id
     */
    public function getAction(Request $request)
    {
        $formElement = $this->validateEntityFromRequest($request->get('id'));

        return $this->get('helper.entity_serializer')->toArray($formElement);

    }

    /**
     * Adds form element
     */
    public function postNewAction(Request $request)
    {
        $data = $request->request->all();
        $formElement = new FormElement();

        // check if there is a formQuestion submitted
        $withFormQuestion = isset($data['formQuestion']) && !empty($data['formQuestion']);

        $formParams = $withFormQuestion ? array() : array('excluded_fields' => array('formQuestion'));
        $form = $this->createFormElementForm($formElement, 'POST', $formParams);
        $form->submit(array_intersect_key($data, $form->all()));

        if ($form->isValid()) {
            $formElement->setIsHiddenToMember(false);
            $formElement->setIsLocked(false);
            $em = $this->getDoctrine()->getManager();
            $em->getRepository('ProductBundle:FormElement')->save($formElement);

            if($withFormQuestion) {
                $formQuestion = $this->saveFormQuestion($form);
                $formElement->setFormQuestion($formQuestion);
            }
            
            return $this->get('helper.entity_serializer')->toArray($formElement);

        } else {
            return $form;
        }
    }

    /**
     * Updates form element
     */
    public function putEditAction(Request $request)
    {
        try {
            $formElementService = $this->get('product.form_element_service');

            $formElement = $this->validateEntityFromRequest($request->get('id', 0));

            $form = $this->createFormElementForm($formElement, 'PUT', array('excluded_fields' => array('formQuestion')));

            $formData = $request->request->all();

            if (isset($formData['id'])) {
                unset($formData['id']);
            }

            $form->submit($formData);

            if ($form->isValid()) {
                $em = $this->getDoctrine()->getManager();

                $em->getRepository('ProductBundle:FormElement')->save($formElement);

                return $this->get('helper.entity_serializer')->toArray($formElement);
            } else {
                return $form;
            }
        } catch(\Exception $e) {
            throw $e;
        }
    }

    /**
     * Removes form element
     */
    public function doDeleteAction(Request $request)
    {
        try {
            $formElement = $this->validateEntityFromRequest($request->get('id', 0));

            $formQuestion = $this->getDoctrine()->getManager()->getRepository('ProductBundle:FormQuestion')->findOneByFormElement($formElement);

            if($formQuestion) {
                $this->getDoctrine()->getManager()->getRepository('ProductBundle:FormQuestion')->remove($formQuestion);
            }

            $this->getDoctrine()->getManager()
                ->getRepository('ProductBundle:FormElement')
                ->remove($formElement);

            return array('success' => true);
        } catch(\Exception $e) {
            throw $e;
        }
    }
    
    /**
     * Move formElement
     */
    public function moveAction(Request $request)
    {
        try {
            $formElementService = $this->get('product.form_element_service');

            $formElement = $this->validateEntityFromRequest($request->get('id', 0));
            
            $form = $this->createFormElementForm($formElement, 'PUT', array('excluded_fields' => array('formQuestion')));

            $formData = $request->request->all();

            if (isset($formData['id'])) {
                unset($formData['id']);
            }

            $form->submit($formData);

            if ($form->isValid()) {
                $em = $this->getDoctrine()->getManager();
    
                $formElementsNewPositions = $em->getRepository('ProductBundle:FormElement')->updatePosition($formElement);

                return $formElementsNewPositions;
            } else {
                return $form;
            }
        } catch(\Exception $e) {
            throw $e;
        }
    }

    /**
     * (non-PHPdoc)
     * @see \YPKY\ApiBundle\Controller\ApiController::validateEntityFromRequest()
     *
     * @return \YPKY\ProductBundle\Entity\FormElement
     */
    protected function validateEntityFromRequest($id, $entityShortName = 'ProductBundle:FormElement')
    {
        return parent::validateEntityFromRequest($id, $entityShortName);
    }

    /**
     * Creates form element form
     */
    private function createFormElementForm($formElement, $method = 'POST', $options=array())
    {
        $options = array_merge(array('method' => $method), $options);
        $form = $this->createForm(new FormElementApiFormType(), $formElement, $options);

        return $form;
    }

    /**
     * Save formQuestion linked to formElement
     */
    private function saveFormQuestion($form)
    {
        // there is a valid formQuestion
        // formQuestion is not a native property of formElement
        $formQuestion = $form->get('formQuestion')->getData();
        $formQuestion->setIsGlobal(true);
        $formQuestion->setFormElement($form->getData());
        $this->getDoctrine()->getRepository('ProductBundle:FormQuestion')->save($formQuestion);

        return $formQuestion;
    }
}