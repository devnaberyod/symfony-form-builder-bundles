<?php
namespace YPKY\ApiBundle\Controller;

use YPKY\ApiBundle\Controller\AuthenticatedApiController;
use Symfony\Component\HttpFoundation\Request;
use YPKY\ProductBundle\Form\FormType;
use YPKY\ProductBundle\Entity\Form;
use YPKY\ProductBundle\Repository\FormRepository;
use YPKY\ProductBundle\Entity\FormSection;
use YPKY\ApiBundle\Form\FormSectionApiFormType;
use FOS\RestBundle\View\View;
use YPKY\ProductBundle\Repository\FormSectionRepository;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;

/**
 *
 * @author Allejo Chris G. Velarde
 *
 */
class FormApiController extends AuthenticatedApiController
{
    /**
     * Returns list of forms
     */
    public function listAction(Request $request)
    {
        $filters = array();

        $data = $this->getDoctrine()
            ->getRepository('ProductBundle:Form')
            ->findWithFilters($filters);

        return array(
            'data' => $data
        );
    }

    /**
     *
     * @param Request $request
     *
     */
    public function postNewAction(Request $request)
    {
        $em = $this->getDoctrine()->getManager();
        $formEntity = new Form();

        $form = $this->createForm(new FormType(), $formEntity ,array('csrf_protection' => false));

        $postParameters = $request->request->all();  

        $form->submit($postParameters);

        if ($form->isValid()) {

            $formEntity->setDateCreated(new \DateTime('now'));
            $formEntity->setDescription($postParameters['description']);

            $this->getDoctrine()->getRepository('ProductBundle:Form')->save($formEntity);

            $view = View::create();
            $this->get('fos_rest.view_handler');

            $view->setData($formEntity);
            
            return $view;
        }
        else {
            $viewData = $form;
        }
        return $viewData;
    }

    /**
     *
     * @param Request $request
     */
    public function putEditAction(Request $request)
    {
        $formEntity = $this->validateEntityFromRequest($request->get('id'), 'ProductBundle:Form');
        $form = $this->createForm(new FormType(), $formEntity ,array('csrf_protection' => false));

        $formData = $request->request->all();
        $formData = array_intersect_key($formData, $form->all());

        $form->submit($formData);

        if ($form->isValid()) {
            $this->getDoctrine()->getRepository('ProductBundle:Form')->save($formEntity);

            return $this->get('helper.entity_serializer')->toArray($formEntity);
        }
        else {
            return $form;
        }
    }

    /**
     *
     * @param Request $request
     * @return \Symfony\Component\HttpFoundation\Response
     */
    public function getAction(Request $request)
    {
        $formEntity = $this->validateEntityFromRequest($request->get('id'), 'ProductBundle:Form');

        return $this->get('helper.entity_serializer')->toArray($formEntity);
    }

    public function indexAction()
    {

    }

    // --- Form Sections API /api/forms/{form_id}/form-sections

    public function postNewFormSectionAction(Request $request)
    {
        $formSection = new FormSection();
        $formSectionForm = $this->createForm(new FormSectionApiFormType(), $formSection);

        $formEntity = $this->validateEntityFromRequest($request->get('form_id'), 'ProductBundle:Form');

        $formSectionForm->submit($request->request->all());
        if ($formSectionForm->isValid()) {

            $formSection->setForm($formEntity);

            $this->getDoctrine()->getRepository('ProductBundle:FormSection')->save($formSection);

            $viewData = $formSection;
        }
        else {
            $viewData = $formSectionForm;
        }

        return $viewData;
    }

    
    // --- Form Sections API /api/forms/{form_id}/form-sections/{id}
    
    public function putEditFormSectionAction(Request $request)
    {
        $entityAlias = 'ProductBundle:FormSection';

        $formEntity = $this->validateEntityFromRequest($request->get('form_id'), 'ProductBundle:Form');
        $formSectionEntity = $this->validateEntityFromRequest($request->get('id'), $entityAlias);
        $formSectionForm = $this->createForm(new FormSectionApiFormType(), $formSectionEntity, array('csrf_protection' => false));

        $formSectionData = $request->request->all();
        $formSectionData = array_intersect_key($formSectionData, $formSectionForm->all());

        $formSectionForm->submit($request->request->all());
        
        if ($formSectionForm->isValid()) {
            $this->getDoctrine()->getRepository($entityAlias)->save($formSectionEntity);
    
            $viewData = $formSectionEntity;
        }
        else {
            $viewData = $formSectionForm;
        }
    
        return $viewData;
    }

    // --- Delete Form Sections API /api/forms/{form_id}/form-sections/{id}

    public function doDeleteFormSectionAction(Request $request)
    {
        try {

            $formSection = $this->getDoctrine()->getManager()->getRepository('ProductBundle:FormSection')->find($request->get('id', 0));
    
            if($formSection) {
                $this->get('product.form_section_service')->deleteByFormSection($formSection);
            }
        
            return array('success' => true);
        } catch(\Exception $e) {
            throw new BadRequestHttpException($e->getMessage());
        }
    }
    
    // --- Reorder Form Sections API /api/forms/{form_id}/form-sections/reorder
    
    public function putReorderFormSectionsAction(Request $request)
    {
        $em = $this->getDoctrine()->getManager();
        $formSectionEntityRepo = $this->getDoctrine()->getRepository('ProductBundle:FormSection');

        $formSectionsData = $request->request->all();
        
        // TODO: Optimize Query
        foreach($formSectionsData as $each) {
            if($eachEntity = $formSectionEntityRepo->find($each['id'])) {
                
                $eachEntity->setPosition($each['position']);
                $em->persist($eachEntity);
            }
        }

        $em->flush();

        return $formSectionsData;
    }
    
    
    /**
     * List Form Sections of a Form
     *
     * @param Request $request
     */
    public function listFormSectionAction(Request $request)
    {
        $formEntity = $this->validateEntityFromRequest($request->get('form_id'), 'ProductBundle:Form');

        $filters = array(
        	'form' => $formEntity->getId()
        );

        $data = $this->getDoctrine()->getRepository('ProductBundle:FormSection')
            ->findWithFilters($filters);

        return array(
        	'data' => $data
        );
    }


}