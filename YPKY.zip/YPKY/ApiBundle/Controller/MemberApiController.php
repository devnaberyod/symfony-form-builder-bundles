<?php
namespace YPKY\ApiBundle\Controller;

use FOS\RestBundle\Controller\FOSRestController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\EventDispatcher\GenericEvent;

use \YPKY\MemberBundle\Form\MemberRegistrationFormType;
use \YPKY\ApiBundle\Classes\ApiConstant;
use \YPKY\UserBundle\Services\UserTokenService;
use \YPKY\UserBundle\Event\UserAccessTokenEvent;
use \YPKY\MemberBundle\Entity\Member;

class MemberApiController extends FOSRestController
{
    public function registerAction(Request $request)
    {
        $form = $this->createRegisterForm();
        $form->handleRequest($request);

        if ($form->isValid()) {
            //save member registration data
            $member = $this->get('member.registration')->registerMember($form->getData());

            // Create Token
            $token = $this->createMemberUserToken($member);

            // Dispatch Create User Events
            $this->dispatchCreateUserEvents($token);

            // Dispatch event for intercom user register.
            $this->get('event_dispatcher')->dispatch('intercom.user.register', new GenericEvent($member->getUser()));

            $response = array('status' => 'success', 'message' => 'Confirm email to activate account');

        } else {
            $response = $this->getInvalidFormResponse($form);
        }

        return $response;
    }

    public function registerWithNameAction(Request $request)
    {
        $form = $this->createRegisterForm();
        $form->handleRequest($request);

        if ($form->isValid()) {
            //save member registration data
            $member = $this->get('member.registration')->registerMember($form->getData());

            // Create Token
            $token = $this->createMemberUserToken($member);

            // Dispatch Create User Events
            $this->dispatchCreateUserEvents($token, false);

            // Dispatch event for intercom user register.
            $this->get('event_dispatcher')->dispatch('intercom.user.register', new GenericEvent($member->getUser()));

            // Get Wordpress User data
            $wpUserData = $this->get('helper.wordpress_platform')->getUserDataByEmail($member->getUser()->getEmail());

            // Dispatch event to add member forms permission.
            $event = new GenericEvent($member, array('wp_user_data' => $wpUserData));
            $this->get('event_dispatcher')->dispatch('member.add_form_permission', $event);

            // Save Member Name data as MemberFormAsnwer 
            $name = array('last_name' => $wpUserData['last_name'], 'first_name' => $wpUserData['first_name']);
            $this->get('member.form_service')->saveMemberName($member, $name);

            // Set Member and Organization Forms permission
            $this->get('member.internal_form_service')->addFormOrgAndMemberPermission($member);

            $authenticationUrl = $this->generateUrl('api_member_authentication', array('access_token' => $token->getToken()), true);
            $response = array('status' => 'success', 'message' => 'Succesfully registered member', 'authentication_url' => $authenticationUrl);
    
        } else {
            $response = $this->getInvalidFormResponse($form);
        }

        return $response;
    }

    public function signUpAction(Request $request)
    {
        $data = $request->request->all();
        // validate post parameters throw exception here if ever

        $member = $this->get('member.registration')->registerMember($data);

        $token = $this->get('helper.user.tokenizer')->generateUserToken($member->getUser(), UserTokenService::getTokenExpiration());

        $em = $this->getDoctrine()->getEntityManager();
        $em->persist($token);
        $em->flush();

        $link = $this->generateUrl('member_email_confirmation', array('access_token' => $token->getToken()), true);    

        return array('link' => $link);
    }

    public function authenticateMemberAction(Request $request)
    {
        $requestToken = $request->get('access_token');
        return $this->forward('MemberBundle:MemberAccount:authenticateMember', array('token' => $requestToken));
    }
    

    ///// Private functions /////

    private function createRegisterForm($withName = false)
    {
        $formType = new MemberRegistrationFormType($withName);
        $userEntity = new \YPKY\UserBundle\Entity\User();

        $form = $this->createForm($formType, $userEntity, array('csrf_protection' => false));

        return $form;
    }

    private function getInvalidFormResponse($form)
    {
        $message = $form->getErrors();

        if(empty($message)) {
            $message = array('Invalid form. Malformed data.');
        }
    
        return array('status' => 'error', 'messages' => $message);
    }

    /** 
     * @param Member $member
     * @return unknown
     */
    private function createMemberUserToken(Member $member)
    {
        $tokenExpiration = UserTokenService::getTokenExpiration();
        $token = $this->get('helper.user.tokenizer')->generateUserToken($member->getUser(), $tokenExpiration);
        
        return $token;
    }
    
    private function dispatchCreateUserEvents($token, $withNotification = true)
    {
        $event = new UserAccessTokenEvent();
        $event->setToken($token);

        $this->get('event_dispatcher')->dispatch('user.access.token.new', $event);
        
        if($withNotification) {
            $this->get('event_dispatcher')->dispatch('notification.user.new', $event);
        }
    }
    
}