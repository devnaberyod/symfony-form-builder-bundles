<?php 

namespace YPKY\ApiBundle\Classes;

class ApiConstant
{
    const HAS_NAME = 1;
}











