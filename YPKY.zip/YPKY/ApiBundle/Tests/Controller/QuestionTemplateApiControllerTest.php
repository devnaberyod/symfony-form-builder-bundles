<?php
namespace YPKY\ApiBundle\Tests\Controller;

use YPKY\HelperBundle\Test\TokenAuthenticatedControllerWebTestCase;


class QuestionTemplateApiControllerTest extends TokenAuthenticatedControllerWebTestCase
{
    public function testIndexWithSuccessfulAuth()
    {
        $this->loadFixtures(array(
            'YPKY\HelperBundle\DataFixtures\UserAccessTokenData',
            'YPKY\ProductBundle\DataFixtures\CompleteWidgetsQuestionTemplateData'
        ));

        $json = $this->fetchJsonContent($this->getUrl('api_questionTemplate_index'));

        $this->assertArrayHasKey('data', $json);
        $this->assertNotEmpty($json['data']);
    }

    public function testGetActionWithInvalidId()
    {
        $this->loadFixtures(array(
            'YPKY\HelperBundle\DataFixtures\UserAccessTokenData'
        ));
        $json = $this->sendGetRequestWithJsonResponse($this->getUrl('api_questionTemplate_get', array('id' => 1)), array(), 404);

        $this->assertArrayHasKey('code', $json);
        $this->assertEquals('404', $json['code']);

    }

    public function testPostNewAction()
    {
        $this->loadFixtures(array(
            'YPKY\HelperBundle\DataFixtures\UserAccessTokenData'
        ));

        $questionTemplateParams = array(
            'name'           => 'Test Form',
            'example'        => 'Example',
            'helpText'       => 'Helptext',
            'notes'          => 'Notes',
            'question'       => 'Question',
            'status'         => 1
        );

        $json = $this->postWithJsonResponse($this->getUrl('api_questionTemplate_postNew'), array('parameters' => $questionTemplateParams), 200);

        // assert keys
        $this->assertArrayHasKey('id', $json);
        $this->assertArrayHasKey('name', $json);
        $this->assertArrayHasKey('help_text', $json);
        $this->assertArrayHasKey('notes', $json);
        $this->assertArrayHasKey('example', $json);
        $this->assertArrayHasKey('question', $json);
        $this->assertArrayHasKey('status', $json);
        $this->assertArrayHasKey('widget_metadata', $json);

        // assert values
        $this->assertEquals(1, $json['id']);
        $this->assertEquals($questionTemplateParams['name'], $json['name']);
        $this->assertEquals($questionTemplateParams['example'], $json['example']);
        $this->assertEquals($questionTemplateParams['helpText'], $json['help_text']);
        $this->assertEquals($questionTemplateParams['notes'], $json['notes']);
        $this->assertEquals($questionTemplateParams['question'], $json['question']);
        $this->assertEquals($questionTemplateParams['status'], $json['status']);

        $this->assertNotEmpty($json['widget_metadata']);
    }

    public function testPostNewActionWithBlankRequiredFields()
    {
        $this->loadFixtures(array(
            'YPKY\HelperBundle\DataFixtures\UserAccessTokenData',
            'YPKY\ProductBundle\DataFixtures\CompleteWidgetsQuestionTemplateData'
        ));

        $questionTemplateParams = array(
            'name'           => '',
            'example'        => 'Example',
            'helpText'       => 'Helptext',
            'notes'          => 'Notes',
            'question'       => 'Question',
            'status'         => 1
        );

        $json = $this->postWithJsonResponse($this->getUrl('api_questionTemplate_postNew'), array('parameters' => $questionTemplateParams), 400);

        // code data assertion
        $this->assertArrayHasKey('code', $json);
        $this->assertEquals('400', $json['code']);

        // errors array assertion
        $this->assertArrayHasKey('errors', $json);
        $this->assertNotEmpty($json['errors']);
    }

    public function testGetAction()
    {
        $this->loadFixtures(array(
            'YPKY\HelperBundle\DataFixtures\UserAccessTokenData',
            'YPKY\ProductBundle\DataFixtures\CompleteWidgetsQuestionTemplateData'
        ));

        $json = $this->sendGetRequestWithJsonResponse($this->getUrl('api_questionTemplate_get', array('id' => 1)));

        $this->assertArrayHasKey('id', $json);
    }

    public function testPutEditAction()
    {
        $this->loadFixtures(array(
            'YPKY\HelperBundle\DataFixtures\UserAccessTokenData',
            'YPKY\ProductBundle\DataFixtures\CompleteWidgetsQuestionTemplateData'
        ));

        $questionTemplateParams = array(
            'name'           => 'Name Edited',
            'example'        => 'Example Edited',
            'helpText'       => 'Helptext Edited',
            'notes'          => 'Notes',
            'question'       => 'Question',
            'status'         => 1
        );

        $json = $this->putWithJsonResponse($this->getUrl('api_questionTemplate_putEdit', array('id' => 1)), array('parameters' => $questionTemplateParams));

        // assert keys
        $this->assertArrayHasKey('id', $json);
        $this->assertArrayHasKey('name', $json);
        $this->assertArrayHasKey('help_text', $json);
        $this->assertArrayHasKey('notes', $json);
        $this->assertArrayHasKey('example', $json);
        $this->assertArrayHasKey('question', $json);
        $this->assertArrayHasKey('status', $json);
        $this->assertArrayHasKey('widget_metadata', $json);

        // assert values
        $this->assertEquals(1, $json['id']);
        $this->assertEquals($questionTemplateParams['name'], $json['name']);
        $this->assertEquals($questionTemplateParams['example'], $json['example']);
        $this->assertEquals($questionTemplateParams['helpText'], $json['help_text']);
        $this->assertEquals($questionTemplateParams['notes'], $json['notes']);
        $this->assertEquals($questionTemplateParams['question'], $json['question']);
        $this->assertEquals($questionTemplateParams['status'], $json['status']);

        $this->assertNotEmpty($json['widget_metadata']);
    }

    public function testPutEditActionWithBlankRequiredFields()
    {
        $this->loadFixtures(array(
            'YPKY\HelperBundle\DataFixtures\UserAccessTokenData',
            'YPKY\ProductBundle\DataFixtures\CompleteWidgetsQuestionTemplateData'
        ));

        $questionTemplateParams = array(
            'name'           => '',
            'example'        => 'Example',
            'helpText'       => 'Helptext',
            'notes'          => 'Notes',
            'question'       => 'Question',
            'status'         => 1
        );

        $json = $this->putWithJsonResponse($this->getUrl('api_questionTemplate_putEdit', array('id' => 1)), array('parameters' => $questionTemplateParams), 400);

        // code data assertion
        $this->assertArrayHasKey('code', $json);
        $this->assertEquals('400', $json['code']);

        // errors array assertion
        $this->assertArrayHasKey('errors', $json);
        $this->assertNotEmpty($json['errors']);
    }

    public function testPutEditActionWithInvalidId()
    {
        $this->loadFixtures(array(
            'YPKY\HelperBundle\DataFixtures\UserAccessTokenData',
        ));
        $json = $this->sendGetRequestWithJsonResponse($this->getUrl('api_questionTemplate_putEdit', array('id' => 1)), array(), 404);

        $this->assertArrayHasKey('code', $json);
        $this->assertEquals('404', $json['code']);
    }

    public function testDoDeleteAction()
    {
        $this->loadFixtures(array(
            'YPKY\HelperBundle\DataFixtures\UserAccessTokenData',
            'YPKY\ProductBundle\DataFixtures\CompleteWidgetsQuestionTemplateData'
        ));

        $response = $this->sendDeleteRequest($this->getUrl('api_questionTemplate_delete', array('id' => 1)));

        $this->assertEquals(200, $response->getStatusCode());

        // test if does not exit anymore
        $json = $this->sendGetRequestWithJsonResponse($this->getUrl('api_questionTemplate_get', array('id' => 1)), array(), 404);

        $this->assertArrayHasKey('code', $json);
        $this->assertEquals('404', $json['code']);
    }

    public function testDoDeleteActionWithInvalidId()
    {
        $this->loadFixtures(array(
            'YPKY\HelperBundle\DataFixtures\UserAccessTokenData'
        ));

        $response = $this->sendDeleteRequest($this->getUrl('api_questionTemplate_delete', array('id' => 1)));
        $json = json_decode($response->getContent(), true);
        
        $this->assertArrayHasKey('code', $json);
        $this->assertEquals('404', $json['code']);
    }

}