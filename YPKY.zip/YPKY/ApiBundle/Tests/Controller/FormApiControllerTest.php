<?php
namespace YPKY\ApiBundle\Tests\Controller;

use YPKY\HelperBundle\Test\TokenAuthenticatedControllerWebTestCase;
class FormApiControllerTest extends TokenAuthenticatedControllerWebTestCase
{
    public function testListAction()
    {
        $this->loadFixtures(array(
            'YPKY\HelperBundle\DataFixtures\UserAccessTokenData',
            'YPKY\ProductBundle\DataFixtures\FormQuestionData',
        ));

        $json = $this->fetchJsonContent($this->getUrl('api_form_list'));

        $this->assertArrayHasKey('data', $json);
        $this->assertNotEmpty($json['data']);
    }

    public function testPostNewAction()
    {
        $this->loadFixtures(array(
            'YPKY\HelperBundle\DataFixtures\UserAccessTokenData',
        ));

        $formParameters = array(
            'name' => 'Test Form',
            'description' => 'Description',
            'helpText' => 'Help Text',
            'price' => 100
        );

        $json = $this->postWithJsonResponse($this->getUrl('api_form_postNew'),array('parameters' => $formParameters), 200);

        $this->assertArrayHasKey('id', $json);
        $this->assertArrayHasKey('name', $json);
        $this->assertArrayHasKey('description', $json);
        $this->assertArrayHasKey('helpText', $json);
        $this->assertArrayHasKey('formSections', $json);

        $this->assertEquals(1, $json['id']);
        $this->assertEquals('Test Form', $json['name']);
        $this->assertEquals('Description', $json['description']);
        $this->assertEquals('Help Text', $json['helpText']);
    }

    public function testPostNewActionWithBlankRequiredFields()
    {
        $this->loadFixtures(array(
            'YPKY\HelperBundle\DataFixtures\UserAccessTokenData',
        ));

        $formParameters = array(
            'name' => '',
            'description' => '',
            'helpText' => '',
            'price' => ''
        );

        $json = $this->postWithJsonResponse($this->getUrl('api_form_postNew'), array('parameters' => $formParameters), 400);

        // code data assertion
        $this->assertArrayHasKey('code', $json);
        $this->assertEquals('400', $json['code']);

        // errors array assertion
        $this->assertArrayHasKey('errors', $json);
        $this->assertNotEmpty($json['errors']);
    }

    public function testGetAction()
    {
        $this->loadFixtures(array(
            'YPKY\HelperBundle\DataFixtures\UserAccessTokenData',
            'YPKY\ProductBundle\DataFixtures\FormData'
        ));

        $json = $this->sendGetRequestWithJsonResponse($this->getUrl('api_form_get', array('id' => 1)), array(), 200);

        $this->assertArrayHasKey('id', $json);
        $this->assertArrayHasKey('name', $json);
        $this->assertArrayHasKey('description', $json);
        $this->assertArrayHasKey('helpText', $json);

        $this->assertEquals(1, $json['id']);
        $this->assertEquals('Form 1', $json['name']);
        $this->assertEquals('Description Only', $json['description']);
        $this->assertEquals('Helptext', $json['helpText']);

    }

    public function testGetActionWithInvalidId()
    {
        $this->loadFixtures(array(
            'YPKY\HelperBundle\DataFixtures\UserAccessTokenData',
        ));
        $json = $this->sendGetRequestWithJsonResponse($this->getUrl('api_form_get', array('id' => 1)), array(), 404);

        $this->assertArrayHasKey('code', $json);
        $this->assertEquals('404', $json['code']);
    }

    public function testPutEditAction()
    {
        $this->loadFixtures(array(
            'YPKY\HelperBundle\DataFixtures\UserAccessTokenData',
            'YPKY\ProductBundle\DataFixtures\FormData'
        ));

        $formParameters = array(
            'name' => 'Name Edited',
            'description' => 'Description Edited',
            'helpText' => 'Help Text Edited',
            'id' => 1,
            'dateCreated' => '2014-10-01'
        );

        $json = $this->putWithJsonResponse($this->getUrl('api_form_putEdit', array('id' => 1)), array('parameters' => $formParameters), 200);

        $this->assertArrayHasKey('id', $json);
        $this->assertArrayHasKey('name', $json);
        $this->assertArrayHasKey('description', $json);
        $this->assertArrayHasKey('helpText', $json);

        $this->assertEquals(1, $json['id']);
        $this->assertEquals('Name Edited', $json['name']);
        $this->assertEquals('Description Edited', $json['description']);
        $this->assertEquals('Help Text Edited', $json['helpText']);
    }

    public function testPutEditActionWithBlankRequiredFields()
    {
        $this->loadFixtures(array(
            'YPKY\HelperBundle\DataFixtures\UserAccessTokenData',
            'YPKY\ProductBundle\DataFixtures\FormData'
        ));

        $formParameters = array(
            'name' => '',
            'description' => '',
            'helpText' => '',
        );

        $json = $this->putWithJsonResponse($this->getUrl('api_form_putEdit', array('id' => 1)), array('parameters' => $formParameters), 400);

        // code data assertion
        $this->assertArrayHasKey('code', $json);
        $this->assertEquals('400', $json['code']);

        // errors array assertion
        $this->assertArrayHasKey('errors', $json);
        $this->assertNotEmpty($json['errors']);
    }

    // --- tests for /api/forms/{form_id}/form-sections
    public function testPostNewFormSectionAction()
    {
        $this->loadFixtures(array(
            'YPKY\HelperBundle\DataFixtures\UserAccessTokenData',
            'YPKY\ProductBundle\DataFixtures\FormData'
        ));

        $formParameters = array(
        	'name' => 'Form Section',
            'description' => 'Form Section description',
            'position' => '1'
        );

        $json = $this->postWithJsonResponse($this->getUrl('api_form_postNewFormSection', array('form_id' => 1)), array('parameters' => $formParameters), 200);

        $this->assertArrayHasKey('name', $json);
        $this->assertArrayHasKey('description', $json);
        $this->assertArrayHasKey('position', $json);
    }

    public function testListFormSectionAction()
    {
        $this->loadFixtures(array(
            'YPKY\HelperBundle\DataFixtures\UserAccessTokenData',
            'YPKY\ProductBundle\DataFixtures\Form1FormSectionData'
        ));

        $json = $this->sendGetRequestWithJsonResponse($this->getUrl('api_form_listFormSection',  array('form_id' => 1)));

        $this->assertArrayHasKey('data', $json);
        $this->assertNotEmpty($json['data']);

        foreach ($json['data'] as $formSectionData) {
            $this->assertArrayHasKey('id', $formSectionData);
            $this->assertArrayHasKey('name', $formSectionData);
            $this->assertArrayHasKey('description', $formSectionData);
            $this->assertArrayHasKey('position', $formSectionData);
            $this->assertArrayHasKey('form', $formSectionData);

            // check that form should be Form 1
            $this->assertNotEmpty($formSectionData['form']);
            $this->assertArrayHasKey('id', $formSectionData['form']);
            $this->assertEquals(1, $formSectionData['form']['id'], 'All form sections should be from Form 1');
        }
    }


}