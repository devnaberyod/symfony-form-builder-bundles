<?php
namespace YPKY\ApiBundle\Tests\Controller;

use YPKY\HelperBundle\Test\TokenAuthenticatedControllerWebTestCase;

class FormElementApiControllerTest extends TokenAuthenticatedControllerWebTestCase
{
    public function testIndexWithSuccessfulAuth()
    {
        $this->loadFixtures(array(
            'YPKY\HelperBundle\DataFixtures\UserAccessTokenData',
            'YPKY\ProductBundle\DataFixtures\FormSection1FormElementData'
        ));

        $json = $this->fetchJsonContent($this->getUrl('api_formElements_index', array('form_section_id' => 1)));

        $this->assertArrayHasKey('data', $json);
        $this->assertNotEmpty($json['data']);

        foreach ($json['data'] as $formElementData) {
            $this->doCommonTestForExpectedFormElementPropertyKeys($formElementData);
        }
    }

    public function testIndexWithFormFilter()
    {
        $this->loadFixtures(array(
            'YPKY\HelperBundle\DataFixtures\UserAccessTokenData',
            'YPKY\ProductBundle\DataFixtures\FormSection1FormElementData',
            // add another form here
            'YPKY\ProductBundle\DataFixtures\OrganizationProfile\OrganizationProfileFormData'
        ));
        $json = $this->sendGetRequestWithJsonResponse($this->getUrl('api_formElements_index', array('form_id' => 1)));

        $this->assertArrayHasKey('data', $json);
        $this->assertNotEmpty($json['data']);

        foreach ($json['data'] as $formElementData) {
            $this->doCommonTestForExpectedFormElementPropertyKeys($formElementData);

            // assert that form id is 1
            $this->assertEquals(1, $formElementData['form']['id']);
        }
    }

    public function testGetAction()
    {
        $this->loadFixtures(array(
            'YPKY\HelperBundle\DataFixtures\UserAccessTokenData',
            'YPKY\ProductBundle\DataFixtures\FormSection1FormElementData'
        ));

        $json = $this->sendGetRequestWithJsonResponse($this->getUrl('api_formElements_get', array('id' => 1)));

        $this->assertArrayHasKey('id', $json);
    }

    public function testGetActionWithInvalidId()
    {
        $this->loadFixtures(array(
            'YPKY\HelperBundle\DataFixtures\UserAccessTokenData',
        ));
        $json = $this->sendGetRequestWithJsonResponse($this->getUrl('api_formElements_get', array('id' => 1)), array(), 404);

        $this->assertArrayHasKey('code', $json);
        $this->assertEquals('404', $json['code']);
    }



    public function testPostNewAction()
    {
        $this->loadFixtures(array(
            'YPKY\HelperBundle\DataFixtures\UserAccessTokenData',
            'YPKY\ProductBundle\DataFixtures\Form1FormSectionData',
        ));

        $formElementParams = array(
            'elementType'       => 1,
            'text'              => 'Example Text',
            'position'          => 1,
            'renderConfig'      => 'Render Configuration',
            'widgetMetadata'    => 'Widget Metadata',
            'form'              => 1,
            'formSection'       => 1
        );

        $json = $this->postWithJsonResponse($this->getUrl('api_formElements_postNew'), array('parameters' => $formElementParams), 200);
        $this->doCommonTestForSuccessfulJsonResponse($formElementParams, $json);

        $this->assertEquals(1, $json['id']);
    }

    public function testPostNewActionWithFormQuestion()
    {
        $this->loadFixtures(array(
            'YPKY\HelperBundle\DataFixtures\UserAccessTokenData',
            'YPKY\ProductBundle\DataFixtures\CompleteWidgetsQuestionTemplateData',
            'YPKY\ProductBundle\DataFixtures\Form1FormSectionData'
        ));

        $formElementParams = array(
            'elementType'       => 1,
            'text'              => 'Example Text',
            'position'          => 1,
            'renderConfig'      => 'Render Configuration',
            'widgetMetadata'    => 'Widget Metadata',
            'form'              => 1,
            'formSection'       => 1
        );

        // form question data
        $formElementParams['formQuestion'] = array(
            'question' => 'What is CQ Example?',
            'name' => 'cq',
            'example' => 'Example here',
            'notes' => 'Notes here',
            'helpText' => 'Help text',
            'questionTemplate' => 1,
            'form' => 1,
        );

        $json = $this->postWithJsonResponse($this->getUrl('api_formElements_postNew'), array('parameters' => $formElementParams), 200);

        $this->doCommonTestForSuccessfulJsonResponse($formElementParams, $json);

        $this->assertEquals(1, $json['id']);
        $this->assertArrayHasKey('formQuestion', $json);
    }

    public function testPostNewActionWithExistingParentFormElement()
    {
        $this->loadFixtures(array(
            'YPKY\HelperBundle\DataFixtures\UserAccessTokenData',
            'YPKY\ProductBundle\DataFixtures\FormSection1FormElementData'
        ));

        $formElementParams = array(
            'elementType'       => 1,
            'text'              => 'Example Text',
            'position'          => 1,
            'renderConfig'      => 'Render Configuration',
            'widgetMetadata'    => 'Widget Metadata',
            'form'              => 1,
            'formSection'       => 1,
            'parentFormElement' => 1
        );

        $json = $this->postWithJsonResponse($this->getUrl('api_formElements_postNew'), array('parameters' => $formElementParams), 200);
        $this->doCommonTestForSuccessfulJsonResponse($formElementParams, $json);

        $this->assertEquals(3, $json['id']);  // assumed as the incremented id of newly added element
        $this->assertArrayHasKey('parent_form_element', $json);
        $this->assertEquals($formElementParams['parentFormElement'], $json['parent_form_element']['id']);
    }

    public function testPostNewActionWithUnexistingParentFormElement()
    {
        $this->loadFixtures(array(
            'YPKY\HelperBundle\DataFixtures\UserAccessTokenData',
            'YPKY\ProductBundle\DataFixtures\FormSection1FormElementData'
        ));

        $formElementParams = array(
            'elementType'       => 1,
            'text'              => 'Example Text',
            'position'          => 1,
            'renderConfig'      => 'Render Configuration',
            'widgetMetadata'    => 'Widget Metadata',
            'form'              => 1,
            'formSection'       => 1,
            'parentFormElement' => 5
        );

        $json = $this->postWithJsonResponse($this->getUrl('api_formElements_postNew'), array('parameters' => $formElementParams), 200);
        $this->doCommonTestForSuccessfulJsonResponse($formElementParams, $json);

        $this->assertEquals(3, $json['id']);  // assumed as the incremented id of newly added element
        $this->assertArrayNotHasKey('parent_form_element', $json);
    }

    public function testPostNewActionWithBlankRequiredFields()
    {
        $this->loadFixtures(array(
            'YPKY\HelperBundle\DataFixtures\UserAccessTokenData'
        ));

        $formElementParams = array(
            'elementType'       => 1,
            'text'              => '',
            'position'          => 1,
            'page'              => 0,
            'renderConfig'      => '',
            'widgetMetadata'    => '',
            'form'              => 1,
            'parentFormElement' => 1
        );

        $json = $this->postWithJsonResponse($this->getUrl('api_formElements_postNew'), array('parameters' => $formElementParams), 400);
        // code data assertion
        $this->assertArrayHasKey('code', $json);
        $this->assertEquals('400', $json['code']);

        // errors array assertion
        $this->assertArrayHasKey('errors', $json);
        $this->assertNotEmpty($json['errors']);
    }

    public function testPutEditAction()
    {
        $this->loadFixtures(array(
            'YPKY\HelperBundle\DataFixtures\UserAccessTokenData',
            'YPKY\ProductBundle\DataFixtures\FormSection1FormElementData'
        ));

        $formElementParams = array(
            'elementType'       => 1,
            'text'              => 'Example Text Edited',
            'position'          => 1,
            'renderConfig'      => 'Render Configuration Edited',
            'widgetMetadata'    => 'Widget Metadata Edited',
            'form'              => 1,
            'formSection'       => 1,
            'id' => 1
        );

        $json = $this->putWithJsonResponse($this->getUrl('api_formElements_putEdit', array('id' => 1)), array('parameters' => $formElementParams), 200);
        $this->doCommonTestForSuccessfulJsonResponse($formElementParams, $json);

        $this->assertEquals(1, $json['id']);
    }

    public function testPutEditActionWithBlankRequiredFields()
    {
        $this->loadFixtures(array(
            'YPKY\HelperBundle\DataFixtures\UserAccessTokenData',
            'YPKY\ProductBundle\DataFixtures\FormSection1FormElementData'
        ));

        $formElementParams = array(
            'elementType'       => 1,
            'text'              => '',
            'position'          => 1,
            'renderConfig'      => '',
            'widgetMetadata'    => 'Widget Metadata Edited',
            'form'              => 1,
            'formSection'       => 1
        );

        $json = $this->putWithJsonResponse($this->getUrl('api_formElements_putEdit', array('id' => 1)), array('parameters' => $formElementParams), 400);

        // code data assertion
        $this->assertArrayHasKey('code', $json);
        $this->assertEquals('400', $json['code']);

        // errors array assertion
        $this->assertArrayHasKey('errors', $json);
        $this->assertNotEmpty($json['errors']);
    }

    public function testPutEditActionWithInvalidId()
    {
        $this->loadFixtures(array(
            'YPKY\HelperBundle\DataFixtures\UserAccessTokenData',
            'YPKY\ProductBundle\DataFixtures\FormSection1FormElementData'
        ));

        $formElementParams = array(
            'elementType'       => 1,
            'text'              => '',
            'position'          => 1,
            'renderConfig'      => '',
            'widgetMetadata'    => 'Widget Metadata Edited',
            'form'              => 1,
            'formSection'       => 1
        );

        $json = $this->putWithJsonResponse($this->getUrl('api_formElements_putEdit', array('id' => 5)), array('parameters' => $formElementParams), 404);

        // code data assertion
        $this->assertArrayHasKey('code', $json);
        $this->assertEquals('404', $json['code']);
    }

    public function testDoDeleteAction()
    {
        $this->loadFixtures(array(
            'YPKY\HelperBundle\DataFixtures\UserAccessTokenData',
            'YPKY\ProductBundle\DataFixtures\FormSection1FormElementData'
        ));

        $response = $this->sendDeleteRequest($this->getUrl('api_formElements_delete', array('id' => 1)));

        $this->assertEquals(200, $response->getStatusCode());

        // assert not exist
        $json = $this->sendGetRequestWithJsonResponse($this->getUrl('api_formElements_get', array('id' => 1)), array(), 404);

        $this->assertArrayHasKey('code', $json);
        $this->assertEquals('404', $json['code']);
    }

    public function testDoDeleteActionWithInvalidId()
    {
        $this->loadFixtures(array(
            'YPKY\HelperBundle\DataFixtures\UserAccessTokenData'
        ));

        $response = $this->sendDeleteRequest($this->getUrl('api_formElements_delete', array('id' => 1)));
        $json = json_decode($response->getContent(), true);

        $this->assertArrayHasKey('code', $json);
        $this->assertEquals('404', $json['code']);
    }

    /**
     * Common test for expected keys of a formElement entity
     *
     * @param array $formElement
     */
    private function doCommonTestForExpectedFormElementPropertyKeys(array $formElement)
    {
        $this->assertArrayHasKey('id', $formElement);
        $this->assertArrayHasKey('elementType', $formElement);
        $this->assertArrayHasKey('text', $formElement);
        $this->assertArrayHasKey('position', $formElement);
        $this->assertArrayHasKey('renderConfig', $formElement);
        $this->assertArrayHasKey('widgetMetadata', $formElement);
        $this->assertArrayHasKey('form', $formElement);
        $this->assertArrayHasKey('formSection', $formElement);
    }

    private function doCommonTestForSuccessfulJsonResponse($formElementParams, $jsonResponse)
    {
        // assert keys
        $this->assertArrayHasKey('id', $jsonResponse);
        $this->assertArrayHasKey('elementType', $jsonResponse);
        $this->assertArrayHasKey('text', $jsonResponse);
        $this->assertArrayHasKey('position', $jsonResponse);
        $this->assertArrayHasKey('renderConfig', $jsonResponse);
        $this->assertArrayHasKey('widgetMetadata', $jsonResponse);

        $this->assertArrayHasKey('form', $jsonResponse);
        $this->assertNotEmpty($jsonResponse['form']);
        $this->assertEquals($formElementParams['form'], $jsonResponse['form']['id']);

        $this->assertArrayHasKey('formSection', $jsonResponse);
        $this->assertNotEmpty($jsonResponse['formSection']);
        $this->assertEquals($formElementParams['formSection'], $jsonResponse['formSection']['id']);


        // assert values
        $this->assertEquals($formElementParams['elementType'], $jsonResponse['elementType']);
        $this->assertEquals($formElementParams['text'], $jsonResponse['text']);
        $this->assertEquals($formElementParams['position'], $jsonResponse['position']);
        $this->assertEquals($formElementParams['renderConfig'], $jsonResponse['renderConfig']);
        $this->assertEquals($formElementParams['widgetMetadata'], $jsonResponse['widgetMetadata']);

    }

}