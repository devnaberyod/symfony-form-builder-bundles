<?php
namespace YPKY\ApiBundle\Tests\Controller;

use YPKY\HelperBundle\Test\TokenAuthenticatedControllerWebTestCase;

use YPKY\ProductBundle\Entity\FormElementTypes;

class FormQuestionApiControllerTest extends TokenAuthenticatedControllerWebTestCase
{
    public function testIndexAction()
    {
        $this->loadFixtures(array(
            'YPKY\HelperBundle\DataFixtures\UserAccessTokenData',
            'YPKY\ProductBundle\DataFixtures\FormQuestionData',
        ));

        $json = $this->fetchJsonContent($this->getUrl('api_formQuestions_index'));

        $this->assertArrayHasKey('data', $json);
        $this->assertNotEmpty($json['data']);
    }

    public function testIndexActionWithFilters()
    {
        $this->loadFixtures(array(
            'YPKY\HelperBundle\DataFixtures\UserAccessTokenData',
            'YPKY\ProductBundle\DataFixtures\FormQuestionData',
        ));

        $json = $this->fetchJsonContent($this->getUrl('api_form_formQuestions', array('form_id' => 1)));
        
        $this->assertArrayHasKey('data', $json);
        $this->assertNotEmpty($json['data']);
        
        foreach ($json['data'] as $question) {
            $this->assertArrayHasKey('form', $question);
            $this->assertEquals(1, $question['form']['id']);
        }
    }

    public function testGetAction()
    {
        $this->loadFixtures(array(
            'YPKY\HelperBundle\DataFixtures\UserAccessTokenData',
            'YPKY\ProductBundle\DataFixtures\FormQuestionData',
        ));

        $json = $this->sendGetRequestWithJsonResponse($this->getUrl('api_formQuestions_get', array('id' => 1)));

        $this->assertArrayHasKey('id', $json);
    }

    public function testPostNewAction()
    {
        $this->loadFixtures(array(
            'YPKY\HelperBundle\DataFixtures\UserAccessTokenData',
            'YPKY\ProductBundle\DataFixtures\FormQuestionData'
        ));

        $formQuestionsParams = array(
            'name'             => 'Name',
            'example'          => 'Example',
            'helpText'         => 'Helptext',
            'notes'            => 'Notes',
            'question'         => 'Question',
            'form'             => 1,
            'formElement'      => 1,
            'questionTemplate' => 1
        );

        $json = $this->postWithJsonResponse($this->getUrl('api_formQuestions_postNew'), array('parameters' => $formQuestionsParams));

        // assert keys
        $this->assertArrayHasKey('id', $json);
        $this->assertArrayHasKey('name', $json);
        $this->assertArrayHasKey('help_text', $json);
        $this->assertArrayHasKey('notes', $json);
        $this->assertArrayHasKey('example', $json);
        $this->assertArrayHasKey('question', $json);
        $this->assertArrayHasKey('form', $json);
        $this->assertArrayHasKey('form_element', $json);
        $this->assertArrayHasKey('question_template', $json);

        // assert values
        $this->assertEquals(2, $json['id']);  //table has one formQuestion already
        $this->assertEquals($formQuestionsParams['name'], $json['name']);
        $this->assertEquals($formQuestionsParams['example'], $json['example']);
        $this->assertEquals($formQuestionsParams['helpText'], $json['help_text']);
        $this->assertEquals($formQuestionsParams['notes'], $json['notes']);
        $this->assertEquals($formQuestionsParams['question'], $json['question']);
        $this->assertEquals($formQuestionsParams['questionTemplate'], $json['question_template']['id']);
        $this->assertEquals($formQuestionsParams['formElement'], $json['form_element']['id']);
        $this->assertEquals($formQuestionsParams['form'], $json['form']['id']);
    }

    public function testPutEditAction()
    {
        $this->loadFixtures(array(
            'YPKY\HelperBundle\DataFixtures\UserAccessTokenData',
            'YPKY\ProductBundle\DataFixtures\FormQuestionData'
        ));

        $formQuestionsParams = array(
            'name'             => 'Name Edited',
            'example'          => 'Example Edited',
            'helpText'         => 'Helptext Edited',
            'notes'            => 'Notes Edited',
            'question'         => 'Question Edited',
            'form'             => 1,
            'formElement'      => 2,
            'questionTemplate' => 1
        );

        $json = $this->putWithJsonResponse($this->getUrl('api_formQuestions_putEdit', array('id' => 1)), array('parameters' => $formQuestionsParams));

        // assert keys
        $this->assertArrayHasKey('name', $json);
        $this->assertArrayHasKey('help_text', $json);
        $this->assertArrayHasKey('notes', $json);
        $this->assertArrayHasKey('example', $json);
        $this->assertArrayHasKey('question', $json);
        $this->assertArrayHasKey('form', $json);
        $this->assertArrayHasKey('form_element', $json);
        $this->assertArrayHasKey('question_template', $json);

        // assert values
        $this->assertEquals(1, $json['id']);  //table has one formQuestion already
        $this->assertEquals($formQuestionsParams['name'], $json['name']);
        $this->assertEquals($formQuestionsParams['example'], $json['example']);
        $this->assertEquals($formQuestionsParams['helpText'], $json['help_text']);
        $this->assertEquals($formQuestionsParams['notes'], $json['notes']);
        $this->assertEquals($formQuestionsParams['question'], $json['question']);
        $this->assertEquals($formQuestionsParams['questionTemplate'], $json['question_template']['id']);
        $this->assertEquals($formQuestionsParams['formElement'], $json['form_element']['id']);
        $this->assertEquals($formQuestionsParams['form'], $json['form']['id']);
    }

    public function testDeleteAction()
    {
        $this->loadFixtures(array(
            'YPKY\HelperBundle\DataFixtures\UserAccessTokenData',
            'YPKY\ProductBundle\DataFixtures\FormQuestionData'
        ));

        $response = $this->sendDeleteRequest($this->getUrl('api_formQuestions_delete', array('id' => 1)));
        $this->assertEquals(200, $response->getStatusCode());

        // test if does not exit anymore
        $json = $this->sendGetRequestWithJsonResponse($this->getUrl('api_formQuestions_get', array('id' => 1)), array(), 404);

        $this->assertArrayHasKey('code', $json);
        $this->assertEquals('404', $json['code']);
    }

}