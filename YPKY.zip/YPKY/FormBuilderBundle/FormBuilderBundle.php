<?php

namespace YPKY\FormBuilderBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class FormBuilderBundle extends Bundle
{
}
