<?php

namespace YPKY\FormBuilderBundle\Services;

/**
 * @author  Farly Taboada
 */
interface FileUploaderInterface
{
    public function setUploadDirectory($uploadDirectory);
}