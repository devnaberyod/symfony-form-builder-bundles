<?php

namespace YPKY\AdminBundle\Controller;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;

use YPKY\MemberBundle\Entity\Organization;
use YPKY\MemberBundle\Form\OrganizationType;

use YPKY\ProductBundle\Entity\Form;
use YPKY\MemberBundle\Entity\OrganizationFormPermission;
/**
 * Organization controller.
 *
 */
class OrganizationController extends OrganizationManagerController
{
    /**
     * Lists all Organization entities.
     *
     */
    public function indexAction(Request $request)
    {
        $searchQuery = $request->get('search_query');
        $internalFormService = $this->get('member.internal_form_service');
        $searchResult = $this->getDoctrine()->getRepository('MemberBundle:Organization')->searchOrganizationByName($searchQuery);

        $paginator  = $this->get('knp_paginator');
        $pagination = $paginator->paginate(
            $searchResult,
            $request->get('page', 1),
            10 /*items limit*/
        );
        
        $data = array(
            'pagination'  => $pagination,
            'selectedTab' => self::MAIN_TAB,
            'selectedSubTab' => self::SUB_TAB_ORG,
            'searchQuery' => $searchQuery,
            'placeholder' => self::MEMBER_SEARCH_ORG_PLACEHOLDER,
            'action' => $this->generateUrl('admin_organization'),
            'memberForms' => $this->getMemberForms(),
            'deleteOrg' => self::DELETE_ORG
        );

        return $this->render('AdminBundle:Organization:index.html.twig', $data);
    }
    
    /**
     * Displays Organization.
     *
     */
    public function showAction($id)
    {
        $em = $this->getDoctrine()->getManager();
        $entity = $em->getRepository('MemberBundle:Organization')->find($id);

        if (!$entity) {
            throw $this->createNotFoundException('Unable to find Organization entity.');
        }

        //FIXME Temporary to get org owner member and memberForms
        $ownerMember = $em->getRepository('MemberBundle:Member')->findOneByOrganization($entity);
        $email = $ownerMember->getUser()->getEmail();
        
        $organizationActiveForms =  $em->getRepository('MemberBundle:OrganizationFormPermission')->getFormsByOrganization($entity);

        $service = $this->get('member.internal_form_service');
        $memberProfile  = $service->getMemberInfo($ownerMember);
        $organizationProfile  = $service->getOrganizationInfo($ownerMember);
    
        $data = array(
            'entity'      => $entity,
            'ownerMember' => $ownerMember,
            'ownerMemberForms' => $organizationActiveForms,
            'selectedTab' => self::MAIN_TAB,
            'selectedSubTab' => self::SUB_TAB_ORG,
            'memberProfile' => $memberProfile,
            'organizationProfile' => $organizationProfile,
        );
    
        return $this->render('AdminBundle:Organization:show.html.twig', $data);
    }
    
    public function formsAccessAction($id)
    {
        $em = $this->getDoctrine()->getManager();

        $entity = $em->getRepository('MemberBundle:Organization')->find($id);

        if (!$entity) {
            throw $this->createNotFoundException('Unable to find Organization entity.');
        }
        
        $organizationActiveForms =  $em->getRepository('MemberBundle:OrganizationFormPermission')->getFormsByOrganization($entity);
        
        $qb = $em->getRepository('ProductBundle:Form')->createQueryBuilder('f');        
        $qb->where('f.status = :status')->setParameter('status', Form::STATUS_ACTIVE);
        
        $paginator  = $this->get('knp_paginator');
        $pagination = $paginator->paginate(
                $qb,
                $this->getRequest()->get('page', 1),
                10 /*items limit*/
        );

        $data = array(
            'entity' => $entity,
            'organizationActiveForms' => $organizationActiveForms,
            'pagination'  => $pagination,
            'selectedTab' => self::MAIN_TAB,
            'selectedSubTab' => self::SUB_TAB_ORG,
        );
        
        return $this->render('AdminBundle:Organization:formsAccess.html.twig', $data);
    }
    
    public function changeFormAccessAction(Request $request)
    {
        $postData = $request->request->all();
        $em = $this->getDoctrine()->getManager();

        $entity = $em->getRepository('MemberBundle:Organization')->find($request->get('id'));        
        if (!$entity) {
            throw $this->createNotFoundException('Unable to find Organization entity.');
        }
        
        $formEntity = $em->getRepository('ProductBundle:Form')->find($postData['form_id']);
        if (!$entity) {
            throw $this->createNotFoundException('Unable to find Form entity.');
        }
        
        $criteria = array('organization' => $entity, 'form' => $formEntity);
        $organizationFormAccess = $em->getRepository('MemberBundle:OrganizationFormPermission')->findOneBy($criteria);
        
        if ($postData['access'] && !$organizationFormAccess) {

            //Find member of this organization. Need to be fix for One to Many relationship(1 org to many member)
            $member = $em->getRepository('MemberBundle:Member')->findOneByOrganization($entity);
            
            $this->get('member.form_service')->addFormPermissionToOrganization($formEntity, $member, false);
//             $organizationFormAccess = new OrganizationFormPermission();
//             $organizationFormAccess->setForm($formEntity);
//             $organizationFormAccess->setOrganization($entity);
//             $organizationFormAccess->setDateCreated(new \DateTime());
//             $em->persist($organizationFormAccess);
//             $organizationFormAccess->setDateExpiry(\DateTime::add('6M'));
        } else {
            $em->remove($organizationFormAccess);
        }

        $result = $em->flush();

        $response = new Response(json_encode(array('result' => $result)));
        $response->headers->set('Content-Type', 'application/json');
        
        return $response;
    }

    /**
     * Delete Organization
     */
    public function deleteAction(Request $request)
    {
        $id = $request->get('id', null);
        $organization = $this->getDoctrine()->getManager()->getRepository('MemberBundle:Organization')->find($id);

        if (!$organization) {
            throw $this->createNotFoundException('Organization does not exists.');
        }

        if ($request->isMethod('POST')) {
            $this->deleteOrganization($organization);
            $this->get('helper.flash_messenge')->showSuccessMessage('Organization account successfully deleted.');
        } else {
            $this->get('helper.flash_messenge')->showErrorMessage('Organization does not match an account in our records.');
        }

        return $this->redirect($this->generateUrl('admin_organization'));
    }
    /**
     * Creates a new Organization entity.
     *
     *
    public function createAction(Request $request)
    {
        $entity = new Organization();
        $form = $this->createCreateForm($entity);
        $form->handleRequest($request);

        if ($form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->persist($entity);
            $em->flush();

            return $this->redirect($this->generateUrl('admin_organization_show', array('id' => $entity->getId())));
        }

        $data = array(
            'entity' => $entity,
            'form'   => $form->createView(),
            'selectedTab' => 'organization',
            'formbuilderTab' => 'questionLists'
        );

        return $this->render('AdminBundle:Organization:new.html.twig', $data);
    } */


    /**
     * Creates a form to create a Organization entity.
     *
     * @param Organization $entity The entity
     *
     * @return \Symfony\Component\Form\Form The form
     *
    private function createCreateForm(Organization $entity)
    {
        $form = $this->createForm(new OrganizationType(), $entity, array(
            'action' => $this->generateUrl('admin_organization_create'),
            'method' => 'POST',
        ));

        $form->add('submit', 'submit', array('label' => 'Create'));

        return $form;
    } */

    /**
     * Displays a form to create a new Organization entity.
     *
     *
    public function newAction()
    {
        $entity = new Organization();
        $form   = $this->createCreateForm($entity);

        $data = array(
            'entity' => $entity,
            'form'   => $form->createView(),
            'selectedTab' => 'organization',
            'formbuilderTab' => 'questionLists'
        );

        return $this->render('AdminBundle:Organization:new.html.twig', $data);
    } */

    /**
     * Displays a form to edit an existing Organization entity.
     *
    public function editAction($id)
    {
        $em = $this->getDoctrine()->getManager();

        $entity = $em->getRepository('MemberBundle:Organization')->find($id);

        if (!$entity) {
            throw $this->createNotFoundException('Unable to find Organization entity.');
        }

        $editForm = $this->createEditForm($entity);
        $deleteForm = $this->createDeleteForm($id);

        $data =  array(
            'entity'      => $entity,
            'edit_form'   => $editForm->createView(),
            'delete_form' => $deleteForm->createView(),
            'selectedTab' => 'organization',
            'formbuilderTab' => 'questionLists'
        );

        return $this->render('AdminBundle:Organization:edit.html.twig', $data);
    } */

    /**
    * Creates a form to edit a Organization entity.
    *
    * @param Organization $entity The entity
    *
    * @return \Symfony\Component\Form\Form The form
    *
    private function createEditForm(Organization $entity)
    {
        $form = $this->createForm(new OrganizationType(), $entity, array(
            'action' => $this->generateUrl('admin_organization_update', array('id' => $entity->getId())),
            'method' => 'PUT',
        ));

        $form->add('submit', 'submit', array('label' => 'Update'));

        return $form;
    } */
    

    /**
     * Edits an existing Organization entity.
     *
    public function updateAction(Request $request, $id)
    {
        $em = $this->getDoctrine()->getManager();

        $entity = $em->getRepository('MemberBundle:Organization')->find($id);

        if (!$entity) {
            throw $this->createNotFoundException('Unable to find Organization entity.');
        }

        $deleteForm = $this->createDeleteForm($id);
        $editForm = $this->createEditForm($entity);
        $editForm->handleRequest($request);

        if ($editForm->isValid()) {
            $em->flush();

            return $this->redirect($this->generateUrl('admin_organization_edit', array('id' => $id)));
        }

        $data = array(
            'entity'      => $entity,
            'edit_form'   => $editForm->createView(),
            'delete_form' => $deleteForm->createView(),
            'selectedTab' => 'organization',
            'formbuilderTab' => 'questionLists'
        );

        return $this->render('AdminBundle:Organization:edit.html.twig', $data);
    } */


    /**
     * Deletes a Organization entity.
     *
    public function deleteAction(Request $request, $id)
    {
        $form = $this->createDeleteForm($id);
        $form->handleRequest($request);

        if ($form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $entity = $em->getRepository('MemberBundle:Organization')->find($id);

            if (!$entity) {
                throw $this->createNotFoundException('Unable to find Organization entity.');
            }

            $em->remove($entity);
            $em->flush();
        }

        return $this->redirect($this->generateUrl('admin_organization'));
    } */

    /**
     * Creates a form to delete a Organization entity by id.
     *
     * @param mixed $id The entity id
     *
     * @return \Symfony\Component\Form\Form The form
     *
    private function createDeleteForm($id)
    {
        return $this->createFormBuilder()
            ->setAction($this->generateUrl('admin_organization_delete', array('id' => $id)))
            ->setMethod('DELETE')
            ->add('submit', 'submit', array('label' => 'Delete'))
            ->getForm(  )
        ;
    } */
}
