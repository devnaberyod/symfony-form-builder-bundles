<?php 

namespace YPKY\AdminBundle\Controller;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\EventDispatcher\GenericEvent;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;

use YPKY\AdminBundle\Form\CustomerFormType;
use YPKY\UserBundle\Entity\User;
use YPKY\UserBundle\Services\UserTokenService;
use YPKY\UserBundle\Event\UserAccessTokenEvent;
use YPKY\MemberBundle\Entity\MemberFormPermission;
use YPKY\MemberBundle\Entity\OrganizationFormPermission;


class PeopleController extends OrganizationManagerController
{
    public function indexAction(Request $request)
    {
        $orgId = $request->get('org_id', null);
        $searchQuery = !$orgId ? $request->get('search_query') : $orgId;
        $internalFormService = $this->get('member.internal_form_service');
        $searchResult = !$orgId ? $this->getDoctrine()->getRepository('MemberBundle:Member')->searchMemberWithOrganizationByNameOrEmail($searchQuery)
            : $this->getDoctrine()->getRepository('MemberBundle:Member')->getMembersWithOrganizationByOrg($searchQuery);

        $paginator  = $this->get('knp_paginator');
        $pagination = $paginator->paginate(
            $searchResult,
            $request->get('page', 1),
            10 /*items limit*/
        );
        
        $searchQuery = $orgId ? $request->get('org_name') : $searchQuery;

        $form = $this->createForm(new CustomerFormType());

        if($request->isMethod('POST')) {
            $form->handleRequest($request);

            if($form->isValid()) {
                $formData = $form->getData();

                $userExists = $this->getDoctrine()->getRepository('UserBundle:User')->findOneByEmail($formData['email']);
                if($userExists) {
                    $showAddModal = true;
                    $this->get('helper.flash_messenge')->showErrorMessage('Email address already exists!');

                } else {
                    $password = $this->get('user.service.password')->generatePassword();
                    $name = array('last_name' => $formData['lastName'], 'first_name' => $formData['firstName']);

                    $registerParams = array(
                        'email' => $formData['email'],
                        'password' => $password,
                        'name' => $name,
                    );

                    //save member registration data
                    $member = $this->get('member.registration')->registerMember($registerParams);

                    // Set Member and Organization Forms permission
                    $this->get('member.internal_form_service')->addFormOrgAndMemberPermission($member);

                    // Save Member Name data as MemberFormAsnwer
                    $this->get('member.form_service')->saveMemberName($member, $name);

                    // Add permission to the selected forms.
                    $em = $this->getDoctrine()->getManager();
                    foreach($formData['forms'] as $each) {
                        $this->get('member.form_service')->addFormPermissionToOrganization($each, $member, false);
                    }
                    $em->flush();

                    // Create Token
                    $tokenExpiration = UserTokenService::getTokenExpiration();
                    $token = $this->get('helper.user.tokenizer')->generateUserToken($member->getUser(), $tokenExpiration);

                    // Dispatch Create User Events
                    $event = new UserAccessTokenEvent();
                    $event->setToken($token);

                    $this->get('event_dispatcher')->dispatch('user.access.token.new', $event);

                    // Dispatch event for intercom user register.
                    $this->get('event_dispatcher')->dispatch('intercom.user.register', new GenericEvent($member->getUser()));

                    // Send invitation
                    if($formData['sendInvite']) {
                        $inviteEvent = new GenericEvent($member->getUser(), array('password' => $password));
                        $this->get('event_dispatcher')->dispatch('notification.user.createFromAdmin', $inviteEvent);
                    }

                    $this->get('helper.flash_messenge')->showSuccessMessage('Successfully created new customer with an email ' . $formData['email']);

                    return $this->redirect($this->generateUrl('admin_people'));
                }

            } else {
                $showAddModal = true;
                $this->get('helper.flash_messenge')->showErrorMessage('Please check the form for the errors.');
            }
        }


        $data = array(
            'pagination'  => $pagination,
            'organization' => $searchResult,
            'searchQuery' => $searchQuery,
            'placeholder' => self::MEMBER_SEARCH_PLACEHOLDER,
            'selectedSubTab' => self::SUB_TAB_PEOPLE,
            'selectedTab' => self::MAIN_TAB,
            'action' => $this->generateUrl('admin_people'),
            'showAddModal' => isset($showAddModal) ? $showAddModal : false,
            'form' => $form->createView(),
            'memberForms' => $this->getMemberForms()
        );

        return $this->render('AdminBundle:People:index.html.twig', $data);
    }

    public function resetPasswordAction(Request $request)
    {
        $email = $request->get('email');
        $user = $this->getDoctrine()->getManager()->getRepository('UserBundle:User')->findOneByEmail($email);

        if (!is_null($user)) {
            $token = $this->get('helper.user.tokenizer')->generateUserToken($user, 1);

            $event = new \YPKY\HelperBundle\Event\RequestPasswordEvent();
            $event->setToken($token);
            $this->get('event_dispatcher')->dispatch('helper.user.request_reset_password', $event);
            $this->get('event_dispatcher')->dispatch('notification.user.request_reset_password', $event);
            
            if ($request->isXmlHttpRequest()) {
                return new JsonResponse(array('error' => 0, 'message' => 'success'));
            }

            $this->get('helper.flash_messenge')->showSuccessMessage('Successfully send reset password link to ' . $email);
        } else {
            $this->get('helper.flash_messenge')->showErrorMessage('Email address does not match an account in our records.');
        }

        return $this->redirect($this->generateUrl('admin_people'));
    }

    /**
     * This function temporary for now. Later if 1:many relationship is implemented this will be change
     */
    public function deleteAction(Request $request)
    {
        $id = $request->get('member_id', null);
        $member = $this->getDoctrine()->getManager()->getRepository('MemberBundle:Member')->find($id);

        if (!$member) {
            throw $this->createNotFoundException('Member does not exists.');
        }

        if ($request->isMethod('POST')) {
            $this->deleteMember($member);
            $this->get('helper.flash_messenge')->showSuccessMessage('Member account successfully deleted.');
        } else {
            $this->get('helper.flash_messenge')->showErrorMessage('Member does not match an account in our records.');
        }

        return $this->redirect($this->generateUrl('admin_people'));
    }

}
