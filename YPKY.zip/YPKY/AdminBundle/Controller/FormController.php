<?php

namespace YPKY\AdminBundle\Controller;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;

use YPKY\ProductBundle\Entity\QuestionTemplate;
use YPKY\ProductBundle\Form\QuestionTemplateType;

use YPKY\AdminBundle\Classes\SearchConstant;

/**
 * Form controller.
 *
 */
class FormController extends Controller
{

    /**
     * Lists all Form entities.
     *
     */
    public function indexAction(Request $request)
    {
        $searchQuery = $request->get('search_query'); 
        $em = $this->getDoctrine()->getManager();

        $result = $em->getRepository('ProductBundle:Form')->searchFormByName($searchQuery);

        $paginator  = $this->get('knp_paginator');
        $pagination = $paginator->paginate(
            $result,
            $request->get('page', 1),
            10 /*items limit*/
        );

        // echo count($result); exit;
        $data = array(
            'pagination'  => $pagination,
            'selectedTab' => SearchConstant::SELECTED_TAB_FORM_BUILDER,
            'formbuilderTab' => SearchConstant::FORM_BUILDER_TAB_FORM,
            'action' => $this->generateUrl('admin_form'),
            'searchQuery' => $searchQuery,
            'placeholder' => SearchConstant::FORM_SEARCH_PLACEHOLDER,
            'memberForms' => $em->getRepository('MemberBundle:MemberForm')->findMemberFormMapByFormOrMember(),
            'formQuestionLocked' => $em->getRepository('ProductBundle:FormQuestion')->findFormQuestionLockedMapByForm(),
            'orgForms' => $em->getRepository('MemberBundle:OrganizationFormPermission')->findOrganizationFormMapByForm(),
            'action' => $this->generateUrl('admin_form'),
        );

        return $this->render('AdminBundle:Form:index.html.twig', $data);
    }

    /*
        Duplicate Form
    */
    public function duplicateFormAction(Request $request)
    {
        $formId = $request->get('form_id', null);
        $formEntity = $this->getDoctrine()->getRepository('ProductBundle:Form')->find($formId);

        if (null !== $formId && $formEntity) {
            $form = $this->get('product.form_duplicate_service')->duplicateForm($formEntity);
            $this->get('helper.flash_messenge')->showSuccessMessage($form . ' successfully created.');
        }

        return $this->redirect($this->generateUrl('admin_form'));
        
    }

    /**
     * Delete form
     */

    public function deleteFormAction(Request $request)
    {
        $formId = $request->get('form_id', null);
        $em = $this->getDoctrine()->getManager();
        $formRepository = $this->getDoctrine()->getRepository('ProductBundle:Form');
        $formEntity = $formRepository->find($formId);

        //Criterias to a form not to delete
        $isUsedByMember = $em->getRepository('MemberBundle:MemberForm')->findOneByForm($formEntity);
        $isUsedByOrg = $em->getRepository('MemberBundle:OrganizationFormPermission')->findOneByForm($formEntity);
        $formQuestionLocked = $em->getRepository('ProductBundle:FormQuestion')->findFormQuestionLockedMapByForm($formEntity);

        if (null !== $formId && $formEntity && !$isUsedByMember && !$isUsedByOrg && !isset($formQuestionLocked[$formEntity->getId()])) {
            $formRepository->remove($formEntity);
            $this->get('helper.flash_messenge')->showSuccessMessage($formEntity->getName() . ' successfully deleted.');
        } else {
            $this->get('helper.flash_messenge')->showErrorMessage('The form was modified and cannot be deleted. Please refresh forms list.');
        }
        
        return $this->redirect($this->generateUrl('admin_form'));
    }
}
