<?php
namespace YPKY\AdminBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;

abstract class MemberAwareController extends Controller
{
    private $member = null;

    /**
     * @return \YPKY\MemberBundle\Entity\Member
     */
    protected function getMember()
    {
        if($this->member) {
            return $this->member;
        }

        $memberId = $this->getRequest()->get('member_id');
        $this->member = $this->getDoctrine()->getRepository('MemberBundle:Member')->find($memberId);

        if (!$this->member) {
            // throw exception; all member aware controller should have a logged in member
            throw new \Exception('Invalid member');
        }

        return $this->member;
    }

    protected function getMemberService()
    {
        $service = $this->get('member.form_service');
        $service->setMember($this->getMember());
        
        return $service;
    }
    
    protected function getFormProductFactoryService()
    {
        $service = $this->get('form_builder.form_product_factory');
        $service->setMember($this->getMember());

        return $service;
    }
}