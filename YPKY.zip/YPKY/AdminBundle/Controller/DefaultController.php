<?php

namespace YPKY\AdminBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Security\Core\SecurityContext;
use YPKY\AdminBundle\Classes\AdminUserConstants;

class DefaultController extends Controller
{
    public function indexAction(Request $request)
    {

        $data = array(
            'selectedTab' => 'dashboard'
        );

        return $this->render('AdminBundle:Default:index.html.twig', $data);
    }

    public function loginAction(Request $request)
    {
        // $request = $this->getRequest();
        $session = $request->getSession();

        // get the login error if there is one
        if ($request->attributes->has(SecurityContext::AUTHENTICATION_ERROR)) {
            $error = $request->attributes->get(SecurityContext::AUTHENTICATION_ERROR);
        } else {
            $error = $session->get(SecurityContext::AUTHENTICATION_ERROR);
            $session->remove(SecurityContext::AUTHENTICATION_ERROR);
        }

        if($this->container->getParameter('url.staging') && !$session->has('showStagingWarningMessage')) {
            $session->set('showStagingWarningMessage', true);
        }

        return $this->render('AdminBundle:Default:login.html.twig', array(
            // last username entered by the user
            'last_username' => $session->get(SecurityContext::LAST_USERNAME),
            'error'         => $error
        ));
    }

    public function removeStagingWarningMessageAction(Request $request)
    {
        if($request->isMethod('POST')) {
            $request->getSession()->remove('showStagingWarningMessage');
        }
    }

    public function adminSessionAction()
    {
        $user = $this->getUser()->getUser();

        //check user type admin
        $em = $this->getDoctrine()->getManager();
        $userAdmin = $em->getRepository('AdminBundle:AdminUser')->find($user->getId());

        if ($userAdmin) {
            $data['userAdmin'] = json_encode(array(
                'type' => $userAdmin->getType(),
                'firstname' => $userAdmin->getFirstName(),
                'lastname' => $userAdmin->getLastName()
            ));

            $data['adminUserType'] = $userAdmin->getType();
        }

        $data['typeAdmin'] = AdminUserConstants::TYPE_ADMIN;
        $data['typeSuperAdmin'] = AdminUserConstants::TYPE_SUPER_ADMIN;

        $response = $this->render('AdminBundle:Default:session.js.twig', $data);
        $response->headers->set('content-type', 'application/javascript');
        $response->headers->addCacheControlDirective('no-cache', true);
        $response->headers->addCacheControlDirective('no-store', true);

        return $response;
    }
}
