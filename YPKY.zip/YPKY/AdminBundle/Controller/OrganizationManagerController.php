<?php

namespace YPKY\AdminBundle\Controller;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;

use YPKY\AdminBundle\Classes\Interfaces\MemberOrganizationConstant;
use YPKY\MemberBundle\Entity\Organization;
use YPKY\MemberBundle\Entity\Member;

/**
 * Organization manager controller. 
 * We will use this class to re use functions related to organization for member and org page
 *
 */
abstract class OrganizationManagerController extends Controller implements MemberOrganizationConstant
{
    protected function getMemberForms()
    {
        $internalForms = $this->get('member.internal_form_service')->getInternalForms();
        return $this->getDoctrine()->getManager()->getRepository('MemberBundle:OrganizationFormPermission')->findOrganizationFormMapByOrgId(array_values($internalForms));
    }

    protected function deleteMember(Member $member)
    {
        $em = $this->getDoctrine()->getManager();

        $email = $member->getUser()->getEmail();
        // Delete user intercom account
        $this->get('helper.intercom_client')->deleteUserByEmail($email);
    
        //Delete wp user record
        $this->get('helper.wordpress_platform')->deleteUserByEmail($email);

        $member->getOrganization()->removeMember($member);

        if(!count($member->getOrganization()->getMembers())) {
            $em->remove($member->getOrganization());
        }

        $em->remove($member);
        $em->flush();
    }

    protected function deleteOrganization(Organization $org)
    {
        $em = $this->getDoctrine()->getManager();
        $members = $org->getMembers();

        foreach($members as $member) {
            $email = $member->getUser()->getEmail();
            // Delete user intercom account
            $this->get('helper.intercom_client')->deleteUserByEmail($email);

            //Delete wp user record
            $this->get('helper.wordpress_platform')->deleteUserByEmail($email);
        }

        $em->remove($org);
        $em->flush();
    }
}
