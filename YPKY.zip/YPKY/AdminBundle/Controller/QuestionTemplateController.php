<?php

namespace YPKY\AdminBundle\Controller;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;

use YPKY\ProductBundle\Entity\QuestionTemplate;
use YPKY\ProductBundle\Form\QuestionTemplateType;

use YPKY\MemberBundle\Services\FlashMessageService;
use YPKY\AdminBundle\Classes\SearchConstant;
/**
 * QuestionTemplate controller.
 *
 */
class QuestionTemplateController extends Controller
{

    const ITEMS_LIMIT = 10;

    /**
     * Lists all QuestionTemplate entities.
     *
     */
    public function indexAction(Request $request)
    {
        $searchQuery = $request->get('search_query'); 

        $em = $this->getDoctrine()->getManager();
        $qb = $em->getRepository('ProductBundle:QuestionTemplate')->searchQuestionTemplateByQuestion($searchQuery);

        $paginator  = $this->get('knp_paginator');
        $currentPage =  $request->get('page', 1);
        $pagination = $paginator->paginate(
            $qb,
            $currentPage,
            self::ITEMS_LIMIT /*items limit*/
        );

        //count all number of page in pagination
        $questionListNoPagination = (integer)($pagination->getTotalItemCount() / self::ITEMS_LIMIT) + 1;

        $data = array(
            'selectedTab' => SearchConstant::SELECTED_TAB_FORM_BUILDER,
            'formbuilderTab' => SearchConstant::FORM_BUILDER_TAB_QUESTION,
            'pagination' => $pagination,
            'questionListNoPagination' =>  $questionListNoPagination,
            'currentPage' => $currentPage,
            'placeholder' => SearchConstant::FORM_QUESTION_SEARCH_PLACEHOLDER,
            'action' => $this->generateUrl('admin_question'),
            'searchQuery' => $searchQuery
        );

        return $this->render('AdminBundle:QuestionTemplate:index.html.twig', $data);
    }
    /**
     * Creates a new QuestionTemplate entity.
     *
     */
    public function createAction(Request $request)
    {
        $entity = new QuestionTemplate();
        $form = $this->createCreateForm($entity);
        $form->handleRequest($request);

        if ($form->isValid()) {
            $entity->setStatus(1);
            $em = $this->getDoctrine()->getManager();
            $em->persist($entity);
            $em->flush();

            $this->get('helper.flash_messenge')->showSuccessMessage('Question was successfully added.');

            return $this->redirect($this->generateUrl('admin_question'));
        }
        else{
            $this->get('helper.flash_messenge')->showErrorMessage('Question was not successfully saved.');
        }

        $data = array(
            'entity' => $entity,
            'form'   => $form->createView(),
            'selectedTab' => 'formBuilder',
            'formbuilderTab' => 'questionLists'
        );

        return $this->render('AdminBundle:QuestionTemplate:new.html.twig', $data);
    }

    /**
     * Creates a form to create a QuestionTemplate entity.
     *
     * @param QuestionTemplate $entity The entity
     *
     * @return \Symfony\Component\Form\Form The form
     */
    private function createCreateForm(QuestionTemplate $entity)
    {
        $form = $this->createForm(new QuestionTemplateType(), $entity, array(
            'action' => $this->generateUrl('admin_question_create'),
            'method' => 'POST',
        ));

        $form->add('submit', 'submit', array('label' => 'Create'));

        return $form;
    }

    /**
     * Displays a form to create a new QuestionTemplate entity.
     *
     */
    public function newAction()
    {
        $entity = new QuestionTemplate();
        $form   = $this->createCreateForm($entity);

        $data = array(
            'entity' => $entity,
            'form'   => $form->createView(),
            'selectedTab' => 'formBuilder',
            'formbuilderTab' => 'questionLists'
        );

        return $this->render('AdminBundle:QuestionTemplate:new.html.twig', $data );
    }

    /**
     * Finds and displays a QuestionTemplate entity.
     *
     */
    public function showAction($id)
    {
        $em = $this->getDoctrine()->getManager();

        $entity = $em->getRepository('ProductBundle:QuestionTemplate')->find($id);

        if (!$entity) {
            throw $this->createNotFoundException('Unable to find QuestionTemplate entity.');
        }

        $deleteForm = $this->createDeleteForm($id);

        $data = array(
            'entity'      => $entity,
            'delete_form' => $deleteForm->createView(),
            'selectedTab' => 'formBuilder',
            'formbuilderTab' => 'questionLists'
        );

        return $this->render('AdminBundle:QuestionTemplate:show.html.twig', $data );
    }

    /**
     * Displays a form to edit an existing QuestionTemplate entity.
     *
     */
    public function editAction($id)
    {
        $em = $this->getDoctrine()->getManager();

        $entity = $em->getRepository('ProductBundle:QuestionTemplate')->find($id);

        if (!$entity) {
            throw $this->createNotFoundException('Unable to find QuestionTemplate entity.');
        }

        $editForm = $this->createEditForm($entity);
        $deleteForm = $this->createDeleteForm($id);

        $data = array(
            'entity'      => $entity,
            'edit_form'   => $editForm->createView(),
            'delete_form' => $deleteForm->createView(),
            'selectedTab' => 'formBuilder',
            'formbuilderTab' => 'questionLists'
        );

        return $this->render('AdminBundle:QuestionTemplate:edit.html.twig', $data);
    }

    /**
    * Creates a form to edit a QuestionTemplate entity.
    *
    * @param QuestionTemplate $entity The entity
    *
    * @return \Symfony\Component\Form\Form The form
    */
    private function createEditForm(QuestionTemplate $entity)
    {
        //To get the current question page
        $request = $this->get('request');
        $currentPage =  $request->get('page', 1);

        $form = $this->createForm(new QuestionTemplateType(), $entity, array(
            'action' => $this->generateUrl('admin_question_update', array('page' => $currentPage, 'id' => $entity->getId())),
            'method' => 'PUT',
        ));

        $form->add('submit', 'submit', array('label' => 'Update'));

        return $form;
    }
    /**
     * Edits an existing QuestionTemplate entity.
     *
     */
    public function updateAction(Request $request, $id)
    {
        $em = $this->getDoctrine()->getManager();

        $entity = $em->getRepository('ProductBundle:QuestionTemplate')->find($id);

        if (!$entity) {
            throw $this->createNotFoundException('Unable to find QuestionTemplate entity.');
        }
        //To get the current question page
        $currentPage =  $request->get('page', 1);

        $deleteForm = $this->createDeleteForm($id);
        $editForm = $this->createEditForm($entity);
        $editForm->handleRequest($request);

        if ($editForm->isValid()) {
            $em->flush();

            $this->get('helper.flash_messenge')->showSuccessMessage('Question was successfully updated.');

            return $this->redirect($this->generateUrl('admin_question', array('page' => $currentPage)));
        } else {
            $this->get('helper.flash_messenge')->showErrorMessage('Question was not successfully saved. Please check for the errors.');
        }

        $data = array(
            'entity'      => $entity,
            'edit_form'   => $editForm->createView(),
            'delete_form' => $deleteForm->createView(),
            'selectedTab' => 'formBuilder',
            'formbuilderTab' => 'questionLists'
        );

        return $this->render('AdminBundle:QuestionTemplate:edit.html.twig', $data);
    }
    /**
     * Deletes a QuestionTemplate entity.
     *
     */
    public function deleteAction(Request $request, $id)
    {
        $form = $this->createDeleteForm($id);
        $form->handleRequest($request);

        if ($form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $entity = $em->getRepository('ProductBundle:QuestionTemplate')->find($id);

            if (!$entity) {
                throw $this->createNotFoundException('Unable to find QuestionTemplate entity.');
            }

            $em->remove($entity);
            $em->flush();
        }

        return $this->redirect($this->generateUrl('admin_question'));
    }

    /**
     * Creates a form to delete a QuestionTemplate entity by id.
     *
     * @param mixed $id The entity id
     *
     * @return \Symfony\Component\Form\Form The form
     */
    private function createDeleteForm($id)
    {
        return $this->createFormBuilder()
            ->setAction($this->generateUrl('admin_question_delete', array('id' => $id)))
            ->setMethod('DELETE')
            ->add('submit', 'submit', array('label' => 'Delete'))
            ->getForm()
        ;
    }
}
