<?php

namespace YPKY\AdminBundle\Controller;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;

use YPKY\ProductBundle\Entity\InfoCollectionType;
use YPKY\ProductBundle\Form\InfoCollectionTypeType;

/**
 * InfoCollectionType controller.
 *
 */
class InfoCollectionTypeController extends Controller
{

    /**
     * Lists all InfoCollectionType entities.
     *
     */
    public function indexAction()
    {
        $em = $this->getDoctrine()->getManager();

        $entities = $em->getRepository('ProductBundle:InfoCollectionType')->findAll();

        $data = array(
            'entities' => $entities,
            'selectedTab' => 'formBuilder',
            'formbuilderTab' => 'questionLists'
        );

        return $this->render('AdminBundle:InfoCollectionType:index.html.twig', $data);
    }
    /**
     * Creates a new InfoCollectionType entity.
     *
     */
    public function createAction(Request $request)
    {
        $entity = new InfoCollectionType();
        $form = $this->createCreateForm($entity);
        $form->handleRequest($request);

        if ($form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->persist($entity);
            $em->flush();

            return $this->redirect($this->generateUrl('admin_infoCollectionType_show', array('id' => $entity->getId())));
        }


        $data = array(
            'entity' => $entity,
            'form'   => $form->createView(),
            'selectedTab' => 'formBuilder',
            'formbuilderTab' => 'questionLists'
        );

        return $this->render('AdminBundle:InfoCollectionType:new.html.twig', $data);
    }

    /**
     * Creates a form to create a InfoCollectionType entity.
     *
     * @param InfoCollectionType $entity The entity
     *
     * @return \Symfony\Component\Form\Form The form
     */
    private function createCreateForm(InfoCollectionType $entity)
    {
        $form = $this->createForm(new InfoCollectionTypeType(), $entity, array(
            'action' => $this->generateUrl('admin_infoCollectionType_create'),
            'method' => 'POST',
        ));

        $form->add('submit', 'submit', array('label' => 'Create'));

        return $form;
    }

    /**
     * Displays a form to create a new InfoCollectionType entity.
     *
     */
    public function newAction()
    {
        $entity = new InfoCollectionType();
        $form   = $this->createCreateForm($entity);

        $data = array(
            'entity' => $entity,
            'form'   => $form->createView(),
            'selectedTab' => 'formBuilder',
            'formbuilderTab' => 'questionLists'
        );

        return $this->render('AdminBundle:InfoCollectionType:new.html.twig', $data);
    }

    /**
     * Finds and displays a InfoCollectionType entity.
     *
     */
    public function showAction($id)
    {
        $em = $this->getDoctrine()->getManager();

        $entity = $em->getRepository('ProductBundle:InfoCollectionType')->find($id);

        if (!$entity) {
            throw $this->createNotFoundException('Unable to find InfoCollectionType entity.');
        }

        $deleteForm = $this->createDeleteForm($id);

        $data = array(
            'entity'      => $entity,
            'delete_form' => $deleteForm->createView(),
            'selectedTab' => 'formBuilder',
            'formbuilderTab' => 'questionLists'
        );

        return $this->render('AdminBundle:InfoCollectionType:show.html.twig', $data);
    }

    /**
     * Displays a form to edit an existing InfoCollectionType entity.
     *
     */
    public function editAction($id)
    {
        $em = $this->getDoctrine()->getManager();

        $entity = $em->getRepository('ProductBundle:InfoCollectionType')->find($id);

        if (!$entity) {
            throw $this->createNotFoundException('Unable to find InfoCollectionType entity.');
        }

        $editForm = $this->createEditForm($entity);
        $deleteForm = $this->createDeleteForm($id);

        $data = array(
            'entity'      => $entity,
            'edit_form'   => $editForm->createView(),
            'delete_form' => $deleteForm->createView(),
            'selectedTab' => 'formBuilder',
            'formbuilderTab' => 'questionLists'
        );

        return $this->render('AdminBundle:InfoCollectionType:edit.html.twig', $data);
    }

    /**
    * Creates a form to edit a InfoCollectionType entity.
    *
    * @param InfoCollectionType $entity The entity
    *
    * @return \Symfony\Component\Form\Form The form
    */
    private function createEditForm(InfoCollectionType $entity)
    {
        $form = $this->createForm(new InfoCollectionTypeType(), $entity, array(
            'action' => $this->generateUrl('admin_infoCollectionType_update', array('id' => $entity->getId())),
            'method' => 'PUT',
        ));

        $form->add('submit', 'submit', array('label' => 'Update'));

        return $form;
    }
    /**
     * Edits an existing InfoCollectionType entity.
     *
     */
    public function updateAction(Request $request, $id)
    {
        $em = $this->getDoctrine()->getManager();

        $entity = $em->getRepository('ProductBundle:InfoCollectionType')->find($id);

        if (!$entity) {
            throw $this->createNotFoundException('Unable to find InfoCollectionType entity.');
        }

        $deleteForm = $this->createDeleteForm($id);
        $editForm = $this->createEditForm($entity);
        $editForm->handleRequest($request);

        if ($editForm->isValid()) {
            $em->flush();

            return $this->redirect($this->generateUrl('admin_infoCollectionType_edit', array('id' => $id)));
        }

        $data = array(
            'entity'      => $entity,
            'edit_form'   => $editForm->createView(),
            'delete_form' => $deleteForm->createView(),
            'selectedTab' => 'formBuilder',
            'formbuilderTab' => 'questionLists'
        );

        return $this->render('AdminBundle:InfoCollectionType:edit.html.twig', $data);
    }
    /**
     * Deletes a InfoCollectionType entity.
     *
     */
    public function deleteAction(Request $request, $id)
    {
        $form = $this->createDeleteForm($id);
        $form->handleRequest($request);

        if ($form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $entity = $em->getRepository('ProductBundle:InfoCollectionType')->find($id);

            if (!$entity) {
                throw $this->createNotFoundException('Unable to find InfoCollectionType entity.');
            }

            $em->remove($entity);
            $em->flush();
        }

        return $this->redirect($this->generateUrl('admin_infoCollectionType'));
    }

    /**
     * Creates a form to delete a InfoCollectionType entity by id.
     *
     * @param mixed $id The entity id
     *
     * @return \Symfony\Component\Form\Form The form
     */
    private function createDeleteForm($id)
    {
        return $this->createFormBuilder()
            ->setAction($this->generateUrl('admin_infoCollectionType_delete', array('id' => $id)))
            ->setMethod('DELETE')
            ->add('submit', 'submit', array('label' => 'Delete'))
            ->getForm()
        ;
    }
}
