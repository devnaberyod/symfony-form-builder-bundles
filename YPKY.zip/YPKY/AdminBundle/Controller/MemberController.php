<?php

namespace YPKY\AdminBundle\Controller;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use YPKY\ProductBundle\Entity\Form;
use YPKY\MemberBundle\Entity\Organization;

/**
 * Member controller.
 */
class MemberController extends MemberAwareController
{    
    const MAIN_TAB = 'member';
    const SUB_TAB = 'organization';

    const SUBMIT_NEXT_VALUE = 'Save, go to Next Step';
    const SUBMIT_FINISH_VALUE = 'Finish';
    const SUBMIT_DASHBOARD_VALUE = 'Save, return to Dashboard';

    public function editFormAction(Request $request)
    {
        $member = $this->getMember();
        $organizationProfile  = $this->get('member.internal_form_service')->getOrganizationInfo($member);

        // check form
        $formEntity = $this->getFormEntity($request->get('form_id'));

        // check form access
        $this->checkFormAccess($formEntity, $member->getOrganization());

        if($formSectionId = $request->get('form_section_id')) {
            $formSection = $this->getDoctrine()->getRepository('ProductBundle:FormSection')->find($formSectionId);
        } else {
            $formSection = $formEntity->getFormSections()->first();
        }

        $form = $this->getFormProductFactoryService()->createForm($formEntity, $formSection);


        if($request->isMethod('POST')) {
    
            $form->submit($request);
    
            if ($form->isValid()) {
                $incrementPage = false;
                $redirectUrl = $this->generateUrl('admin_organization_show', array('id' => $member->getOrganization()->getId()));
    
                switch($action = $request->get('submit_action')) {
                    case self::SUBMIT_NEXT_VALUE :
                    case self::SUBMIT_DASHBOARD_VALUE :
                        $formSections = $formEntity->getFormSections()->toArray();
                        $index = array_search($formSection, $formSections);
                        $nextFormSection = $formSections[$index + 1];
                        $incrementPage = true;
    
                        if($action == self::SUBMIT_NEXT_VALUE) {
                            $urlParams = array('member_id' => $member->getId(), 'form_id' => $formEntity->getId(), 'form_section_id' => $nextFormSection->getId());
                            $redirectUrl = $this->generateUrl('admin_member_editForm', $urlParams);
                        }
                        break;
                }
    
                $memberForm = $this->get('member.form_service')->prepareMemberForm($formEntity, $member);
                $this->getMemberService()->saveMemberFormEntity($memberForm, $formSection, $incrementPage);
                $this->getMemberService()->saveMemberFormAnswers($memberForm, $formSection, $form, $request->files->all());

                $this->get('helper.flash_messenge')->showSuccessMessage('Form was successfully saved.');

                return $this->redirect($redirectUrl);
            }
        }
    
        return $this->render('AdminBundle:Member:editForm.html.twig', array(
            'selectedTab' => self::MAIN_TAB,
            'selectedSubTab' => self::SUB_TAB,
            'form' => $form->createView(),
            'formEntity' => $formEntity,
            'formSection' => $formSection,
            'member' => $member,
            'organization' => $organizationProfile,
            'memberForm' => null,//$memberForm,
            'submitNextValue' => self::SUBMIT_NEXT_VALUE,
            'submitFinishValue' => self::SUBMIT_FINISH_VALUE,
            'submitDashboardValue' => self::SUBMIT_DASHBOARD_VALUE
        ));
    }
    
    /// Private Functions
    private function getFormEntity($id)
    {
        $formEntity = $this->getDoctrine()->getRepository('ProductBundle:Form')->find($id);
    
        if (!$formEntity) {
            throw $this->createNotFoundException('Form is not valid.');
        }
    
        return $formEntity;
    }
    
    private function checkFormAccess(Form $formEntity, Organization $organization)
    {
        $criteria = array('form' => $formEntity, 'organization' => $organization);
        $hasFormAccess = $this->getDoctrine()->getRepository('MemberBundle:OrganizationFormPermission')->findOneBy($criteria);
    
        if (!$hasFormAccess) {
            throw $this->createNotFoundException('You do not have access yet to this form.');
        }
    
        return $hasFormAccess;
    }
}
