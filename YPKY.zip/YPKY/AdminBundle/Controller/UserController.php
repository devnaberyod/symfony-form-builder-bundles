<?php

namespace YPKY\AdminBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\RedirectResponse;

use YPKY\AdminBundle\Entity\AdminUser;
use YPKY\AdminBundle\Classes\AdminUserConstants;
use YPKY\UserBundle\Services\UserTokenService;

class UserController extends Controller
{
    public function addAdminUserAction(Request $request)
    {
        $form = $this->createAddForm(new AdminUser());

        $data = array(
            'form' => $form->createView(),
            'selectedTab' => ''
        );

        return $this->render('AdminBundle:User:addUser.html.twig', $data);
    }

    public function processAdminUserAction(Request $request)
    {
        $adminUser = new AdminUser();
        $adminUser->setUser(new \YPKY\UserBundle\Entity\User());

        $form = $this->createAddForm($adminUser);
        $form->handleRequest($request);

        if ($form->isValid()) {

            // generated password
            $password = $this->get('helper.password.generator')->generate(10);

            $adminUser = $this->get('admin.user')->setUser($form->getData())
                                                 ->setSalt(md5(time()))
                                                 ->setPassword($password)
                                                 ->setStatus(AdminUserConstants::SUSPENDED)
                                                 ->save();

            $token = $this->get('helper.user.tokenizer')->generateUserToken($adminUser->getUser(), UserTokenService::getTokenExpiration());

            $event = new \YPKY\AdminBundle\Event\AdminUserEvent();
            $event->setToken($token);
            $event->setPassword($password);

            $this->get('event_dispatcher')->dispatch('user.access.token.new', $event);
            $this->get('event_dispatcher')->dispatch('admin.user.new', $event);
            

            return $this->redirect($this->generateUrl('admin_homepage'));
        }


        $data = array(
            'form' => $form->createView(),
            'selectedTab' => ''
        );

        return $this->render('AdminBundle:User:addUser.html.twig', $data);
    }

    public function emailConfirmationAction(Request $request)
    {
        if ($this->getUser() instanceof \Symfony\Component\Security\Core\User\User) {
            return new RedirectResponse($this->generateUrl('admin_homepage'));
        }

        if (!is_null($this->getUser())) {

            if (in_array("ROLE_MEMBER", $this->getUser()->getRoles())) {
                return new RedirectResponse($this->generateUrl('member_homepage'));
            }
            
            return new RedirectResponse($this->generateUrl('admin_homepage'));
        }

        $token = $request->get('token');

        $repository = $this->getDoctrine()->getManager()->getRepository('UserBundle:UserAccessToken');
        
        $form = $this->createForm(new \YPKY\UserBundle\Form\ChangePasswordType());
        $form->add('submit','submit', array('label' => 'Save Changes'));

        // expiration not here not being checked
        $userToken = $repository->findOneByToken($token);

        if (is_null($userToken)) {
            return new RedirectResponse($this->generateUrl('admin_homepage'));
        }

        // authenticate

        if ($request->isMethod('POST')) {
                $form->handleRequest($request);

                if ($form->isValid()) {
                    $eventDispatcher = $this->get('event_dispatcher');

                    $password = $form->get('password')->getData(); 

                    $user = $userToken->getUser();
                    $user->setStatus(\YPKY\UserBundle\Classes\UserConstants::ACTIVE);

                    $adminUser = $this->getDoctrine()->getManager()->getRepository('AdminBundle:AdminUser')->findOneByUser($user);

                    $service = $this->get('user.service');
                    $user = $service->setUser($user)
                                    ->setPassword($password)
                                    ->getUser();

                    $authorizedUser = new \YPKY\UserBundle\Security\User($user, $user->getSalt(), AdminUserConstants::$ROLE[$adminUser->getType()]);

                    $token = new \Symfony\Component\Security\Core\Authentication\Token\UsernamePasswordToken($authorizedUser, $authorizedUser->getPassword(), 'admin_area', $authorizedUser->getRoles());
                    $request->getSession()->set('_security_admin_area', serialize($token));

                    $event = new \Symfony\Component\Security\Http\Event\InteractiveLoginEvent($request, $token);
                    $eventDispatcher->dispatch("security.interactive_login", $event);

                    $event = new \YPKY\UserBundle\Event\UserUpdateEvent();
                    $event->setUser($user);
                    $eventDispatcher->dispatch('user.update.info', $event);
                    $eventDispatcher->dispatch('user.update.password', $event);
                    
                    $repository->delete($userToken);

                    return new RedirectResponse($this->generateUrl('admin_homepage'));
                }
            }

        $data = array(
            'form'=> $form->createView(),
            'selectedTab' => ''
        );

        return $this->render('AdminBundle:User:confirmEmail.html.twig', $data);
    }

    private function createAddForm(AdminUser $entity)
    {
        $form = $this->createForm(new \YPKY\AdminBundle\Form\AdminUserType(), $entity, array(
            'method' => 'POST',
            'action' => $this->generateUrl('admin_process_user')
        ));

        $form->add('submit','submit', array('label' => 'Create'));

        return $form;
    }
}
