<?php
namespace YPKY\AdminBundle\Controller;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Chromedia\WidgetFormBuilderBundle\Form\WidgetBuilderFormType;
use YPKY\ProductBundle\Entity\QuestionTemplate;
use YPKY\ProductBundle\Form\QuestionTemplateType;
class SampleFormController extends Controller
{
    public function indexAction(Request $request)
    {
        $questionTemplate = new QuestionTemplate();

        $metadata = array(
        	'widget_id' => 'choice',
            'widget_choices' => array(
                'My Choice'
            ),
            'widget_attribute' => array(
                array(
                    'key' => 'The Key',
                    'value' => 'The Value'
                )
            )
        );
        $questionTemplate->setWidgetMetadata(json_encode($metadata));

        $form = $this->createForm(new QuestionTemplateType(), $questionTemplate);

        if ($request->isMethod('POST')) {
            $form->submit($request);
            if ($form->isValid()) {
            	var_dump($form->getData());
            	exit;
            }
            else {
                var_dump($form->getErrors());
                exit;
            }
        }

        return $this->render('AdminBundle:SampleForm:index.html.twig', array(
        	'form' => $form->createView()
        ));
    }
}