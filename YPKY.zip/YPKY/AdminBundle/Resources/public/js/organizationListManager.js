var organizationListManager = {

    confirmDeleteModal: null,
    deleteButton: null,
    deleteForm: null,

    init: function() {
        this.confirmDeleteModal = $('#confirmDeleteOrganization');
        this.deleteButton = this.confirmDeleteModal.find('#btn-delete');

        this.bindEvents();
    },

    // Bind events
    bindEvents: function() {
        var self = this;

        self.confirmDeleteModal.on('shown.bs.modal', function(e){
            var orgId = $(e.relatedTarget).data('id');
            self.deleteForm = $('#delete-org-form-' + orgId);
            self.deleteButton.prop('disabled', false);
        });

        self.deleteButton.click(function() {
            $(this).prop('disabled', true);
            self.deleteForm.submit();
        });
    },
};


organizationListManager.init();