(function($){
    $.fn.tinymce = function(options){
        var settings = $.extend({
            selector: this.attr('id'),
            plugins: [
                "advlist autolink lists link charmap preview anchor",
                "searchreplace wordcount visualblocks code",
                "insertdatetime table contextmenu paste"
            ],
            toolbar: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link",
            width: 600,
            height: 200
        }, options);

        tinymce.init(settings)
    };
})(jQuery);