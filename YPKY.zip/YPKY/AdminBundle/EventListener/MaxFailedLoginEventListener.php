<?php

namespace YPKY\AdminBundle\EventListener;

use Doctrine\ORM\EntityManager;

use YPKY\AdminBundle\Event\MaxFailedLoginEvent;
use YPKY\AdminBundle\Classes\AdminUserConstants;

/**
 * class that "listens" if the max required failed login is invoked.
 * 
 * @author Farly Taboada
 */
class MaxFailedLoginEventListener
{
    private $entityManager;

    public function __construct(EntityManager $entityManager)
    {
        $this->entityManager = $entityManager;
    }


    /**
     * invoked when the maximum failed login is achieved. 
     * will suspend the user
     * @param  MaxFailedLoginEvent $event 
     */
    public function onMaxFailedLoginSuspend(MaxFailedLoginEvent $event)
    {
        $email = $event->getEmail();

        $user = $this->entityManager->getRepository('UserBundle:User')->findOneBy(array('email' => $email));

        $user->setStatus(AdminUserConstants::SUSPENDED);
        $this->entityManager->persist($user);
        $this->entityManager->flush();
    }

    /**
     * invoke when the maximum failed login is achieved.
     * will notify the super admin
     * @param  MaxFailedLoginEvent $event 
     */
    public function onMaxFailedLoginNotify(MaxFailedLoginEvent $event)
    {

    }
}