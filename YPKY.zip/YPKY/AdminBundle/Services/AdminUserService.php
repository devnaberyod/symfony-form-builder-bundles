<?php


namespace YPKY\AdminBundle\Services;

use YPKY\AdminBundle\Entity\AdminUser;
use YPKY\UserBundle\Services\UserService;
use Doctrine\Bundle\DoctrineBundle\Registry;

class AdminUserService
{
    private $doctrine;

    private $userService;


    public function setDoctrine(Registry $registry)
    {
        $this->doctrine = $registry;

        return $this;
    }


    public function setUserService(UserService $service)
    {
        $this->userService = $service;

        return $this;
    }


    public function setUser(AdminUser $adminUser)
    {
        $this->adminUser = $adminUser;
        
        $this->userService->setUser($adminUser->getUser());

        return $this;
    }

    public function setPassword($password)
    {
        $this->userService->setPassword($password);

        return $this;
    }

    public function setSalt($salt)
    {
        $this->userService->setSalt($salt);

        return $this;
    }

    public function setStatus($status)
    {
        $this->userService->setStatus($status);

        return $this;
    }

    public function save()
    {
        $user = $this->userService->getUser();

        $em = $this->doctrine->getManager();
        $em->persist($user);
        $em->flush();

        $this->adminUser->setUser($user);

        $em->persist($this->adminUser);
        $em->flush();

        return $this->adminUser;
    }
}