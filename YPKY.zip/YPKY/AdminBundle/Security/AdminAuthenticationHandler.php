<?php

namespace YPKY\AdminBundle\Security;

use Symfony\Component\Security\Http\Authentication\AuthenticationSuccessHandlerInterface;
use Symfony\Component\Security\Http\Authentication\AuthenticationFailureHandlerInterface;
use Symfony\Component\Security\Core\Exception\AuthenticationException;
use Symfony\Component\Security\Core\Authentication\Token\TokenInterface;
use Symfony\Component\Security\Core\SecurityContext;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\Routing\Router;
use YPKY\HelperBundle\Service\UserTokenizerService;

/**
 * Class that handles successful on failed login
 *
 * @author Farly Taboada
 * 
 * @todo  improve this
 */
class AdminAuthenticationHandler implements AuthenticationSuccessHandlerInterface
{

    private $router;


    private $doctrine;

    public function setRouter(Router $router)
    {
        $this->router = $router;
    }

    public function setUserTokenizerService(UserTokenizerService $userTokenizerService)
    {
        $this->userTokenizerService = $userTokenizerService;

        return $this;
    }

    public function onAuthenticationSuccess(Request $request, TokenInterface $token)
    {    
        $session = $request->getSession();
        // executes on successful login
        if ($session->has('failed_login')) {
            $session->remove('failed_login');
        }

        if ($token->getUser() instanceof \Symfony\Component\Security\Core\User\User) {
            $accessToken = $this->userTokenizerService->generateUserToken();
            $accessKey = NULL;
        } else {
            $accessToken = $this->userTokenizerService->generateUserToken($token->getUser()->getUser(), 1);
            $accessKey =  $accessToken->getUser()->getId();
        }

        $this->userTokenizerService->save($accessToken);
        $session->set('access_key', $accessKey);
        $session->set('access_token', $accessToken->getToken());

        return new RedirectResponse($this->router->generate('admin_homepage'));
    }

    // public function onAuthenticationFailure(Request $request, AuthenticationException $exception)
    // {
    //     $session = $request->getSession();

    //     if (!$session->has('failed_login')) {
    //         $session->set('failed_login', array('count' =>1, 'email' => $request->get('_username')));
    //     } else {
    //         $parameters = $session->get('failed_login');

    //         if ($parameters['email'] !== $request->get('_username')) {
    //             $session->set('failed_login', array('count' =>1, 'email' => $request->get('_username')));
    //         } else {
    //             $parameters['count']++;    

    //             /**
    //              * use constant for 5
    //              * 
    //              * 5 failed login will lock the account
    //              */
    //             if ($parameters['count'] >= 5) {
                    
    //                 $session->remove('failed_login');
    //                 // dispatch event for locking
    //                 // dispatch event for notifying super admin
                    
    //             } else {
    //                 $session->set('failed_login', $parameters);    
    //             }
    //         }
    //     }

    //     return new Response(null);
    // }
}
