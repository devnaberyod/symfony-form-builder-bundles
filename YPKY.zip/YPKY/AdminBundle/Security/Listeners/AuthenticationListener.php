<?php


namespace YPKY\AdminBundle\Security\Listeners;
 
use Symfony\Component\Security\Core\Event\AuthenticationFailureEvent;
use Symfony\Component\Security\Http\Event\InteractiveLoginEvent;

use YPKY\AdminBundle\Event\MaxFailedLoginEvent; 

class AuthenticationListener
{
    /**
     * onAuthenticationFailure
     *
     * @author    Farly Taboada
     * @param     AuthenticationFailureEvent $event
     */
    public function onAuthenticationFailure( AuthenticationFailureEvent $event )
    {
        // executes on failed login
        
        if (strpos($event->getAuthenticationToken()->getProviderKey(), "admin") === false ) {
            return;
        }

        $request = $event->getDispatcher()->getContainer()->get('request');
        $session = $request->getSession();

        if (!$session->has('failed_login')) {
            $session->set('failed_login', array('count' =>1, 'email' => $request->get('_username')));
        } else {
            $parameters = $session->get('failed_login');

            if ($parameters['email'] !== $request->get('_username')) {
                $session->set('failed_login', array('count' =>1, 'email' => $request->get('_username')));
            } else {
                $parameters['count']++;    

                /**
                 * use constant for 5
                 * 
                 * 5 failed login will lock the account
                 */
                if ($parameters['count'] >= 5) {

                    $session->remove('failed_login');

                    $dispatcher = $event->getDispatcher();
                    $dispatcher->dispatch('admin.max_failed_login', new MaxFailedLoginEvent($parameters['email']));
                    // dispatch event for locking
                    // dispatch event for notifying super admin
                    
                } else {
                    $session->set('failed_login', $parameters);    
                }
            }
        }
    }
 
    /**
     * onAuthenticationSuccess
     *
     * @author    Farly Taboada
     * @param     InteractiveLoginEvent $event
     */
    public function onAuthenticationSuccess( InteractiveLoginEvent $event )
    {
        if (strpos($event->getAuthenticationToken()->getProviderKey(), "admin") === false ) {
            return;
        }

        $request = $event->getRequest();
        $session = $request->getSession();
        // executes on successful login
        if ($session->has('failed_login')) {
            $session->remove('failed_login');
        }
    }
}