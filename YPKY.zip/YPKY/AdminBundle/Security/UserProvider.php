<?php


namespace YPKY\AdminBundle\Security;

use Symfony\Component\Security\Core\User\UserProviderInterface;
use Symfony\Component\Security\Core\User\UserInterface;
use Symfony\Component\Security\Core\Exception\BadCredentialsException;
use Symfony\Component\Security\Core\Exception\UsernameNotFoundException;
use Symfony\Component\Security\Core\Exception\UnsupportedUserException;

use Doctrine\ORM\EntityManager;
use YPKY\UserBundle\Security\User;
use YPKY\AdminBundle\Classes\AdminUserConstants;

class UserProvider implements UserProviderInterface
{

    private $entityManager;

    public function __construct(EntityManager $entityManager)
    {
        $this->entityManager = $entityManager;
    }

    public function loadUserByUsername($username)
    {

        $user = $this->entityManager->getRepository('UserBundle:User')->findOneByEmail($username);

        /**
         * @todo  improve this
         */
        $adminUser = $this->entityManager->getRepository('AdminBundle:AdminUser')->findOneByUser($user);

        if (!is_null($user) && !is_null($adminUser)) { 

            if ($user->getStatus() === AdminUserConstants::SUSPENDED) {
                throw new BadCredentialsException("Account is suspended");
            }

            return new User($user, $user->getSalt(), AdminUserConstants::$ROLE[$adminUser->getType()]);
        } 

        throw new UsernameNotFoundException(
            sprintf('Email "%s" does not exist.', $username)
        );
    }

    public function refreshUser(UserInterface $user)
    {
        if (!$user instanceof User) {
            throw new UnsupportedUserException(
                sprintf('Instances of "%s" are not supported.', get_class($user))
            );
        }

        return $this->loadUserByUsername($user->getUsername());
    }

    public function supportsClass($class)
    {
        return $class === 'YPKY\MemberBundle\Security\User';
    }
}

