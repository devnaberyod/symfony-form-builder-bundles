<?php

namespace YPKY\AdminBundle\Event;

use Symfony\Component\EventDispatcher\Event;

/**
 * 
 * @author Farly Taboada 
 */
class MaxFailedLoginEvent extends Event
{

    private $email;

    public function __construct($email)
    {
        $this->email = $email;
    }

    public function getEmail()
    {
        return $this->email;
    }
}