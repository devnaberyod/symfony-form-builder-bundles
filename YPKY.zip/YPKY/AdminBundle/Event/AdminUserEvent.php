<?php


namespace YPKY\AdminBundle\Event;

use YPKY\UserBundle\Event\UserEvent;


class AdminUserEvent extends UserEvent
{

    private $password;

    public function setPassword($password)
    {
        $this->password = $password;

        return $this;
    }

    public function getPassword()
    {
        return $this->password;
    }
}