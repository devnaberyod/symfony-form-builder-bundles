<?php
namespace YPKY\AdminBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;
use YPKY\AdminBundle\Form\Transformer\StateTransformer;

class StateFieldType extends AbstractType
{
    private $em;

    public function __construct($em)
    {
        $this->em = $em;
    }
    
    public function getName()
    {
        return 'ypky_admin_stateChoice';
    }

    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $transformer = new StateTransformer($this->em);
        $builder->addModelTransformer($transformer);
    }

    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(array(
        	'class' => 'YPKY\AdminBundle\Entity\State',
            'property' => 'name'
        ));
    }

    public function getParent()
    {
        return 'entity';
    }
}