<?php 

namespace YPKY\AdminBundle\Form\Transformer;

use Symfony\Component\Form\DataTransformerInterface;
use Symfony\Component\Form\Exception\TransformationFailedException;
use Doctrine\Common\Persistence\ObjectManager;
use YPKY\AdminBundle\Entity\State;
use Symfony\Component\Security\Core\SecurityContextInterface;

class StateTransformer implements DataTransformerInterface
{
    /**
     * @var ObjectManager
     */
    private $om;

    /**
     * @param ObjectManager $om
     */
    public function __construct(ObjectManager $om)
    {
        $this->om = $om;
    }

    /**
     * Transforms an object (State) to a string (name).
     *
     * @param  State|null $state
     * @return string
     */
    public function transform($state)
    {
        if (null === $state) {
            return "";
        }
        // var_dump('transform:');
        // var_dump($state);
        $state = $this->om->getRepository('AdminBundle:State')->find($state);

        //var_dump('state after query:');
        //var_dump($state);
        return $state;
    }

    /**
     * Transforms a string (id) to an object (state).
     *
     * @param  string|State $state
     *
     * @return State|null
     *
     * @throws TransformationFailedException if object (state) is not found.
     */
    public function reverseTransform($state)
    {
        if (!$state) {
            return null;
        }

        if(!is_object($state)) {
            $id = $state;
            $state = $this->om->getRepository('AdminBundle:State')->find($id);
            if (!$state) {
                throw new TransformationFailedException(sprintf( 'An state with id "%s" does not exist!', $id));
            }
        }

        return $state->getId();

        /*

        if (null === $id) {
            throw new TransformationFailedException(sprintf( 'An state with id "%s" does not exist!', $id));
        }
        
        $state = $this->om->getRepository('AdminBundle:State')->find($id);

        return $state;
        */
    }
}
