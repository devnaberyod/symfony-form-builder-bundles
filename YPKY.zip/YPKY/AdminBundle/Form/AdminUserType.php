<?php

namespace YPKY\AdminBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;

use YPKY\UserBundle\Form\UserType;
use YPKY\AdminBundle\Classes\AdminUserConstants;

class AdminUserType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('user', new UserType(false))
            ->add('title', 'text', array('required' => false))
            ->add('first_name', 'text', array('required' => false))
            ->add('last_name', 'text', array('required' => false))
            ->add('phone_number','text', array('required' => false))
            ->add('type', 'choice', array(
                'choices' => AdminUserConstants::$TYPE
            ))
        ;
    }

    
    /**
     * @param OptionsResolverInterface $resolver
     */
    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'YPKY\AdminBundle\Entity\AdminUser',
            'cascade_validation' => true,
        ));
    }



    /**
     * @return string
     */
    public function getName()
    {
        return 'ypky_adminbundle_admin_user';
    }
}
