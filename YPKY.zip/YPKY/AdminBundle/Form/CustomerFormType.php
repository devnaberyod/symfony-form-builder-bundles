<?php

namespace YPKY\AdminBundle\Form;

use Doctrine\ORM\EntityRepository;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Validator\Constraints\NotBlank;
use Symfony\Component\Validator\Constraints\Email;
use Symfony\Component\Validator\Constraints\Count;

use YPKY\ProductBundle\Entity\Form;
class CustomerFormType extends AbstractType
{
    const NAME = 'memberForm';

    public function getName()
    {
        return self::NAME;
    }

    public function buildForm(FormBuilderInterface $builder, array $options = array())
    {
        $builder->add('email', 'email', array(
            'label' => 'Email *',
            'required' => true,
            'constraints' => array(
                new NotBlank(array('message' => 'Email is required')), 
                new Email(array('message' => 'Invalid email format'))
            ),
            'attr' => array('placeholder' => 'Email Address'),
            'error_bubbling' => false,
        ));

        $builder->add('firstName', null, array(
            'label' => 'First Name *',
            'required' => true,
            'constraints' => array(new NotBlank(array('message' => 'First Name is required'))),
            'attr' => array('placeholder' => 'First Name'),
            'error_bubbling' => false,
        ));
        $builder->add('lastName', null, array(
            'label' => 'Last Name *',
            'required' => true,
            'constraints' => array(new NotBlank(array('message' => 'Last Name is required'))),
            'attr' => array('placeholder' => 'First Name'),
            'error_bubbling' => false,
        ));
        
        $builder->add('forms', 'entity', 
            array(
                'multiple' => true,
                'expanded' => true,
                'label' => 'Select the forms to be activated for this account',
                'class' => 'ProductBundle:Form',
                //'constraints' => array(new Count(array('min' => 1, 'minMessage' => 'At least one(1) form is required.'))),
                'error_bubbling' => false,
                'query_builder' => function(EntityRepository $er) {
                    $qb = $er->createQueryBuilder('f');
                    $qb->where('f.status = :status')
                    ->andWhere($qb->expr()->notIn('f.id', array(1, 2)))
                    ->orderBy('f.name', 'ASC')
                    ->setParameter('status', Form::STATUS_ACTIVE);

                    return $qb;
                }
            )
        );

        $builder->add('sendInvite', 'checkbox', array('required' => false, 'label' => 'Do you want to send an invite email to the customer at the address address above? '));
    }
}
