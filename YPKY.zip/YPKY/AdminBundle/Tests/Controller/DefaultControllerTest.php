<?php

namespace YPKY\AdminBundle\Tests\Controller;

use YPKY\HelperBundle\Test\WebTestCase;
class DefaultControllerTest extends WebTestCase
{


    public function testAdminSession()
    {
        $this->loadFixtures(array(
        	'YPKY\UserBundle\DataFixtures\AdminUserData'
        ));

        $response = $this->sendGetRequest($this->getUrl('admin_default_adminSession'));
        var_dump($response); exit;
    }
}
