<?php 

namespace YPKY\AdminBundle\Classes;

class SearchConstant
{

    const MEMBER_SEARCH_PLACEHOLDER = 'Type Org/Member Name or Email Address';
    const MEMBER_SEARCH_ORG_PLACEHOLDER = 'Type Org/Member Name';
    const MAIN_TAB = 'member';
    const SUB_TAB_PEOPLE = 'people';
    const SUB_TAB_ORG = 'organization';

    //question template page
    const FORM_QUESTION_SEARCH_PLACEHOLDER = 'Question Name';
    const SELECTED_TAB_FORM_BUILDER = 'formBuilder';
    const FORM_BUILDER_TAB_QUESTION = 'questionLists';
    const FORM_BUILDER_TAB_FORM = 'formLists';

    //form page
    const FORM_SEARCH_PLACEHOLDER = 'Form Name';
}
