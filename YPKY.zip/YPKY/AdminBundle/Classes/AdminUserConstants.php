<?php


namespace YPKY\AdminBundle\Classes;

class AdminUserConstants extends \YPKY\UserBundle\Classes\UserConstants
{
    const TYPE_ADMIN = 1;

    const TYPE_SUPER_ADMIN = 2;

    public static  $ROLE = array(
        self::TYPE_ADMIN => array('ROLE_ADMIN'),
        self::TYPE_SUPER_ADMIN => array('ROLE_SUPER_ADMIN')
    );

    public static $TYPE = array(
        self::TYPE_ADMIN => 'YKY Admin',
        self::TYPE_SUPER_ADMIN => 'Site Admin'
    );
}