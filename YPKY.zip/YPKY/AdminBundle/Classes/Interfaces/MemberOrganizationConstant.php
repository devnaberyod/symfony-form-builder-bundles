<?php 

namespace YPKY\AdminBundle\Classes\Interfaces;

interface MemberOrganizationConstant
{

    //search
    const MEMBER_SEARCH_PLACEHOLDER = 'Type Org/Member Name or Email Address';
    const MEMBER_SEARCH_ORG_PLACEHOLDER = 'Type Org/Member Name';
    const MAIN_TAB = 'member';
    const SUB_TAB_PEOPLE = 'people';
    const SUB_TAB_ORG = 'organization';

    //delete
    const DELETE_ORG = 1;
    const DELETE_MEMBER = 1;
}
