<?php

namespace YPKY\HelperBundle\Event; 

use Symfony\Component\EventDispatcher\Event;

use YPKY\HelperBundle\Classes\Token;
use YPKY\HelperBundle\Classes\TokenInterface;
use YPKY\UserBundle\Entity\User;

/**
 * @author  Farly Taboada
 */
class RequestPasswordEvent extends Event implements TokenInterface
{
    private $token;

    public function setToken(Token $token)
    {
        $this->token = $token;

        return $this;
    }

    public function getToken()
    {
        return $this->token;
    }
}