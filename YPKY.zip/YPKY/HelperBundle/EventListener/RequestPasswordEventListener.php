<?php

namespace YPKY\HelperBundle\EventListener;

use YPKY\HelperBundle\Event\RequestPasswordEvent;
use Doctrine\Bundle\DoctrineBundle\Registry;

/**
 * @author  Farly Taboada
 */
class RequestPasswordEventListener
{

    public $doctrine;

    public function setDoctrine(Registry $registry)
    {
        $this->doctrine = $registry;
    }

    // public function setMailerSerivce()
    // {

    // }

    public function onRequestPasswordSaveToken(RequestPasswordEvent $event)
    {
        $token = $event->getToken();
        $this->doctrine->getRepository('UserBundle:UserAccessToken')->save($token);
    }


    public function onRequestPasswordNotify(RequestPasswordEvent $event)
    {
    }
}