<?php

namespace YPKY\HelperBundle\Security;

/**
 * @author  Farly Taboada
 */
interface YPKYUser
{
}