<?php

namespace YPKY\HelperBundle\Security;

use YPKY\HelperBundle\Security\YPKYUser;

/**
 * @author  Farly Taboada
 * @todo  This class's no longer being used. Please verify and remove.
 */
class User implements \Symfony\Component\Security\Core\User\UserInterface
{

    private $user;
    private $salt;
    private $roles;
    
    public function __construct(YPKYUser $user, $salt, $roles)
    {
        $this->user = $user;
        $this->salt = $salt;
        $this->roles = $roles;
    }

    public function getUsername()
    {
        return $this->user->getEmail();
    }

    public function getPassword()
    {
        return $this->user->getPassword();
    }

    public function getSalt()
    {
        return $this->salt;
    }

    public function getRoles()
    {
        return $this->roles;
    }

    public function getUser()
    {
        return $this->user; 
    }

    public function eraseCredentials()
    {
    }
}