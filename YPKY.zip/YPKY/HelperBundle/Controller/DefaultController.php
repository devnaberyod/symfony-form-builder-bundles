<?php

namespace YPKY\HelperBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

class DefaultController extends Controller
{

    public function javascriptUrlHelperAction()
    {
        $response = $this->render('HelperBundle:Default:urlHelper.js.twig');
        //$response->headers->set('content-type', 'application/octet-stream');
        //$response->headers->set('Content-Type','application/force-download');
        $response->headers->set('content-type', 'application/javascript');
        $response->headers->addCacheControlDirective('no-cache', true);
        $response->headers->addCacheControlDirective('no-store', true);
        return $response;
    }

    /**
     * @author  Farly
     * @todo  Please improve this. and move this action to proper class
     */
    public function downloadFileAction(Request $request)
    {
        $filename = $request->get('file');

        /**
         * @todo  improve this
         */
        //$path = $request->getUriForPath(DIRECTORY_SEPARATOR. $this->container->getParameter('form_builder.file.upload_path'). DIRECTORY_SEPARATOR. $filename);
        $path = $this->get('kernel')->getRootDir() . '/../web'.DIRECTORY_SEPARATOR. $this->container->getParameter('form_builder.file.upload_path'). DIRECTORY_SEPARATOR. $filename;

        $content = file_get_contents($path);
        
        $response = new Response();

        $response->headers->set('Content-Disposition', 'attachment; filename="'.$filename);

        $response->setContent($content);
        return $response;
    }
}
