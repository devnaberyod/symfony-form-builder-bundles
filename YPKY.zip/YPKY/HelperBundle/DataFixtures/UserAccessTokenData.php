<?php
namespace YPKY\HelperBundle\DataFixtures;

use Doctrine\Common\DataFixtures\AbstractFixture;
use Doctrine\Common\DataFixtures\DependentFixtureInterface;
use Doctrine\Common\Persistence\ObjectManager;
use YPKY\HelperBundle\Service\UserTokenizerService;
use YPKY\UserBundle\Entity\UserAccessToken;
class UserAccessTokenData extends AbstractFixture implements DependentFixtureInterface
{
    public function getDependencies()
    {
        return array(
            'YPKY\UserBundle\DataFixtures\AdminUserData'
        );
    }

    public function load(ObjectManager $manager)
    {
        $token = new UserAccessToken();
        $token->setUser($this->getReference('UserBundle:User-AdminUser'));

        $expiration = new \DateTime('now');
        date_add($expiration, \date_interval_create_from_date_string('30 days'));
        $token->setExpiration($expiration);

        $token->setToken('4d04a14a853177950b43d3aa5d646d4e');

        $manager->persist($token);
        $manager->flush();

        $this->addReference('UserBundle:UserAccessToken', $token);
    }
}