<?php
namespace YPKY\HelperBundle\Test;

use Symfony\Bundle\FrameworkBundle\Test\WebTestCase as BaseWebTestCase;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\BrowserKit\Cookie;
use Symfony\Component\HttpFoundation\Session\Session;
use Symfony\Component\DomCrawler\Crawler;
use Symfony\Bridge\Doctrine\DataFixtures\ContainerAwareLoader as DataFixturesLoader;
use Doctrine\Common\Persistence\ManagerRegistry;
use Doctrine\Common\DataFixtures\DependentFixtureInterface;
use Doctrine\Common\DataFixtures\Executor\ORMExecutor;
use Doctrine\Common\DataFixtures\Purger\ORMPurger;
use Doctrine\Common\DataFixtures\ProxyReferenceRepository;
use	Doctrine\Common\DataFixtures\Loader;
use Doctrine\Bundle\FixturesBundle\Common\DataFixtures\Loader as DoctrineFixturesLoader;
use Symfony\Bundle\FrameworkBundle\Client;

/**
 * Adds commonly used convenience functions to symfony's WebTestCase using
 * doctrine fixtures
 *
 * NOTE than on the extending test classes comparisons to entity ids will only
 * work if purger uses TRUNCATE mode when emptying tables. The ORMPurger class
 * has been edited to turn off foreigh key checks for truncate command to work
 * properly. Other versions of mysql will not need this hack [provide link].
 *
 * Please apply the hack to doctrine fixture's ORMPurger class accordingly:
 * Look for the foreach loop below and add the if blocks
 *
 *       // My modifications HAM31Oct2013
 *       // THIS IS A HACK! Look for a more long term solution
        if (self::PURGE_MODE_TRUNCATE == $this->purgeMode) {
            $this->em->getConnection()->executeUpdate("SET foreign_key_checks = 0;");
        }
 *
 *       foreach($orderedTables as $tbl) {
 *           if ($this->purgeMode === self::PURGE_MODE_DELETE) {
 *               $this->em->getConnection()->executeUpdate("DELETE FROM " . $tbl);
 *           } else {
 *               $this->em->getConnection()->executeUpdate($platform->getTruncateTableSQL($tbl, true));
 *           }
 *       }
 *
 *       // My modifications HAM31Oct2013
 *       // THIS IS A HACK! Look for a more long term solution
 *       if (self::PURGE_MODE_TRUNCATE == $this->purgeMode) {
 *           $this->em->getConnection()->executeUpdate("SET foreign_key_checks = 1;");
 *       }
 *
 * @author Harold Modesto <harold.modesto@chromedia.com>
 *
 */
abstract class WebTestCase extends BaseWebTestCase
{
    protected $environment = 'test';
    protected $containers;
    protected $kernelDir;
    // 5 * 1024 * 1024 KB
    protected $maxMemory = 5242880;
    protected $client = null;

    /**
     * @var array
     */
    private $mockServices = array();

    /**
     * @var array
     */
    private $firewallLogins = array();


    /**
     * Overridden to avoid using the Finder object.
     *
     * @return string
     */
    static protected function getKernelClass()
    {
        $dir = isset($_SERVER['KERNEL_DIR']) ? $_SERVER['KERNEL_DIR'] : self::getPhpUnitXmlDir();
        list($appname) = explode('\\', get_called_class());

        $class = $appname . 'Kernel';
        $file = $dir . '/' . strtolower($appname) . '/' . $class . '.php';
        if (!file_exists($file)) {
            return parent::getKernelClass();
        }
        require_once $file;

        return $class;
    }

    /**
     * Creates a mock object builder of a symfony service identified by its id.
     *
     * TODO: this currently cannot handle aliases or aliases to private services
     *
     * @param string $id
     * @return PHPUnit_Framework_MockObject_MockBuilder
     */
    protected function getServiceMockBuilder($id, $disableOriginalConstrucor = true)
    {
        $mockbuilder = $this->getMockBuilder(get_class($this->getContainer()->get($id)));

        if ($disableOriginalConstrucor) {
            $mockbuilder->disableOriginalConstructor();
        }

        return $mockbuilder;
    }

    /**
     * Builds up the environment to run the given command.
     *
     * @param string $name
     * @param array $params
     *
     * @return string
     */
    protected function runCommand($name, array $params = array())
    {
        array_unshift($params, $name);

        $kernel = $this->createKernel(array('environment' => $this->environment));
        $kernel->boot();

        $application = new Application($kernel);
        $application->setAutoExit(false);

        $input = new ArrayInput($params);
        $input->setInteractive(false);

        $fp = fopen('php://temp/maxmemory:'.$this->maxMemory, 'r+');
        $output = new StreamOutput($fp);

        $application->run($input, $output);

        rewind($fp);

        return stream_get_contents($fp);
    }

    /**
     * Get an instance of the dependency injection container.
     * (this creates a kernel *without* parameters).
     *
     * @return ContainerInterface
     */
    protected function getContainer()
    {
        if (!empty($this->kernelDir)) {
            $tmpKernelDir = isset($_SERVER['KERNEL_DIR']) ? $_SERVER['KERNEL_DIR'] : null;
            $_SERVER['KERNEL_DIR'] = getcwd() . $this->kernelDir;
        }

        $cacheKey = $this->kernelDir . '|' . $this->environment;
        if (empty($this->containers[$cacheKey])) {
            $options = array('environment' => $this->environment);
            $kernel = $this->createKernel($options);
            $kernel->boot();

            $this->containers[$cacheKey] = $kernel->getContainer();
        }

        if (isset($tmpKernelDir)) {
            $_SERVER['KERNEL_DIR'] = $tmpKernelDir;
        }

        return $this->containers[$cacheKey];
    }

    /**
     * Set the database to the provided fixtures.
     *
     * Drops the current database and then loads fixtures using the specified
     * classes. The parameter is a list of fully qualified class names of
     * classes that implement Doctrine\Common\DataFixtures\FixtureInterface
     * so that they can be loaded by the DataFixtures Loader::addFixture
     *
     * Depends on the doctrine data-fixtures library being available in the
     * class path.
     *
     * @param array $classNames List of fully qualified class names of fixtures to load
     * @param string $omName The name of object manager to use
     * @param string $registryName The service id of manager registry to use
     * @param int $purgeMode Sets the ORM purge mode
     *
     * @return null|Doctrine\Common\DataFixtures\Executor\AbstractExecutor
     */

    protected function loadFixtures(array $classNames, $omName = 'default', $registryName = 'doctrine', $purgeMode = null)
    {
        $container = $this->getContainer();

        $registry = $container->get($registryName);
        if ($registry instanceof ManagerRegistry) {
            $om = $registry->getManager($omName);
            $type = $registry->getName();
        } else {
            $om = $registry->getEntityManager($omName);
            $type = 'ORM';
        }

        $cacheDriver = $om->getMetadataFactory()->getCacheDriver();
        if ($cacheDriver) {
            $cacheDriver->deleteAll();
        }

        $purgerClass = 'Doctrine\\Common\\DataFixtures\\Purger\\'.$type.'Purger';
        $purger = new $purgerClass();
        if ('ORM' == $type) {
            $purger->setPurgeMode(is_null($purgeMode) ? ORMPurger::PURGE_MODE_TRUNCATE : $purgeMode);
        }

        $executorClass = 'Doctrine\\Common\\DataFixtures\\Executor\\'.$type.'Executor';
        $executor = new $executorClass($om, $purger);
        $executor->setReferenceRepository(new ProxyReferenceRepository($om));
        $executor->purge();

        $loader = $this->getFixtureLoader($container, $classNames);
        $executor->execute($loader->getFixtures(), true);

        return $executor;
    }

    /**
     * Shortcut for odm fixtures
     *
     * @param array $classNames
     * @param string $omName
     * @param string $registryName
     * @param string $purgeMode
     * @throws \InvalidArgumentException
     * @return Ambigous <NULL, \Doctrine\Common\DataFixtures\Executor\AbstractExecutor, \Doctrine\Common\DataFixtures\Executor\ORMExecutor>|unknown
     */
    protected function loadOdmFixtures(array $classNames, $omName = "default", $registryName = 'doctrine_mongodb')
    {
        return $this->loadFixtures($classNames, $omName, $registryName);
    }

    /**
     * Retrieve Doctrine DataFixtures loader.
     *
     * @param ContainerInterface $container
     * @param array $classNames
     *
     * @return \Symfony\Bundle\DoctrineFixturesBundle\Common\DataFixtures\Loader
     */
    protected function getFixtureLoader(ContainerInterface $container, array $classNames)
    {
        $loader = class_exists('Symfony\Bridge\Doctrine\DataFixtures\ContainerAwareLoader')
            ? new DataFixturesLoader($container)
            : (class_exists('Doctrine\Bundle\FixturesBundle\Common\DataFixtures\Loader')
                ? new DoctrineFixturesLoader($container)
                : new SymfonyFixturesLoader($container));

        foreach ($classNames as $className) {
            $this->loadFixtureClass($loader, $className);
        }

        return $loader;
    }

    /**
     * Load a data fixture class.
     *
     * @param \Symfony\Bundle\DoctrineFixturesBundle\Common\DataFixtures\Loader $loader
     * @param string $className
     */
    protected function loadFixtureClass($loader, $className)
    {
        $fixture = new $className();

        if ($loader->hasFixture($fixture)) {
            unset($fixture);
            return;
        }

        $loader->addFixture($fixture);

        if ($fixture instanceof DependentFixtureInterface) {
            foreach ($fixture->getDependencies() as $dependency) {
                $this->loadFixtureClass($loader, $dependency);
            }
        }
    }

    /**
     * Creates an instance of a lightweight Http client.
     *
     * If $authentication is set to 'true' it will use the content of
     * 'functional_test.authentication' to log in. Can also pass an array
     * with 'username' and 'password' keys.
     *
     * $params can be used to pass headers to the client, note that they have
     * to follow the naming format used in $_SERVER.
     * Example: 'HTTP_X_REQUESTED_WITH' instead of 'X-Requested-With'
     *
     * @param mixed $authentication
     * @param array   $params
     *
     * @return Client
     */
    protected function makeClient($authentication = false, array $params = array())
    {
        // instance already added probably in client testcase
        if ($this->client && $this->client instanceof Client) {
            return $this->client;
        }

        if ($authentication) {
            if ($authentication === true) {
                $authentication = $this->getContainer()->getParameter('functional_test');
                $authentication = $authentication['authentication'];
            }

            $params = array_merge($params, array('PHP_AUTH_USER' => $authentication['username'], 'PHP_AUTH_PW' => $authentication['password']));
        }

        $client = static::createClient(array('environment' => $this->environment), $params);

        foreach($this->mockServices as $key => $value) {
            $client->getContainer()->set($key, $value);
        }

        if ($this->firewallLogins) {
            // has to be set otherwise "hasPreviousSession" in Request returns false.
            $options = $client->getContainer()->getParameter('session.storage.options');

            if (!$options || !isset($options['name'])) {
                throw new \InvalidArgumentException("Missing session.storage.options#name");
            }

            $session = $client->getContainer()->get('session');
            // Since the namespace of the session changed in symfony 2.1, instanceof can be used to check the version.
            if ($session instanceof Session) {
                $session->setId(uniqid());
            }

            $client->getCookieJar()->set(new Cookie($options['name'], $session->getId()));

            /** @var $user UserInterface */
            foreach ($this->firewallLogins as $firewallName => $user) {
                $token = new UsernamePasswordToken($user, null, $firewallName, $user->getRoles());

                $client->getContainer()->get('security.context')->setToken($token);
                $session->set('_security_' . $firewallName, serialize($token));
            }

            $session->save();
        }

        return $client;
    }

    /**
     * Extracts the location from the given route.
     *
     * @param string $route  The name of the route
     * @param array $params  Set of parameters
     * @param boolean $absolute
     *
     * @return string
     */
    protected function getUrl($route, $params = array(), $absolute = false)
    {
        return $this->getContainer()->get('router')->generate($route, $params, $absolute);
    }

    /**
     * Checks the success state of a response
     *
     * @param Response $response Response object
     * @param bool $success to define whether the response is expected to be successful
     * @param string $type
     *
     * @return void
     */
    public function isSuccessful($response, $success = true, $type = 'text/html')
    {
        try {
            $crawler = new Crawler();
            $crawler->addContent($response->getContent(), $type);
            if (!count($crawler->filter('title'))) {
                $title = '[' . $response->getStatusCode() . '] - ' . $response->getContent();
            } else {
                $title = $crawler->filter('title')->text();
            }
        } catch (\Exception $e) {
            $title = $e->getMessage();
        }

        if ($success) {
            $this->assertTrue($response->isSuccessful(), 'The Response was not successful: ' . $title);
        } else {
            $this->assertFalse($response->isSuccessful(), 'The Response was successful: ' . $title);
        }
    }

    /**
     * Executes a request on the given url and returns the response contents.
     *
     * @param string $path path of the requested page
     * @param string $method The HTTP method to use, defaults to GET
     * @param bool $authentication Whether to use authentication, defaults to false
     * @param int $statusCode to define whether the response is expected to be successful
     * @param array $clientRequestArguments
     * @return string
     */
    public function fetchContent($path, $method = 'GET', $authentication = false, $statusCode = 200, $clientRequestArguments=array())
    {
//         $client = $this->makeClient($authentication);
//         $client->request($method, $path);
//         $content = $client->getResponse()->getContent();
//         if (is_bool($success)) {
//             $this->isSuccessful($client->getResponse(), $success);
//         }

        $response = $this->sendRequest($path, $method, $authentication, $clientRequestArguments);

        $content = $response->getContent();
        $this->assertEquals($statusCode, $response->getStatusCode(), 'Expected status code is '.$statusCode);


        return $content;
    }

    /**
     * Executes a request on the given url and returns a Crawler object.
     *
     * @param string $path path of the requested page
     * @param string $method The HTTP method to use, defaults to GET
     * @param bool $authentication Whether to use authentication, defaults to false
     * @param int $statusCode Expected status code
     * @param array $clientRequestArguments
     * @return Crawler
     */
    public function fetchCrawler($path, $method = 'GET', $authentication = false, $statusCode=200, $clientRequestArguments = array())
    {
        $client = $this->makeClient($authentication);
        list($parameters, $files, $server, $content, $changeHistory) =
            $this->extractClientRequestArguments($clientRequestArguments);

        $crawler = $client->request($method, $path, $parameters, $files, $server, $content, $changeHistory);
        $this->assertEquals($statusCode, $client->getResponse()->getStatusCode());

        return $crawler;
    }

    /**
     * @param UserInterface $user
     *
     * @return WebTestCase
     */
    public function loginAs(UserInterface $user, $firewallName)
    {
        $this->firewallLogins[$firewallName] = $user;
        return $this;
    }

    /**
     * simulate login
     *
     * @author Farly Taboada
     */
    public function loginClient()
    {

        $em = $this->client->getContainer()->get('doctrine.orm.entity_manager');

        $user  = $em->find('UserBundle:User', 1);

        $this->assertNotNull($user, 'User not found');

        $authorizedUser = new \YPKY\UserBundle\Security\User($user, $user->getSalt(), array('ROLE_CLIENT'));

        $session = $this->client->getContainer()->get('session');

        $firewall = 'client_area';
        $token = new \Symfony\Component\Security\Core\Authentication\Token\UsernamePasswordToken($authorizedUser, $authorizedUser->getPassword(), $firewall, array('ROLE_CLIENT'));
        $session->set('_security_'.$firewall, serialize($token));
        $session->save();

        // $event = new \Symfony\Component\Security\Http\Event\InteractiveLoginEvent($request, $token);
        // $eventDispatcher->dispatch("security.interactive_login", $event);

        $cookie = new Cookie($session->getName(), $session->getId());
        $this->client->getCookieJar()->set($cookie);

        // $securityContext = $this->getContainer()->get('security.context');
        // $this->assertNotNull($securityContext->getToken());
        // $this->asseerNotNull($securityContext->getToken()->getUser());
        // $authorizedUser = new \YPKY\UserBundle\Security\User($user, $user->getSalt(), array('ROLE_CLIENT') );
        // $this->loginAs($authorizedUser, 'client_area');
    }

    /**
     * Asserts that the response contains valid json. Will also check the
     * statusCode and for the existence of a header with content type
     * 'application/json'.
     *
     * Return the json decoded array if json is valid and null otherwise.
     *
     * @param unknown $response
     * @param number $statusCode
     * @return array json_decoded response
     */
    public function assertJsonResponse($response, $statusCode = 200)
    {
        $this->assertEquals($statusCode, $response->getStatusCode(), "Failed asserting expected status code");

        $json = $response->getContent();
        $decoded = json_decode($json, true);
        $this->assertEquals(JSON_ERROR_NONE, json_last_error(), 'Invalid json');
        // assert expected status code

        $this->assertTrue($response->headers->contains('Content-Type', 'application/json'), $response->headers);

        return $decoded;
    }

    /**
     * Returns the json decoded content and indirectly makes assertions that
     *
     * 1. the response contains valid json,
     * 2. status code is equal to the provided code
     * 3. and that the header Content-Type is equal to application/json
     *
     * TODO: remove $authentication argument (?)
     *
     * @param string $path Url
     * @param string $method Method name
     * @param string $authentication Logs in using the credentials in functional_test.authentication
     * @param number $statusCode Expected status code
     * @param array $clientRequestArguments Additional arguments that can be passed to Symfony\Component\BrowserKit\Client::request() method
     *
     * @return array An array representing the json_decoded text
     */
    public function fetchJsonContent($path, $method = 'GET', $authentication = false, $statusCode = 200, $clientRequestArguments = array()) {

        $response = $this->sendRequest($path, $method, $authentication, $clientRequestArguments);

        return $this->assertJsonResponse($response, $statusCode);
    }


    /**
     *
     * @return Symfony\Component\HttpFoundation\Response
     */
    public function sendRequest($path, $method = 'GET', $authentication = false,  $clientRequestArguments = array())
    {
        $client = $this->makeClient($authentication);
        list($parameters, $files, $server, $content, $changeHistory) =
        $this->extractClientRequestArguments($clientRequestArguments);

        $client->request($method, $path, $parameters, $files, $server, $content, $changeHistory);

        return $client->getResponse();
    }

    /**
     *
     * @param unknown $path
     * @param unknown $clientRequestArguments
     * @param number $statusCode
     *
     * @return array json_decoded response
     */
    public function postWithJsonResponse($path, $clientRequestArguments=array(), $statusCode=200)
    {
        $response = $this->sendPostRequest($path, $clientRequestArguments);

        return $this->assertJsonResponse($response, $statusCode);
    }

    /**
     *
     * @param unknown $path
     * @param unknown $clientRequestArguments
     * @param number $statusCode
     * @return array json_decoded response
     */
    public function putWithJsonResponse($path, $clientRequestArguments=array(), $statusCode=200)
    {
        $response = $this->sendPutRequest($path, $clientRequestArguments);

        return $this->assertJsonResponse($response, $statusCode);
    }

    /**
     * Send PUT Request with expected JSON response
     *
     * @param string $path
     * @param array $clientRequestArguments
     * @param number $statusCode
     *
     * @return array json_decoded response
     */
    public function sendGetRequestWithJsonResponse($path, $clientRequestArguments=array(), $statusCode=200)
    {
        return $this->assertJsonResponse($this->sendGetRequest($path, $clientRequestArguments), $statusCode);
    }


    public function sendGetRequest($path, $clientRequestArguments=array())
    {
        $response = $this->sendRequest($path, 'GET', false, $clientRequestArguments);

        return $response;
    }

    /**
     *
     * @param string $path
     * @param array $clientRequestArguments
     * @param number $statusCode
     * @return Symfony\Component\HttpFoundation\Response
     */
    public function sendPostRequest($path, $clientRequestArguments=array())
    {
        $response = $this->sendRequest($path, 'POST', false, $clientRequestArguments);

        return $response;
    }

    public function sendPutRequest($path, $clientRequestArguments=array())
    {
        return $this->sendRequest($path, 'PUT', false, $clientRequestArguments);
    }

    public function sendDeleteRequest($path, $clientRequestArguments=array())
    {
        return $this->sendRequest($path, 'DELETE', false, $clientRequestArguments);
    }


    /**
     * Adds a mocked symfony service so they can be later injected into the
     * container replacing the actual service.
     *
     * @param string $id Service id
     * @param mixed $value The mock object
     */
    protected function addMockService($id, $mockService)
    {
        $this->mockServices[$id] = $mockService;
    }

    /**
     * See doc on addMockService
     *
     * @param array $mockServices Array of mocked services with service id as key and the mock object as the value
     */
    protected function setMockServices($mockServices = array())
    {
        $this->mockServices = $mockServices;
    }

    /**
     * TODO: monitor effects of teardown
     *
     * @see \Symfony\Bundle\FrameworkBundle\Test\WebTestCase::tearDown()
     */
    protected function tearDown()
    {
        // shuts down the kernel
        parent::tearDown();

        $refl = new \ReflectionObject($this);
        foreach ($refl->getProperties() as $prop) {
            if (!$prop->isStatic() && 0 !== strpos($prop->getDeclaringClass()->getName(), 'PHPUnit_')) {
                $prop->setAccessible(true);
                $prop->setValue($this, null);
            }
        }
    }

    /**
     * Extracts the additional arguments that can be passed to Symfony\Component\BrowserKit\Client::request() method
     *
     * @param array $clientRequestArguments
     * @return array
     */
    private function extractClientRequestArguments($clientRequestArguments = array())
    {
        return array(
            isset($clientRequestArguments['parameters']) ? $clientRequestArguments['parameters'] : array(),
            isset($clientRequestArguments['files']) ? $clientRequestArguments['files'] : array(),
            isset($clientRequestArguments['server']) ? $clientRequestArguments['server'] : array(),
            isset($clientRequestArguments['content']) ? $clientRequestArguments['content'] : null,
            isset($clientRequestArguments['changeHistory']) ? $clientRequestArguments['changeHistory'] : true);
    }
}
