<?php
namespace YPKY\HelperBundle\Test;

use YPKY\HelperBundle\Test\WebTestCase;

abstract class TokenAuthenticatedControllerWebTestCase extends WebTestCase
{
    public function sendRequest($path, $method = 'GET', $authentication = false,  $clientRequestArguments = array())
    {
        $accessKey = $this->getContainer()->getParameter('chromedia_security_token.access_key_request_parameter');
        $accessTokenKey = $this->getContainer()->getParameter('chromedia_security_token.access_token_request_parameter');
        $apiParameters = array(
            $accessKey => 1,
            $accessTokenKey => '4d04a14a853177950b43d3aa5d646d4e',
        );

        $headerKey = $this->getContainer()->getParameter('chromedia_security_token.authorization_header_key');
        $clientRequestArguments['server']['HTTP_'.$headerKey] = \base64_encode($apiParameters[$accessKey].':'.$apiParameters[$accessTokenKey]);

        return parent::sendRequest($path, $method, $authentication, $clientRequestArguments);
    }
}