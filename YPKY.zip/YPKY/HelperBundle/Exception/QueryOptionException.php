<?php
namespace YPKY\HelperBundle\Exception;

class QueryOptionException extends \Exception
{
    static public function invalidSortField($field)
    {
        return new self("Unable to add invalid sort field: {$field}");
    }
}