<?php
namespace YPKY\HelperBundle\Twig;

/**
 * @author  Farly Taboada
 * 
 * @todo  Please verify if it's still being used.. Remove if not..
 */
class ElementTwigExtension extends \Twig_Extension
{

    public function getName()
    {
        return 'ypky_element_twig_extension';
    }

    public function isElement($name)
    {
        return strpos($name, 'element') !== false;
    }

    public function getFilters()
    {
        return array(
            new \Twig_SimpleFilter('is_element', array($this, 'isElement'))
        );
    }
}