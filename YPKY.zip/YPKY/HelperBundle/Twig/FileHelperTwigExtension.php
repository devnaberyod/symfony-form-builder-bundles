<?php
namespace YPKY\HelperBundle\Twig;

use \Twig_Filter_Function;
use \Twig_Filter_Method;

class FileHelperTwigExtension extends \Twig_Extension
{
    public function getName()
    {
        return 'ypky_file_helper_twig_extension';
    }

    public function getFunctions()
    {
        return array(
            'file_exists' => new \Twig_Function_Function('file_exists')
        );
    }   

}
