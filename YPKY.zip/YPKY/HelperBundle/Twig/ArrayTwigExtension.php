<?php
namespace YPKY\HelperBundle\Twig;

class ArrayTwigExtension extends \Twig_Extension
{
    public function getName()
    {
        return 'ypky_array_twig_extension';
    }

    public function removeElementWithIndexInArray($array, $index)
    {
        if (isset($array[$index])) {
            unset($array[$index]);
        }

        return $array;
    }

    public function getFilters()
    {
        return array(
            new \Twig_SimpleFilter('remove_in_array', array($this, 'removeElementWithIndexInArray'))
        );
    }
}