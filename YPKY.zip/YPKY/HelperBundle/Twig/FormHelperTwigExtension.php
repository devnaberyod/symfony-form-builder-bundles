<?php
namespace YPKY\HelperBundle\Twig;

use YPKY\ProductBundle\Entity\Form;

class FormHelperTwigExtension extends \Twig_Extension
{
    public function getName()
    {
        return 'ypky_form_helper_twig_extension';
    }

    private static $formStatusLabels = array(
        Form::STATUS_DRAFT => 'Draft',
        Form::STATUS_ACTIVE => 'Active',
        Form::STATUS_INACTIVE => 'Inactive'
    );
    
    private static $formStatusLabelClasses = array(
        Form::STATUS_DRAFT => 'label-default',
        Form::STATUS_ACTIVE => 'label-success',
        Form::STATUS_INACTIVE => 'label-danger'
    );
    
    public function getFormStatusLabel($status)
    {
        return isset(self::$formStatusLabels[$status])
            ? self::$formStatusLabels[$status]
            : '';
    }
    
    public function getFormStatusLabelClass($status)
    {
        return isset(self::$formStatusLabelClasses[$status]) 
            ? self::$formStatusLabelClasses[$status]
            : '';
    }

    public function getFunctions()
    {
        return array(
            new \Twig_SimpleFunction('form_status_label', array($this, 'getFormStatusLabel')),
            new \Twig_SimpleFunction('form_status_label_class', array($this, 'getFormStatusLabelClass'))
        );
    }    
}
