<?php

namespace YPKY\HelperBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class HelperBundle extends Bundle
{
}
