<?php

namespace YPKY\HelperBundle\Service;


/** 
 * @author  Farly Taboada
 */
class PasswordGeneratorService
{

    /**
     * generates password "randomly"
     * @param  integer $length length of password
     * @return string          password generated
     * 
     * @todo  this is a very simple algorith please improve!
     */
    public function generate($length=8)
    {
        $string = md5(time().$length);

        $length = strlen($string) > $length ? $length : strlen($string);

        return substr($string, 0, $length);
    }
}