<?php

namespace YPKY\HelperBundle\Service;

use YPKY\HelperBundle\Security\YPKYUser;
use YPKY\UserBundle\Entity\UserAccessToken;
use YPKY\UserBundle\Entity\User;
use Doctrine\Bundle\DoctrineBundle\Registry;
use Chromedia\SecurityTokenBundle\Provider\AccessTokenProviderInterface;

/**
 * @author  Farly Taboada
 */
class UserTokenizerService implements AccessTokenProviderInterface
{

    /**
     * @var Registry
     */
    private $doctrine;

    public function setDoctrine(Registry $registry)
    {
        $this->doctrine = $registry;
    }

    public function loadToken($token, $key=null)
    {
        $userAccessToken = $this->doctrine->getRepository('UserBundle:UserAccessToken')
            ->findActiveToken($token, $key);

        return $userAccessToken;
    }

    public function findToken($token)
    {
        return $this->doctrine->getRepository('UserBundle:UserAccessToken')->findOneByToken($token);
    }

    public function save(\YPKY\HelperBundle\Classes\Token $token)
    {
        $this->doctrine->getRepository('UserBundle:UserAccessToken')->save($token);
    }

    public function remove(\YPKY\HelperBundle\Classes\Token $token)
    {
        $this->doctrine->getRepository('UserBundle:UserAccessToken')->delete($token);
    }

    /**
     * generate token
     * @param  User $user
     * @param  integer  $expirationInHours
     * @return UserAccessToken $userToken
     *
     * @todo   improve this
     */
    public function generateUserToken(User $user = null, $expirationInHours=1)
    {
        $intervalSpec = "PT{$expirationInHours}H";

        $dateInterval = new \DateInterval($intervalSpec);

        $token = new UserAccessToken();

        // set expiration
        $now = new \DateTime();
        $token->setExpiration($now->add($dateInterval));

        // generate token string
        $token->setToken($this->generateToken(is_null($user) ? 0 : $user->getId()));
        $token->setUser($user);

        return $token;
    }

    /**
     * generate encoded string using md5
     * @param  string $salt
     * @return string
     */
    public function generateToken($salt=null)
    {
        return md5(time().$salt);
    }
}