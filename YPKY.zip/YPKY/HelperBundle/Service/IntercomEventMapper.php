<?php 
/**
 * Intercom Events Mapper based on form ids.
 *  
 * @author Adelbert Silla 
 */
namespace YPKY\HelperBundle\Service;

use YPKY\ProductBundle\Entity\Form;
class IntercomEventMapper
{
    private $productFormMapper;
    
    public function __construct($productForms = array(), $internalForms = array())
    {
        $forms = $productForms + $internalForms;
        $this->productFormMapper = array(
            $forms['ein'] => IntercomEvents::USER_FILLED_UP_EIN,
            $forms['aoi'] => IntercomEvents::USER_FILLED_UP_AOI,
            $forms['fast501c3'] => IntercomEvents::USER_FILLED_UP_FAST501_C3,
            $forms['full501c3'] => IntercomEvents::USER_FILLED_UP_FULL501_C3,
            $forms['document990'] => IntercomEvents::USER_FILLED_UP_990_DOCUMENT,
            $forms['unified_compliance'] => IntercomEvents::USER_FILLED_UP_UNIFIED_COMPLIANCE,
            $forms['member_profile'] => IntercomEvents::USER_FILLED_UP_MEMBER_PROFILE,
            $forms['organization_profile'] => IntercomEvents::USER_FILLED_UP_ORGANIZATION_PROFILE,

            '1023' => IntercomEvents::USER_SIGNED_UP_WITH_1023,
            '1023_aoi' => IntercomEvents::USER_SIGNED_UP_WITH_1023_AND_AOI,
            '1023_ein' => IntercomEvents::USER_SIGNED_UP_WITH_1023_AND_EIN,
            '1023_aoi_ein' => IntercomEvents::USER_SIGNED_UP_WITH_1023_AND_AOI_AND_EIN
        );
    }

    /** 
     * @param Form $form
     * @return event|NULL
     */
    public function getEventNameByForm(Form $form)
    {
        return isset($this->productFormMapper[$form->getId()])
            ? $this->productFormMapper[$form->getId()]
            : null;
    }

    /** 
     * @param string|int $key
     * @return event|NULL
     */
    public function getEventNameByKey($key)
    {
        return isset($this->productFormMapper[$key])
        ? $this->productFormMapper[$key]
        : null;
    }
}