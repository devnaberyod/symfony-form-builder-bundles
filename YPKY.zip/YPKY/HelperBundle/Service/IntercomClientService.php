<?php
/**
 * @author Adelbert Silla
 * 
 * Helper class for interom client API.
 * 
 * reference for the result object for client methods: 
 * http://api.guzzlephp.org/class-Guzzle.Service.Resource.Model.html
 */
namespace YPKY\HelperBundle\Service;

use Intercom\IntercomBasicAuthClient;
use YPKY\UserBundle\Entity\User;

use Intercom\Exception\ClientErrorResponseException;

class IntercomClientService
{
    const MESSAGE_ADMIN_ASSIGNEE = 'admin';
    const MESSAGE_USER_ASSIGNEE = 'user';
    const MESSAGE_NOBODY_ADMIN_ASSIGNEE = 'nobody_admin';

    private $appId;
    private $apiKey;

    static $client;

    public $user = 'user';

    public $admin = 'admin';

    public function __construct($intercomConfig = array())
    {        
        $config = $intercomConfig;
        $this->appId = $config['app_id'];
        $this->apiKey = $config['api_key'];
        
        return $this;
    }

    public function getAppId()
    {
        return $this->appId;
    }

    public function getApiKey()
    {
        return $this->apiKey;
    }

    public function getClient()
    {
        if(!static::$client) {
            static::$client = IntercomBasicAuthClient::factory(array(
                'app_id' => $this->getAppId(),
                'api_key' => $this->getApiKey()
            ));
        }

        return static::$client;
    }

    public function getUsers()
    {
        $intercom = $this->getClient();
        $intercomUsers = $intercom->getUsers();

        return $intercomUsers;
    }

    public function createUser(User $user)
    {
        $data = array(
            'created_at' => time(),
            'last_request_at' => time(),
            'user_id' => (string)$user->getId(),
            'email' => $user->getEmail()
        );

        $this->getClient()->createUser($data);
    }

    public function userExist($email)
    {
        $intercom = $this->getClient();
        $userExist = $intercom->getUser(array("email" => $email));

        return $userExist;
    }

    public function getConversations($criteria = array(), $assigneeFilter = null)
    {
        $messages = array();
        $result = $this->getClient()->getConversations($criteria);

        //var_dump($result); 
        foreach ($result['conversations'] as $each) {

            $conversation = $this->getConversation($each['id']);
            if($assigneeFilter == $conversation['conversation_message']['author']['type']) {
                $messages[] = $conversation['conversation_message'];
            }

            $conversationParts = $conversation['conversation_parts']['conversation_parts'];
            if(!empty($conversationParts)) {
                $messages = array_merge($messages, $conversationParts);                    
            }
        }

        return $messages;
    }

    public function getConversation($conversationId = null)
    {
        $intercom = $this->getClient();
        $conversation = array();
        if($conversationId !== null){
            $conversation = $intercom->getConversation(array("id" => $conversationId));
        }

        return $conversation;
    }

    public function getUserConversations(User $user, $unreadStatus = null)
    {
        $email = $user->getEmail();
        if(!$this->userExist($email)){
            $this->createUser($user);
        }

        $criteria = array('email' => $email, 'type' => 'user');
        if($unreadStatus !== null){
            $criteria['unread'] = $unreadStatus;
        }

        $conversationLists = $this->getConversations($criteria, self::MESSAGE_ADMIN_ASSIGNEE); 

        return $conversationLists;
    }
    
    /**
     * Create Intercom User event
     *
     * @param string $eventName
     * @param User $user
     */
    public function createUserEvent($eventName, User $user, array $metadata = array())
    {
        $data = array(
            'user_id' => (string)$user->getId(),
            'event_name' => $eventName,
            'created_at' => time()
        );

        if(!empty($metadata)) {
            $data['metadata'] = $metadata;
        }

        try {
            $this->getClient()->createEvent($data);
        } catch (\Exception $e) {}
    }

    /**
     * Delete Intercom User
     * @param string $email
     */
    public function deleteUserByEmail($email)
    {
        try {
            $intercom = $this->getClient();
            $intercom->deleteUser(array(
              'email' => trim($email)
            ));
        } catch (ClientErrorResponseException $e) {
            // should we interrupt process when we got errors from intercom?
            $response = $e->getResponse();
            $code = $response->getStatusCode();
            $return = '';
            if (200 !== $code) {
                $return = 'Error delete intercom account.';
            }
            return $return;
        }
    }
}
