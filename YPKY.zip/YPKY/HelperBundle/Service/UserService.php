<?php

namespace YPKY\HelperBundle\Service;

use Doctrine\Bundle\DoctrineBundle\Registry;

class UserService
{
    private $doctrine;

    public function setDoctrine(Registry $registry)
    {
        $this->doctrine = $registry;
    }

    public function findUser($username, $repository)
    {
        // $user = $this->doctrine->getRepository($repository)->findOneBy(array('email' => $username));

        $user = $this->doctrine->getRepository('UserBundle:User')->findOneByEmail($username);

        return $user;
    }

    public function findUserById($id, $repository)
    {
        $user = $this->doctrine->getEntityManager()->find($repository, $id);

        return $user;
    }
}