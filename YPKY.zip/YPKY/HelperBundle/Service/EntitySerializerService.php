<?php 

namespace YPKY\HelperBundle\Service;

use JMS\Serializer\SerializerBuilder;
use JMS\Serializer\SerializationContext;

/**
 * EntitySerializerService
 */
class EntitySerializerService
{
    public function toArray($entity)
    {
        $serializer = SerializerBuilder::create()->build();
        $maxDepth = SerializationContext::create()->enableMaxDepthChecks();
        $data = \json_decode($serializer->serialize($entity, 'json', $maxDepth), true);

        return $data;
    }
}