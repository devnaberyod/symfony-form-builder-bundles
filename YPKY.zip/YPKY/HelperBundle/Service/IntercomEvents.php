<?php 
/**
 * List of all Intercom events
 *  
 * @author Adelbert Silla
 */
namespace YPKY\HelperBundle\Service;

class IntercomEvents
{
    const USER_FILLED_UP_EIN = 'user-filled-up-ein';
    const USER_FILLED_UP_AOI = 'user-filled-up-aoi';
    const USER_FILLED_UP_FAST501_C3 = 'user-filled-up-fast501-c3';
    const USER_FILLED_UP_FULL501_C3 = 'user-filled-up-full501-c3';
    const USER_FILLED_UP_990_DOCUMENT = 'user-filled-up-990-document';
    const USER_FILLED_UP_UNIFIED_COMPLIANCE = 'user-filled-up-unified-compliance';
    const USER_FILLED_UP_MEMBER_PROFILE = 'user-filled-up-member-profile';
    const USER_FILLED_UP_ORGANIZATION_PROFILE = 'user-filled-up-organization-profile';

    const USER_SIGNED_UP_WITH_1023 = 'user-signed-up-with-form-1023';
    const USER_SIGNED_UP_WITH_1023_AND_AOI = 'user-signed-up-with-form-1023-and-aoi';
    const USER_SIGNED_UP_WITH_1023_AND_EIN = 'user-signed-up-with-form-1023-and-ein';
    const USER_SIGNED_UP_WITH_1023_AND_AOI_AND_EIN = 'user-signed-up-with-form-1023-and-aoi-and-ein';

}