<?php 
namespace YPKY\HelperBundle\Service;

use Doctrine\Bundle\DoctrineBundle\Registry;

class WordpressPlatformService
{
    const WP_FORM_TABLE = 'wp_rg_form';
    const WP_USER_LEAD_DETAILS = 'wp_rg_lead_detail';
    const WP_USER_TABLE = 'wp_users';
    const WP_USER_META_TABLE = 'wp_usermeta';
    const WP_USER_POST_TABLE = 'wp_posts';
    const WP_USER_COMMENTS_TABLE = 'wp_comments';
    const WP_USER_POSTMETA_TABLE = 'wp_postmeta';

    // based on wp_forms.id
    const NONPROFIT_FORM = 7;
    const COMPLIANCE_FORM = 14;

    
    // Key/Index is based on wp_rg_lead_detail.field_number
    static $nonProfileFormPropertyMapper = array (
        '1' => 'first_name',
        '2' => 'last_name',
        '3' => 'email',
        '8.1' => 'step2_option1',
        '70.1' => 'step2_option2',
        '69.1' => 'step2_option3',
        '11.1' => 'aoi_form',
        '71.1' => 'ein_form'
    );

    // Key/Index is based on wp_rg_lead_detail.field_number
    static $complianceFormPropertyMapper = array (
        '2' => 'first_name',
        '3' => 'last_name',
        '4' => 'email',
        '17' => 'states'
    );

    /**
     * @var Registry
     */
    private $doctrine;
    
    public function setDoctrine(Registry $registry)
    {
        $this->doctrine = $registry;
    }
    
    public function getActiveForms()
    {
        $sql = "SELECT * FROM " . self::WP_FORM_TABLE . " WHERE is_active = 1 AND is_trash != 1";

        $conn = $this->getConnection();
        $stmt = $conn->prepare($sql);
        $stmt->execute();

        return $stmt->fetchAll();
    }
    
    public function getUserDataByEmail($email)
    {
        $data = $this->getLeadIdAndFormIdByEmail($email);

        if(empty($data)) {
            return $data;
        }

        $sql = "SELECT * FROM " . self::WP_USER_LEAD_DETAILS . " WHERE lead_id = ". $data['lead_id'];

        $conn = $this->getConnection();
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();
        
        $propertiesMapper = $this->getPropertiesMapperByForm($data['form_id']);

        foreach($result as $each) {
            if(isset($propertiesMapper[$each['field_number']])) {
                $data[$propertiesMapper[$each['field_number']]] = $each['value'];
            }
        }

        return $data;
    }
    
    public function getLeadIdAndFormIdByEmail($email)
    {
        $sql = "SELECT * FROM " . self::WP_USER_LEAD_DETAILS . " WHERE value LIKE '". $email ."' ORDER BY id DESC LIMIT 1";

        $conn = $this->getConnection();
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll();

        $data = array();
        if(!empty($result)) {
            $data = array('lead_id' => $result[0]['lead_id'], 'form_id' => $result[0]['form_id']);
        }

        return $data;
    }
    
    public function getActiveFormsAsChoices()
    {
        $forms = $this->getActiveForms();
        
        $choices = array();
        foreach($forms as $each) {
            $choices[$each['id']] = $each['title'];
        }
        
        return $choices;
    }
    
    private function getConnection()
    {
        return $this->doctrine->getConnection('wp_db');
    }

    private function getPropertiesMapperByForm($formId)
    {
        $properties = array();

        switch ($formId)
        {
            case self::COMPLIANCE_FORM : 
                $properties = self::$complianceFormPropertyMapper; break;
            case self::NONPROFIT_FORM : 
                $properties = self::$nonProfileFormPropertyMapper; break;
        }

        return $properties;
    }

    public function deleteUserByEmail($email)
    {
        $sql = "DELETE FROM " . self::WP_USER_TABLE . " WHERE user_email = '" . trim($email) ."';";

        $conn = $this->getConnection();
        
        $query = $conn->prepare($sql);
        $userDeleted = $query->execute();

        //Delete related user record
        $sql2 = "
            DELETE FROM " . self::WP_USER_META_TABLE . " WHERE user_id = '" . trim($userDeleted['user_id']) ."';
            DELETE FROM " . self::WP_USER_COMMENTS_TABLE . " WHERE user_id = '" . trim($userDeleted['user_id']) ."';
            DELETE FROM " . self::WP_USER_POSTMETA_TABLE. " WHERE user_id = '" . trim($userDeleted['user_id']) ."';
            DELETE FROM " . self::WP_USER_POST_TABLE . "  WHERE user_id =  '" . trim($userDeleted['user_id']) . "';
        ";

        $query2 = $conn->prepare($sql2);
        $query2->execute();

    }
}