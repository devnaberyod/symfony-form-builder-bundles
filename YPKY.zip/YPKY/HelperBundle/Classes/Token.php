<?php

namespace YPKY\HelperBundle\Classes;

interface Token
{
}