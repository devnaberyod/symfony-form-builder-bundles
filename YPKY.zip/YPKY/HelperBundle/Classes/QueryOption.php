<?php

namespace YPKY\HelperBundle\Classes;

class QueryOption
{
    private $orderByOptions=array();

    /**
     *
     * @param string $sort
     * @param boolean $ascending
     */
    public function addOrderBy($sort, $ascending=true)
    {
        $opt = new \stdClass();
        $opt->sort = $sort;
        $opt->order = $ascending ? 'ASC':'DESC';

        $this->orderByOptions[] = $opt;
    }

    public function getOrderByOptions()
    {
        return $this->orderByOptions;
    }
}