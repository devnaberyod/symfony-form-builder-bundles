<?php

namespace YPKY\HelperBundle\Classes;

use YPKY\HelperBundle\Classes\Token;

interface TokenInterface
{
    public function setToken(Token $token);
}