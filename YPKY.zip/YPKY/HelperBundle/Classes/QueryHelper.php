<?php
namespace YPKY\HelperBundle\Classes;

use Doctrine\ORM\QueryBuilder;
use YPKY\HelperBundle\Exception\QueryOptionException;
class QueryHelper
{
    /**
     * Convenience function to apply $filters to a QueryBuilder. $filters will be checked if it belongs to $knownFilters
     *
     * @param QueryBuilder $qb
     * @param array $knownFilters
     * @param array $filters
     * @return QueryBuilder
     */
    static public function applyQueryBuilderFilters(QueryBuilder $qb, array $knownFilters, array $filters=array())
    {
        foreach ($filters as $key => $val){
            if (isset($knownFilters[$key]) && !\is_null($val)){
                $expr = $knownFilters[$key];
                $qb->andWhere($expr)
                ->setParameter($key, $val);
            }
        }

        return $qb;
    }

    static public function applyOrderByOptions(QueryBuilder $qb, array $allowedSortFields, QueryOption $queryOption)
    {
        foreach ($queryOption->getOrderByOptions() as $opt) {
            if (!array_key_exists($opt->sort, $allowedSortFields)) {
                throw QueryOptionException::invalidSortField($opt->sort);
            }
            $qb->addOrderBy($allowedSortFields[$opt->sort], $opt->order);
        }

        return $qb;
    }
}